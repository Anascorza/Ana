<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * AUTH HELPER — Funções de Autenticação com JWT
 * Versão: 2.0.1 (Corrigida)
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Arquivo compartilhado para ambos os sistemas (Sistema Branco + R Créditos)
 * Fornece funções de autenticação, validação e geração de tokens JWT
 */

// Incluir classe JWT
require_once __DIR__ . '/jwt.php';

// ════════════════════════════════════════════════════════════════════════════
// CONFIGURAÇÕES
// ════════════════════════════════════════════════════════════════════════════

// JWT_EXPIRATION definido em app/config/app.php

// ════════════════════════════════════════════════════════════════════════════
// FUNÇÕES DE AUTENTICAÇÃO
// ════════════════════════════════════════════════════════════════════════════

/**
 * Validar credenciais de login
 * 
 * @param string $email Email do usuário
 * @param string $senha Senha em texto plano
 * @param PDO $db Conexão com banco de dados
 * @return array|null Dados do usuário se válido, null caso contrário
 */
function validarCredenciais($email, $senha, $db) {
    try {
        $stmt = $db->prepare('SELECT id, nome, email, senha, tipo, admin_id, ativo FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1');
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();
        
        if (!$usuario) {
            return null;
        }
        
        // Verificar senha
        if (!password_verify($senha, $usuario['senha'])) {
            return null;
        }
        
        return $usuario;
    } catch (Exception $e) {
        error_log('Erro ao validar credenciais: ' . $e->getMessage());
        return null;
    }
}

/**
 * Gerar JWT para usuário
 * 
 * @param array $usuario Dados do usuário
 * @param int $expirationTime Tempo de expiração em segundos
 * @return string Token JWT
 */
function gerarToken($usuario, $expirationTime = JWT_EXPIRATION) {
    $payload = [
        'usuario_id' => (int)$usuario['id'],
        'nome' => $usuario['nome'],
        'email' => $usuario['email'],
        'tipo' => $usuario['tipo'],
        'admin_id' => !empty($usuario['admin_id']) ? (int)$usuario['admin_id'] : null,
    ];
    
    return JWT::encode($payload, $expirationTime);
}

/**
 * Validar token JWT do header
 * 
 * @return array|null Payload do token se válido, null caso contrário
 */
function validarTokenHeader() {
    return JWT::validateFromHeader();
}

/**
 * Obter usuário atual do token
 * 
 * @param array $payload Payload do JWT
 * @return array Dados do usuário
 */
function obterUsuarioAtual($payload) {
    return [
        'id' => $payload['usuario_id'],
        'nome' => $payload['nome'],
        'email' => $payload['email'],
        'tipo' => $payload['tipo'],
        'admin_id' => $payload['admin_id'],
    ];
}

/**
 * Verificar se usuário é admin
 * 
 * @param array $payload Payload do JWT
 * @return bool
 */
function ehAdmin($payload) {
    return $payload['tipo'] === 'admin';
}

/**
 * Verificar se usuário é operador
 * 
 * @param array $payload Payload do JWT
 * @return bool
 */
function ehOperador($payload) {
    return $payload['tipo'] === 'operador';
}

/**
 * Registrar tentativa de login
 * 
 * @param string $email Email tentado
 * @param bool $sucesso Se o login foi bem-sucedido
 * @param string $motivo Motivo da falha (se aplicável)
 * @param PDO $db Conexão com banco de dados
 */
function registrarTentativaLogin($email, $sucesso, $motivo = null, $db = null) {
    if (!$db) return;
    
    try {
        $usuario_id = null;
        if ($sucesso) {
            $stmt = $db->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $u = $stmt->fetch();
            $usuario_id = $u['id'] ?? null;
        }
        
        $stmt = $db->prepare('
            INSERT INTO auditoria_acesso (usuario_id, tipo_acesso, resultado, motivo_falha, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ');
        
        $stmt->execute([
            $usuario_id,
            'login',
            $sucesso ? 'sucesso' : 'falha',
            $motivo,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        error_log('Erro ao registrar tentativa de login: ' . $e->getMessage());
    }
}

/**
 * Registrar ação do usuário em logs
 * Redireciona para logAcao() definida em app/config/app.php para evitar duplicidade
 */
function registrarAcao($db, $usuario_id, $admin_id, $acao, $tabela = null, $item_id = null, $dados_antigos = null, $dados_novos = null) {
    if (function_exists('logAcao')) {
        $detalhes = $dados_novos ? (is_string($dados_novos) ? $dados_novos : json_encode($dados_novos, JSON_UNESCAPED_UNICODE)) : null;
        logAcao($acao, $detalhes, $tabela, $item_id);
    }
}

/**
 * Invalidar token (logout)
 * 
 * @param string $token Token JWT a ser invalidado
 * @param int $usuario_id ID do usuário
 * @param PDO $db Conexão com banco de dados
 * @param string $motivo Motivo da invalidação
 */
function invalidarToken($token, $usuario_id, $db, $motivo = 'logout') {
    try {
        $tokenHash = hash('sha256', $token);
        
        $stmt = $db->prepare('
            INSERT INTO tokens_invalidados (usuario_id, token_hash, motivo)
            VALUES (?, ?, ?)
        ');
        
        $stmt->execute([$usuario_id, $tokenHash, $motivo]);

        // Bug fix: Purga periódica de tokens expirados (mais de 24h)
        $db->prepare('DELETE FROM tokens_invalidados WHERE criado_em < DATE_SUB(NOW(), INTERVAL 24 HOUR)')->execute();
        
    } catch (Exception $e) {
        error_log('Erro ao invalidar token: ' . $e->getMessage());
    }
}

/**
 * Verificar se token foi invalidado
 * 
 * @param string $token Token JWT
 * @param PDO $db Conexão com banco de dados
 * @return bool True se foi invalidado, false caso contrário
 */
function tokenFoiInvalidado($token, $db) {
    try {
        $tokenHash = hash('sha256', $token);
        
        $stmt = $db->prepare('SELECT id FROM tokens_invalidados WHERE token_hash = ? LIMIT 1');
        $stmt->execute([$tokenHash]);
        
        return $stmt->fetch() !== false;
    } catch (Exception $e) {
        error_log('Erro ao verificar token invalidado: ' . $e->getMessage());
        return false;
    }
}

/**
 * Validar código de vínculo
 * 
 * @param string $codigo_vinculo Código a validar
 * @param PDO $db Conexão com banco de dados
 * @return array|null Dados do admin se válido, null caso contrário
 */
function validarCodigoVinculo($codigo_vinculo, $db) {
    try {
        // Busca em usuarios.codigo_vinculo — gerado pelo Sistema Branco
        $stmt = $db->prepare(
            'SELECT id, nome, email, tipo FROM usuarios
             WHERE codigo_vinculo = ? AND tipo = "admin" AND ativo = 1
             LIMIT 1'
        );
        $stmt->execute([$codigo_vinculo]);
        return $stmt->fetch();
    } catch (Exception $e) {
        error_log('Erro ao validar código de vínculo: ' . $e->getMessage());
        return null;
    }
}

/**
 * Gerar código de vínculo único
 * 
 * @return string Código de vínculo (20 caracteres)
 */
function gerarCodigoVinculo() {
    return strtoupper(substr(bin2hex(random_bytes(10)), 0, 20));
}

/**
 * Registrar vínculo entre admin e operador
 * 
 * @param PDO $db Conexão com banco de dados
 * @param int $admin_id ID do admin
 * @param int $usuario_id ID do operador
 * @param string $codigo_vinculo Código utilizado
 * @param string $nome_ruta Nome da ruta
 * @return bool True se registrado com sucesso
 */
function registrarVinculo($db, $admin_id, $usuario_id, $codigo_vinculo, $nome_ruta) {
    try {
        $stmt = $db->prepare('
            INSERT INTO vinculacoes (admin_id, usuario_id, codigo_vinculo_usado, nome_ruta, ip_vinculacao, user_agent_vinculacao)
            VALUES (?, ?, ?, ?, ?, ?)
        ');
        
        $stmt->execute([
            $admin_id,
            $usuario_id,
            $codigo_vinculo,
            $nome_ruta,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        return true;
    } catch (Exception $e) {
        error_log('Erro ao registrar vínculo: ' . $e->getMessage());
        return false;
    }
}

/**
 * Revogar vínculo
 * 
 * @param PDO $db Conexão com banco de dados
 * @param int $vinculo_id ID do vínculo
 * @param string $motivo Motivo da revogação
 * @return bool True se revogado com sucesso
 */
function revogarVinculo($db, $vinculo_id, $motivo = null) {
    try {
        $stmt = $db->prepare('
            UPDATE vinculacoes 
            SET status = "revogado", data_desvinculacao = NOW(), motivo_revogacao = ?
            WHERE id = ?
        ');
        
        $stmt->execute([$motivo, $vinculo_id]);
        return true;
    } catch (Exception $e) {
        error_log('Erro ao revogar vínculo: ' . $e->getMessage());
        return false;
    }
}

// Função resposta() definida em app/config/app.php

/**
 * Middleware de autenticação JWT
 * Deve ser chamado no início de cada endpoint protegido
 * 
 * @param PDO $db Conexão com banco de dados
 * @return array Payload do JWT
 */
function middleware_autenticacao($db) {
    $payload = JWT::validateFromHeader();
    
    if (!$payload) {
        resposta(false, 'Token inválido ou expirado', null, 401);
    }
    
    // Verificar se token foi invalidado
    if (tokenFoiInvalidado(JWT::getTokenFromHeader(), $db)) {
        resposta(false, 'Token foi revogado', null, 401);
    }
    
    return $payload;
}

/**
 * Middleware de autorização (apenas admin)
 * 
 * @param array $payload Payload do JWT
 */
function middleware_admin($payload) {
    if (!ehAdmin($payload)) {
        resposta(false, 'Acesso negado. Apenas administradores.', null, 403);
    }
}

/**
 * Middleware de autorização (apenas operador)
 * 
 * @param array $payload Payload do JWT
 */
function middleware_operador($payload) {
    if (!ehOperador($payload)) {
        resposta(false, 'Acesso negado. Apenas operadores.', null, 403);
    }
}

?>
