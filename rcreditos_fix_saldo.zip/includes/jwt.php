<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * JWT — JSON Web Token (Implementação em PHP Puro)
 * ════════════════════════════════════════════════════════════════════════════
 * 
 * Implementação nativa de JWT (RFC 7519) sem dependências externas.
 * Compatível com PHP 7.2+
 * 
 * Algoritmo: HS256 (HMAC com SHA-256)
 * Formato: header.payload.signature (Base64Url)
 */

class JWT {
    
    /**
     * Chave secreta para assinatura do token
     * Deve ser definida via setSecret() no bootstrap da aplicação
     */
    private static $secret = '';
    
    /**
     * Algoritmo de assinatura
     */
    private static $algorithm = 'HS256';
    
    /**
     * ────────────────────────────────────────────────────────────────────────
     * Codificar Payload em JWT
     * ────────────────────────────────────────────────────────────────────────
     */
    public static function encode($payload, $expirationTime = 3600) {
        if (empty(self::$secret)) {
            throw new Exception('JWT Secret não configurado. Chame JWT::setSecret() antes de usar.');
        }

        if (!is_array($payload)) {
            throw new InvalidArgumentException('Payload deve ser um array');
        }
        
        $header = [
            'alg' => self::$algorithm,
            'typ' => 'JWT'
        ];
        
        $payload['exp'] = time() + $expirationTime;
        $payload['iat'] = time();
        
        $headerEncoded = self::base64UrlEncode(json_encode($header, JSON_UNESCAPED_UNICODE));
        $payloadEncoded = self::base64UrlEncode(json_encode($payload, JSON_UNESCAPED_UNICODE));
        
        $signatureInput = $headerEncoded . '.' . $payloadEncoded;
        $signature = hash_hmac('sha256', $signatureInput, self::$secret, true);
        $signatureEncoded = self::base64UrlEncode($signature);
        
        return $signatureInput . '.' . $signatureEncoded;
    }
    
    /**
     * ────────────────────────────────────────────────────────────────────────
     * Decodificar JWT
     * ────────────────────────────────────────────────────────────────────────
     */
    public static function decode($token) {
        if (empty(self::$secret)) {
            throw new Exception('JWT Secret não configurado. Chame JWT::setSecret() antes de usar.');
        }

        if (!is_string($token)) {
            return null;
        }
        
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }
        
        list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
        
        $signatureInput = $headerEncoded . '.' . $payloadEncoded;
        $signature = hash_hmac('sha256', $signatureInput, self::$secret, true);
        $signatureValid = self::base64UrlEncode($signature) === $signatureEncoded;
        
        if (!$signatureValid) {
            return null;
        }
        
        try {
            $payload = json_decode(self::base64UrlDecode($payloadEncoded), true);
        } catch (Exception $e) {
            return null;
        }
        
        if (!is_array($payload)) {
            return null;
        }
        
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return null;
        }
        
        return $payload;
    }
    
    public static function isValid($token) {
        return self::decode($token) !== null;
    }
    
    public static function getTokenFromHeader() {
        $authHeader = '';
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        }
        if (empty($authHeader)) {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        }
        
        if (empty($authHeader)) {
            return null;
        }
        
        if (strpos($authHeader, 'Bearer ') !== 0) {
            return null;
        }
        
        return substr($authHeader, 7);
    }
    
    public static function validateFromHeader() {
        $token = self::getTokenFromHeader();
        if (!$token) {
            return null;
        }
        return self::decode($token);
    }
    
    public static function setSecret($secret) {
        if (strlen($secret) < 16) {
            throw new InvalidArgumentException('Chave secreta deve ter no mínimo 16 caracteres');
        }
        self::$secret = $secret;
    }
    
    private static function base64UrlEncode($data) {
        return rtrim(str_replace(['+', '/'], ['-', '_'], base64_encode($data)), '=');
    }
    
    private static function base64UrlDecode($data) {
        $remainder = strlen($data) % 4;
        if ($remainder) {
            $data .= str_repeat('=', 4 - $remainder);
        }
        return base64_decode(str_replace(['-', '_'], ['+', '/'], $data));
    }
}
?>
