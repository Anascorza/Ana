# Sistema de filtros — correções aplicadas

O dashboard do R. Créditos foi revisado e o sistema de filtros foi corrigido e otimizado.

## Alterações principais

- O filtro por tipo no painel agora reaplica a listagem imediatamente ao trocar a opção.
- A regra de baixas foi ajustada: somente `tipo = pagamento` entra em “Pagaram Hoje”; `tipo = pagamento` e `tipo = nao-pagou` contam como baixa para excluir o cliente de “Sem Baixa”. Eventos de multa não são tratados como baixa de parcela.
- Campos de atraso, valor e vencimento só são considerados quando o respectivo tipo de filtro está ativo; valores antigos em campos ocultos não interferem mais no resultado.
- A função de data atual passou a usar a data local do dispositivo, evitando diferenças causadas por UTC/fuso horário.
- A busca de clientes passou a considerar nome comercial, nome completo, celular e identificador numérico.
- A busca de vendas passou a considerar os mesmos campos do cliente e mantém o filtro por valor.
- A ordenação por data de venda foi corrigida para aceitar os nomes de campo normalizados e os nomes legados.
- Foram adicionadas proteções contra respostas assíncronas antigas sobrescreverem uma filtragem mais recente.
- Foi corrigido um handler inline malformado no card do painel que poderia interromper a interação com o WhatsApp.

## Validação

- Os blocos JavaScript embutidos no dashboard foram extraídos e validados com `node --check` sem erros de sintaxe.
- O interpretador PHP não está instalado neste ambiente, portanto a validação de sintaxe PHP não pôde ser executada localmente.
