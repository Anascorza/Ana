# Histórico Diário de Cobranças

A implementação adiciona uma tabela isolada, `historico_cobrancas`, sem alterar as tabelas existentes de vendas, parcelas ou pagamentos. A migração está em `database/historico_cobrancas.sql` e deve ser executada uma única vez no banco antes de usar o histórico.

## Regras definitivas

A consulta sincroniza, de forma idempotente, todos os dias de cobrança já alcançados enquanto a venda ainda não estiver 100% quitada. Cada parcela com data de cobrança vencida ou atual gera um registro, exceto domingos. A sincronização não para por atraso, parcela em aberto ou pagamento posterior; ela só deixa de criar novos dias quando todas as parcelas estiverem integralmente pagas.

Um dia sem pagamento fica como `nao-pagou` e nunca é convertido retroativamente em `pago`. Uma baixa posterior é outro evento, gravado na data real em que ocorreu e vinculado ao número da parcela efetivamente baixada.

## Valor real e pagamentos parciais

Os eventos de baixa usam o valor efetivamente registrado no pagamento. Quando uma baixa quita várias parcelas, o sistema registra um evento por parcela com a alocação correspondente. Quando existe crédito parcial anterior, a nova baixa é alocada somente pelo valor necessário para completar a parcela e pelo eventual restante destinado à próxima. Pagamentos parciais permanecem parciais até a soma dos pagamentos vinculados atingir o valor previsto da parcela.

Na interface, os eventos de baixa aparecem como `Pago — R$ valor`, com a data real, o número da parcela e a observação de que se trata da baixa daquela parcela. O valor previsto da parcela não substitui o valor real da baixa.

## Idempotência e compatibilidade

Os registros de cobrança usam chave única por venda, parcela e data. Os eventos de pagamento usam chave única por identificador da baixa, parcela e valor. Consultas repetidas não duplicam dias, pagamentos, baixas ou parcelas. A lógica atual de vendas, parcelas, pagamentos, multas e rotas permanece preservada.

A nova tabela é opcional até a migração ser executada; enquanto ela não existir, os endpoints financeiros continuam operando. Após executar o SQL, o botão **Histórico de Parcelas** passa a consultar o histórico diário persistido.
