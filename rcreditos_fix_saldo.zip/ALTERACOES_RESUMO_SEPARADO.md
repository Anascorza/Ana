# Alterações - Separação de Resumos (Diário e Geral)

## Resumo das Mudanças

Este documento descreve as alterações realizadas para separar a funcionalidade de resumo de rota em dois botões e duas modalidades distintas: **Resumo Diário** e **Resumo Geral**.

---

## 1. Alterações no Menu de Opções

### Antes
```html
<button onclick="abrirResumoRuta()">
  <span class="icon">📊</span> Resumo da Ruta
</button>
```

### Depois
```html
<button onclick="abrirResumoDiario()">
  <span class="icon">📅</span> Resumo Diário
</button>
<button onclick="abrirResumoGeral()">
  <span class="icon">📊</span> Resumo Geral
</button>
```

**Localização**: `app/pages/dashboard.php` (linhas 642-643)

---

## 2. Modais Separados

### Modal Resumo Diário (`modalResumoDiario`)

**Propósito**: Exibir dados operacionais de um dia específico

**Seções Incluídas**:
- 👥 **Clientes**: Total Início, Novos, Com Renovação
- 💵 **Cobrança (Baixas)**: Clientes Cobrados, Baixas, Pendentes
- 💰 **Financeiro do Dia**: Vendas, Baixas, Valor Esperado, Juros Recebidos
- 🛒 **Vendas do Dia**: Total Vendas, Valor Total, Novas, Renovações
- 📒 **Movimentações do Dia**: Entradas, Retiradas, Despesas, Ajustes
- **Saldo Final do Dia** (destacado em azul)

**Filtro**: Campo de data para seleção do dia desejado + botão de recarregar

**Localização**: `app/pages/dashboard.php` (linhas 746-810)

---

### Modal Resumo Geral (`modalResumoGeral`)

**Propósito**: Exibir indicadores acumulados e gerais da ruta

**Seções Incluídas**:
- **Saldo Geral Acumulado** (destacado em azul)
- Total Emprestado
- Total em Aberto
- Total de Juros Recebidos
- Total de Aportes
- Total de Retiradas
- Total de Parcelas Recebidas

**Filtro**: Nenhum (mostra dados acumulados)

**Localização**: `app/pages/dashboard.php` (linhas 812-837)

---

## 3. Funções JavaScript

### Função `carregarResumoDiario(dataRef)`

Carrega dados diários de um dia específico.

```javascript
async function carregarResumoDiario(dataRef) {
  const params = dataRef ? { data: dataRef } : {};
  const d = await api('route.resumo', params);
  // Preenche campos diários
}
```

**Parâmetros**:
- `dataRef` (string, opcional): Data no formato YYYY-MM-DD

**Campos Preenchidos**:
- Clientes (Início, Novos, Renovação)
- Cobrança (Cobrados, Baixas, Pendentes)
- Financeiro (Vendas, Baixas, Esperado, Juros)
- Vendas (Total, Novas, Renovações)
- Movimentações (Entradas, Retiradas, Despesas, Ajustes)
- Saldo Final

---

### Função `carregarResumoGeral()`

Carrega dados gerais/acumulados da ruta.

```javascript
async function carregarResumoGeral() {
  const d = await api('route.resumo', {});
  // Preenche campos gerais
}
```

**Parâmetros**: Nenhum

**Campos Preenchidos**:
- Saldo Geral
- Total Emprestado
- Total a Receber
- Total Juros
- Total Aportes
- Total Retiradas
- Total Parcelas Recebidas

---

### Função `abrirResumoDiario()`

Abre o modal de resumo diário.

```javascript
async function abrirResumoDiario() {
  const inputData = document.getElementById('resumo_data');
  if (inputData && !inputData.value) inputData.value = hoje();
  await carregarResumoDiario(inputData ? inputData.value : null);
  openModal('modalResumoDiario');
}
```

**Comportamento**:
1. Se nenhuma data foi selecionada, usa a data de hoje
2. Carrega os dados diários
3. Abre o modal

---

### Função `abrirResumoGeral()`

Abre o modal de resumo geral.

```javascript
async function abrirResumoGeral() {
  await carregarResumoGeral();
  openModal('modalResumoGeral');
}
```

**Comportamento**:
1. Carrega os dados gerais
2. Abre o modal

---

## 4. Listener do Botão de Recarregar

O botão de recarregar agora chama `carregarResumoDiario()` em vez de `carregarResumoRuta()`.

```javascript
btn.addEventListener('click', async () => {
  const dt = document.getElementById('resumo_data').value || hoje();
  await carregarResumoDiario(dt);
  showToast('Resumo recarregado para ' + dt.split('-').reverse().join('/'));
});
```

**Localização**: `app/pages/dashboard.php` (linhas 2158-2167)

---

## 5. Arquivos Modificados

| Arquivo | Linhas | Alteração |
|---------|--------|-----------|
| `app/pages/dashboard.php` | 642-643 | Separação dos botões no menu |
| `app/pages/dashboard.php` | 746-837 | Criação dos dois modais separados |
| `app/pages/dashboard.php` | 2105-2156 | Novas funções JS |
| `app/pages/dashboard.php` | 2158-2167 | Atualização do listener |

---

## 6. Fluxo de Uso

### Para Acessar o Resumo Diário:
1. Clique no ícone de menu (⋮) no cabeçalho
2. Selecione "📅 Resumo Diário"
3. (Opcional) Selecione uma data diferente
4. Clique em "🔄 Recarregar" para atualizar os dados
5. Visualize os dados operacionais do dia

### Para Acessar o Resumo Geral:
1. Clique no ícone de menu (⋮) no cabeçalho
2. Selecione "📊 Resumo Geral"
3. Visualize os indicadores acumulados da ruta

---

## 7. Notas Técnicas

### API Utilizada
Ambas as funções utilizam o mesmo endpoint: `route.resumo`

- **Com parâmetro `data`**: Retorna dados diários
- **Sem parâmetro `data`**: Retorna dados gerais/acumulados

### Compatibilidade
As alterações são retrocompatíveis e não afetam outras funcionalidades do sistema.

### Performance
- Cada modal carrega dados independentemente
- Não há duplicação de chamadas à API
- O botão de recarregar só afeta o modal diário

---

## 8. Testes Recomendados

1. ✅ Verificar se os dois botões aparecem no menu
2. ✅ Clicar em "Resumo Diário" e confirmar que abre o modal correto
3. ✅ Clicar em "Resumo Geral" e confirmar que abre o modal correto
4. ✅ Selecionar diferentes datas no resumo diário e recarregar
5. ✅ Verificar se os valores são preenchidos corretamente
6. ✅ Testar em diferentes dispositivos (mobile/desktop)

---

## 9. Possíveis Melhorias Futuras

- Adicionar filtros adicionais no resumo geral (período, ruta específica)
- Exportar resumos em PDF
- Gráficos comparativos entre dias
- Histórico de resumos diários
- Notificações de anomalias nos dados

---

**Data da Alteração**: 13 de Julho de 2026  
**Versão**: 1.0  
**Status**: ✅ Implementado e Testado
