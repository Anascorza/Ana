<?php
/**
 * MIGRAÇÃO SEGURA — R Créditos v4.2
 * ════════════════════════════════════════════════════════════════════
 * Suba este arquivo na raiz do sistema, acesse pelo navegador UMA VEZ,
 * confirme que aparece "MIGRAÇÃO CONCLUÍDA" e depois APAGUE este arquivo.
 *
 * O que este script faz (100% seguro, sem apagar dados):
 *  1. Adiciona colunas novas (ruta_id, usuario_id, admin_id) se não existirem
 *  2. Preenche retroativamente os registros antigos
 *  3. Cria índices de performance
 *  4. Expande o ENUM movimentacoes.tipo para incluir 'despesa'
 *  5. Adiciona coluna vendas.tipo se não existir
 */
require_once __DIR__ . '/shared/db.php';
header('Content-Type: text/html; charset=utf-8');

echo '<pre style="white-space:pre-wrap;font-family:Consolas,monospace;padding:20px">';
echo "MIGRAÇÃO SEGURA — R Créditos v4.2\n";
echo str_repeat('=', 55) . "\n\n";

try {
    $db = getDB();
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    function mig_tableExists(PDO $db, $table) {
        $st = $db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $st->execute([$table]);
        return (int)$st->fetchColumn() > 0;
    }

    function mig_colExists(PDO $db, $table, $col) {
        $st = $db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
        $st->execute([$table, $col]);
        return (int)$st->fetchColumn() > 0;
    }

    function mig_idxExists(PDO $db, $table, $idx) {
        $st = $db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?");
        $st->execute([$table, $idx]);
        return (int)$st->fetchColumn() > 0;
    }

    function mig_addCol(PDO $db, $table, $col, $ddl) {
        if (!mig_tableExists($db, $table)) { echo "  AVISO  Tabela {$table} nao existe — pulado\n"; return; }
        if (!mig_colExists($db, $table, $col)) {
            $db->exec("ALTER TABLE `{$table}` ADD COLUMN {$ddl}");
            echo "  OK     Coluna adicionada: {$table}.{$col}\n";
        } else {
            echo "  -      Coluna ja existe:  {$table}.{$col}\n";
        }
    }

    function mig_addIdx(PDO $db, $table, $idx, $cols) {
        if (!mig_tableExists($db, $table)) { echo "  AVISO  Tabela {$table} nao existe — indice pulado\n"; return; }
        if (!mig_idxExists($db, $table, $idx)) {
            $db->exec("ALTER TABLE `{$table}` ADD INDEX `{$idx}` ({$cols})");
            echo "  OK     Indice adicionado: {$table}.{$idx}\n";
        } else {
            echo "  -      Indice ja existe:  {$table}.{$idx}\n";
        }
    }

    // ── PASSO 1: Novas colunas ────────────────────────────────────
    echo "PASSO 1 — Adicionando colunas novas...\n";
    mig_addCol($db, 'vendas',    'ruta_id',   '`ruta_id`    INT NULL DEFAULT NULL AFTER `admin_id`');
    mig_addCol($db, 'parcelas',  'usuario_id','`usuario_id` INT NULL DEFAULT NULL AFTER `cliente_id`');
    mig_addCol($db, 'parcelas',  'ruta_id',   '`ruta_id`    INT NULL DEFAULT NULL AFTER `usuario_id`');
    mig_addCol($db, 'pagamentos','usuario_id','`usuario_id` INT NULL DEFAULT NULL AFTER `cliente_id`');
    mig_addCol($db, 'pagamentos','ruta_id',   '`ruta_id`    INT NULL DEFAULT NULL AFTER `usuario_id`');
    mig_addCol($db, 'multas',    'usuario_id','`usuario_id` INT NULL DEFAULT NULL AFTER `cliente_id`');
    mig_addCol($db, 'multas',    'ruta_id',   '`ruta_id`    INT NULL DEFAULT NULL AFTER `usuario_id`');
    mig_addCol($db, 'multas',    'admin_id',  '`admin_id`   INT NULL DEFAULT NULL AFTER `ruta_id`');
    mig_addCol($db, 'fotos',     'usuario_id',   '`usuario_id`    INT NULL DEFAULT NULL AFTER `cliente_id`');
    mig_addCol($db, 'fotos',     'ruta_id',      '`ruta_id`       INT NULL DEFAULT NULL AFTER `usuario_id`');
    mig_addCol($db, 'fotos',     'imagem_base64','`imagem_base64` LONGTEXT NULL DEFAULT NULL AFTER `label`');
    // vendas.tipo (necessario para classificar nova/renovacao)
    mig_addCol($db, 'vendas',    'tipo',      "`tipo` ENUM('nova','renovacao') NOT NULL DEFAULT 'nova' AFTER `edicoes_restantes`");

    // ── PASSO 2: Preencher dados retroativos ──────────────────────
    echo "\nPASSO 2 — Preenchendo registros antigos...\n";
    if (mig_tableExists($db, 'vendas') && mig_tableExists($db, 'rutas') && mig_colExists($db, 'vendas', 'ruta_id')) {
        $db->exec("UPDATE `vendas` v INNER JOIN `rutas` r ON r.usuario_id = v.usuario_id AND r.ativa = 1 SET v.ruta_id = r.id WHERE v.ruta_id IS NULL");
        echo "  OK     vendas.ruta_id preenchido\n";
    }
    if (mig_tableExists($db, 'parcelas') && mig_tableExists($db, 'vendas') && mig_colExists($db, 'parcelas', 'usuario_id')) {
        $db->exec("UPDATE `parcelas` p INNER JOIN `vendas` v ON v.id = p.venda_id SET p.usuario_id = v.usuario_id, p.ruta_id = v.ruta_id WHERE p.usuario_id IS NULL OR p.ruta_id IS NULL");
        echo "  OK     parcelas usuario_id/ruta_id preenchidos\n";
    }
    if (mig_tableExists($db, 'pagamentos') && mig_tableExists($db, 'vendas') && mig_colExists($db, 'pagamentos', 'usuario_id')) {
        $db->exec("UPDATE `pagamentos` p INNER JOIN `vendas` v ON v.id = p.venda_id SET p.usuario_id = v.usuario_id, p.ruta_id = v.ruta_id WHERE p.usuario_id IS NULL OR p.ruta_id IS NULL");
        echo "  OK     pagamentos usuario_id/ruta_id preenchidos\n";
    }
    if (mig_tableExists($db, 'multas') && mig_tableExists($db, 'vendas') && mig_colExists($db, 'multas', 'usuario_id')) {
        $db->exec("UPDATE `multas` m INNER JOIN `vendas` v ON v.id = m.venda_id SET m.usuario_id = v.usuario_id, m.ruta_id = v.ruta_id, m.admin_id = v.admin_id WHERE m.usuario_id IS NULL OR m.ruta_id IS NULL");
        echo "  OK     multas usuario_id/ruta_id/admin_id preenchidos\n";
    }
    if (mig_tableExists($db, 'fotos') && mig_tableExists($db, 'clientes') && mig_tableExists($db, 'rutas') && mig_colExists($db, 'fotos', 'usuario_id')) {
        $db->exec("UPDATE `fotos` f INNER JOIN `clientes` c ON c.id = f.cliente_id INNER JOIN `rutas` r ON r.usuario_id = c.usuario_id AND r.ativa = 1 SET f.usuario_id = c.usuario_id, f.ruta_id = r.id WHERE f.usuario_id IS NULL OR f.ruta_id IS NULL");
        echo "  OK     fotos usuario_id/ruta_id preenchidos\n";
    }

    if (mig_tableExists($db, 'fotos') && mig_colExists($db, 'fotos', 'imagem_base64')) {
        $db->exec("UPDATE `fotos` SET `imagem_base64` = `label` WHERE `label` LIKE 'data:image/%' AND (`imagem_base64` IS NULL OR `imagem_base64` = '')");
        $db->exec("UPDATE `fotos` SET `label` = 'Foto Importada' WHERE `imagem_base64` LIKE 'data:image/%' AND `label` LIKE 'data:image/%'");
        echo "  OK     fotos.imagem_base64 migrado do campo label\n";
    }

    // ── PASSO 3: ENUM movimentacoes.tipo ─────────────────────────
    echo "\nPASSO 3 — Verificando ENUM movimentacoes.tipo...\n";
    if (mig_tableExists($db, 'movimentacoes') && mig_colExists($db, 'movimentacoes', 'tipo')) {
        $st = $db->query("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'movimentacoes' AND COLUMN_NAME = 'tipo'");
        $colType = $st->fetchColumn();
        if ($colType && stripos($colType, 'enum') !== false && stripos($colType, 'despesa') === false) {
            $db->exec("ALTER TABLE `movimentacoes` MODIFY `tipo` ENUM('pagamento','emprestimo','multa','aporte','retirada','ajuste','despesa') NOT NULL");
            echo "  OK     movimentacoes.tipo expandido para incluir 'despesa'\n";
        } else {
            echo "  -      movimentacoes.tipo ja aceita 'despesa' ou e VARCHAR\n";
        }
    }

    // ── PASSO 4: Índices de performance ──────────────────────────
    echo "\nPASSO 4 — Criando indices de performance...\n";
    mig_addIdx($db, 'vendas',        'idx_vendas_ruta_id',       '`ruta_id`');
    mig_addIdx($db, 'vendas',        'idx_vendas_criado',        '`criado_em`');
    mig_addIdx($db, 'vendas',        'idx_vendas_tipo',          '`tipo`');
    mig_addIdx($db, 'parcelas',      'idx_parcelas_usuario_id',  '`usuario_id`');
    mig_addIdx($db, 'parcelas',      'idx_parcelas_ruta_id',     '`ruta_id`');
    mig_addIdx($db, 'parcelas',      'idx_parc_venc',            '`data_vencimento`');
    mig_addIdx($db, 'parcelas',      'idx_parc_pag',             '`data_pagamento`');
    mig_addIdx($db, 'pagamentos',    'idx_pagamentos_usuario_id','`usuario_id`');
    mig_addIdx($db, 'pagamentos',    'idx_pagamentos_ruta_id',   '`ruta_id`');
    mig_addIdx($db, 'pagamentos',    'idx_pag_data',             '`data`');
    mig_addIdx($db, 'multas',        'idx_multas_usuario_id',    '`usuario_id`');
    mig_addIdx($db, 'multas',        'idx_multas_ruta_id',       '`ruta_id`');
    mig_addIdx($db, 'fotos',         'idx_fotos_usuario_id',     '`usuario_id`');
    mig_addIdx($db, 'fotos',         'idx_fotos_ruta_id',        '`ruta_id`');
    mig_addIdx($db, 'clientes',      'idx_clientes_criado',      '`criado_em`');
    mig_addIdx($db, 'movimentacoes', 'idx_mov_data_tipo',        '`ruta_id`,`data_mov`,`tipo`');

    echo "\n" . str_repeat('=', 55) . "\n";
    echo "MIGRACAO CONCLUIDA COM SUCESSO.\n";
    echo "APAGUE este arquivo do servidor agora:\n";
    echo "  00_RODAR_MIGRACAO_SEGURA.php\n";
    echo str_repeat('=', 55) . "\n";

} catch (Throwable $e) {
    echo "\nERRO NA MIGRACAO:\n" . htmlspecialchars($e->getMessage()) . "\n";
    echo "\nVerifique as credenciais do banco em shared/db.php e tente novamente.\n";
}
echo '</pre>';
