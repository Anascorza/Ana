# Implementação do Histórico de Parcelas

Foi adicionada uma visualização de **Histórico de Parcelas por venda**, preservando a tabela atual de vendas e os cálculos existentes.

## Alterações

| Arquivo | Alteração |
|---|---|
| `src/InstallmentHistoryQuery.php` | Nova consulta que vincula parcelas e pagamentos à venda, exclui domingos, soma pagamentos por data, identifica pagamentos parciais e calcula a classificação acumulada. |
| `public/admin/sales.php` | Botão “Ver histórico” em cada venda e tela detalhada com registros cronológicos. |
| `public/admin/assets/admin.css` | Estilos para os estados Pago, Pendente, Não pagou e classificações verde, amarela e vermelha. |

A classificação considera somente a venda aberta: até 3 registros “Não pagou” fica normal/verde; de 4 a 5 fica amarela; com 6 ou mais fica vermelha. A regra não depende de consecutividade e não altera multas.

## Validação

Os dois arquivos PHP alterados passaram na validação de sintaxe. O pacote original contém um erro de sintaxe preexistente em `public/admin/route.php`, na linha 8, que impede a validação global do projeto e deve ser corrigido separadamente antes da publicação.

A execução funcional contra dados reais não foi possível porque o pacote não inclui banco local nem credenciais de conexão; a aplicação usa MySQL e dados sincronizados em `sb_sync_records`.
