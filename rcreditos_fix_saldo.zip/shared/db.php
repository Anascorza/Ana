<?php
/**
 * R. Créditos — Configuração de Banco de Dados (Compartilhado)
 * ════════════════════════════════════════════════════════════════
 *
 * ⚠️  CREDENCIAIS PREENCHIDAS — PRONTO PARA INFINITYFREE
 *
 * Este arquivo é compartilhado pelos dois sistemas.
 * O if(!defined) garante que nunca haverá conflito de constantes.
 *
 * ❌ NUNCA use "localhost" no InfinityFree — use o host SQL fornecido!
 */

if (!defined('DB_HOST'))    define('DB_HOST',    'sql302.infinityfree.com');
if (!defined('DB_NAME'))    define('DB_NAME',    'if0_41425409_Rcreditos');
if (!defined('DB_USER'))    define('DB_USER',    'if0_41425409');
if (!defined('DB_PASS'))    define('DB_PASS',    'hollaphy');
if (!defined('DB_CHARSET')) define('DB_CHARSET', 'utf8mb4');

// Fuso oficial do sistema: horário de Brasília (UTC-03:00).
// A definição aqui cobre também o painel administrativo, que compartilha esta conexão.
date_default_timezone_set('America/Sao_Paulo');

/**
 * Singleton PDO — conexão única e reutilizada em toda a requisição
 */
function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $opt = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // IMPORTANTE: precisa ser true. Várias queries do sistema (ex.: route.resumo)
            // reutilizam o mesmo placeholder nomeado (ex.: :data) mais de uma vez na
            // mesma consulta. Com prepares nativos (false) o MySQL rejeita isso com
            // SQLSTATE[HY093]: Invalid parameter number. Emulando o prepare no PHP,
            // o PDO resolve os placeholders repetidos antes de enviar ao servidor.
            PDO::ATTR_EMULATE_PREPARES   => true,
            PDO::ATTR_TIMEOUT            => 15,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opt);
            // Mantém NOW(), CURDATE() e demais funções temporais do MySQL
            // alinhadas ao horário de Brasília, independentemente do servidor.
            $pdo->exec("SET time_zone = '-03:00'");
        } catch (PDOException $e) {
            error_log('[DB CONNECTION ERROR] host=' . DB_HOST . ' db=' . DB_NAME . ' | ' . $e->getMessage());
            http_response_code(500);

            // Se a chamada veio de uma API (JSON), retorna JSON de erro
            $isApi = strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false
                  || strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false
                  || strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

            if ($isApi) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'sucesso'  => false,
                    'mensagem' => 'Erro de conexão com o banco de dados.',
                    'dados'    => null,
                ]);
                exit;
            }

            die('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
                <title>Erro de Conexão</title>
                <style>
                  body{font-family:sans-serif;background:#0f1117;color:#eef0f3;
                  display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
                  .box{background:#161920;border:1px solid #363b47;border-radius:12px;
                  padding:40px;max-width:500px;text-align:center}
                  h2{color:#e85656;margin-bottom:12px}
                  code{color:#f5b731;display:block;background:#0f1117;
                  padding:6px 12px;border-radius:6px;margin:6px 0;font-size:13px}
                  p{color:#8b929e;font-size:14px;margin:8px 0;line-height:1.5}
                </style></head>
                <body><div class="box">
                <h2>⚠ Erro de conexão com o banco</h2>
                <p>Verifique as credenciais em <code>shared/db.php</code></p>
                <p>Host configurado:</p>
                <code>' . htmlspecialchars(DB_HOST) . '</code>
                <p>Banco configurado:</p>
                <code>' . htmlspecialchars(DB_NAME) . '</code>
                <p>No InfinityFree, nunca use <strong>"localhost"</strong> — use o host SQL do painel.</p>
                </div></body></html>');
        }
    }
    return $pdo;
}
?>
