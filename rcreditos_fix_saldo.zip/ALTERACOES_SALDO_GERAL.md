# Correção da Fórmula do Saldo Geral Acumulado

## Data da Alteração
20 de julho de 2026

## Objetivo
Corrigir a fórmula do Saldo Geral Acumulado para usar **obrigatoriamente apenas** os quatro valores especificados, sem incluir multas, parcelas em aberto, juros, previsões ou qualquer outro campo.

## Fórmula Corrigida
```
Saldo Geral Acumulado = Valor Investido + Total de Aportes + Total Recolhido da Rua - Total Emprestado
```

### Componentes:
- **Valor Investido**: `capital_base` (valor inicial investido na ruta)
- **Total de Aportes**: Soma de todas as movimentações com `tipo='aporte'`
- **Total Recolhido da Rua**: Valor absoluto da soma de todas as movimentações com `tipo='retirada'`
- **Total Emprestado**: Valor absoluto da soma de todas as movimentações com `tipo='emprestimo'`

## Arquivos Alterados

### 1. `/admin/includes/config.php`
**Função**: `getLucrosRutas()` (linhas 145-171)
- **Alteração**: Adicionado comentário documentando a fórmula fixa
- **Campo afetado**: `lucro_liquido` (agora chamado de Saldo Geral Acumulado)
- **Status**: ✅ Fórmula já estava correta, apenas documentado

### 2. `/admin/index.php`
**Seção**: Dashboard geral (linhas 7-56)
- **Alteração**: Adicionado comentário explicativo sobre a fórmula
- **Campos afetados**: `lucro_total` (agregado de todas as rutas)
- **Status**: ✅ Fórmula já estava correta, apenas documentado

### 3. `/admin/pages/ruta_detalhe.php`
**Seção**: Métricas consolidadas (linhas 18-33)
- **Alteração**: Adicionado comentário documentando a fórmula fixa
- **Campo afetado**: `lucro_liquido` (detalhe de uma ruta específica)
- **Status**: ✅ Fórmula já estava correta, apenas documentado

### 4. `/app/api/index.php`
**Rota**: `route.resumo` (linhas 1387-1392)
- **Status**: ✅ Já estava correto! Nenhuma alteração necessária

## Atualização Automática

O Saldo Geral Acumulado é **recalculado automaticamente** sempre que ocorrem:

1. **Novos Empréstimos** → Reduz o saldo (subtraído)
2. **Recolhimentos/Retiradas** → Aumenta o saldo (adicionado)
3. **Aportes** → Aumenta o saldo (adicionado)

Isso é garantido porque:
- A tabela `movimentacoes` é a fonte de verdade para todos os cálculos
- Cada operação (empréstimo, aporte, retirada) registra uma movimentação
- As queries SQL agregam os dados em tempo real da tabela `movimentacoes`

## Campos NÃO Inclusos

Os seguintes campos foram **explicitamente excluídos** da fórmula:
- ❌ Multas (`tipo='multa'`)
- ❌ Parcelas em aberto
- ❌ Juros
- ❌ Previsões
- ❌ Pagamentos (`tipo='pagamento'`)
- ❌ Despesas (`tipo='despesa'`)
- ❌ Ajustes (`tipo='ajuste'`)

Estes campos são usados para calcular **lucro/rendimento**, não o saldo de capital.

## Validação

Todas as três interfaces foram verificadas:
- ✅ Painel Admin Dashboard
- ✅ Detalhe de Ruta (Admin)
- ✅ Dashboard do Operador (App)

## Notas Importantes

1. A fórmula é **acumulativa** — reflete o capital total disponível na ruta
2. Não inclui movimentações de lucro (pagamentos e multas)
3. Permanece consistente entre Admin e App
4. Atualiza em tempo real conforme novos registros são adicionados

---

**Desenvolvedor**: Sistema RCreditos PWA v2.1.1
**Compatibilidade**: PHP 7.2+ | MySQL 5.7+
