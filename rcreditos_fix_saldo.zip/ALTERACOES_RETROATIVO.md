# Separação: Pagamentos Operacionais vs. Ajustes Retroativos

## Objetivo

Registros de pagamento cujo campo `motivo` contenha termos como **"Ajuste retroativo"**, **"Reconciliação"**, **"Correção histórica"** ou **"retroativo"** são agora tratados exclusivamente como **regularizações do banco de dados**. Eles continuam abatendo corretamente o saldo da venda e participando dos cálculos financeiros (total pago, total em aberto), mas **não** são considerados movimentação operacional.

---

## Regras de Exclusão

| Critério | Comportamento |
|---|---|
| Abater saldo da venda | **Sim** — continua funcionando normalmente |
| Cálculos financeiros (total pago, total em aberto) | **Sim** — continuam incluídos |
| Aparecer na tela de Movimentações (admin) | **Não** |
| Aparecer no Resumo da Rota (operador) | **Não** |
| Entrar no Caixa do dia | **Não** |
| Ser contabilizado como recebimento do operador | **Não** |
| Alterar estatísticas diárias | **Não** |
| Aparecer no painel/histórico do operador | **Não** |

---

## Arquivos Alterados

### 1. `app/api/index.php` — Backend principal

#### Helper `isRetroativo()` e `retroativoSql()` (linhas ~240-273)

Novas funções utilitárias:

- **`isRetroativo(?string $motivo)`** — retorna `true` se o motivo contiver qualquer keyword retroativa (case-insensitive via `mb_stripos`).
- **`retroativoSql(string $alias = 'p')`** — retorna um fragmento SQL seguro com `COALESCE(alias.motivo, '') NOT LIKE '%keyword%'` para cada keyword, combinado com `AND`.

Keywords detectadas: `Ajuste retroativo`, `Reconciliação`, `Correção histórica`, `ajuste retroativo`, `reconciliação`, `correção histórica`, `retroativo`.

#### `pagamentos.salvar` (linha ~905)

Quando o pagamento é retroativo, a chamada a `registrarMovimentacao()` é **pulada**. O pagamento é inserido na tabela `pagamentos` normalmente, mas não gera registro em `movimentacoes`.

```php
if (!isRetroativo($d['motivo'] ?? null)) {
    registrarMovimentacao(...);
}
```

#### `pagamentos.listar` (linha ~836)

Adiciona `AND retroativoSql('p')` na WHERE para excluir pagamentos retroativos da listagem retornada ao operador (painel, histórico).

#### `ruta.get` — `recebido_hoje` e `pagamentos_hoje` (linha ~1188)

Adiciona `AND retroativoSql('p')` na query de pagamento do dia para não contar retroativos como recebimento do operador.

#### `route.resumo` — `totalRecebido` (linha ~1354)

Adiciona `AND retroativoSql('p')` na query de total recebido do dia, excluindo retroativos do caixa e da eficiência de cobrança.

#### `route.resumo` — `jurosRecebidosHoje` (linha ~1391)

Adiciona `AND retroativoSql('p')` na query de juros recebidos hoje, excluindo retroativos.

#### `route.resumo` — Financeiro via `movimentacoes` (linha ~1331)

Adiciona filtro `AND (tipo != 'pagamento' OR COALESCE(descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(descricao, '') NOT LIKE '%retroativo%')` para defesa em profundidade caso alguma movimentação antiga tenha sido registrada antes desta alteração.

#### `dashboard.dados` — `total_recebido_hoje` (linha ~1668)

Adiciona `AND retroativoSql('p')` na subquery de total recebido hoje do dashboard.

---

### 2. `admin/includes/config.php` — Helpers administrativos

#### `getLucrosRutas()` (linha ~173)

Adiciona filtro na JOIN com `movimentacoes` para excluir movimentações de pagamento retroativo dos totais de ranking.

#### `getLucroHoje()` (linha ~195)

Adiciona filtro na JOIN com `movimentacoes` para excluir retroativos do lucro hoje.

#### `getLucroSemana()` (linha ~216)

Adiciona filtro na JOIN com `movimentacoes` para excluir retroativos do lucro da semana.

#### `getLucroMes()` (linha ~238)

Adiciona filtro na JOIN com `movimentacoes` para excluir retroativos do lucro do mês.

---

### 3. `admin/index.php` — Dashboard admin

#### `$totais` (linha ~28)

Adiciona filtro na LEFT JOIN com `movimentacoes` para excluir retroativos.

#### `$ultimas` — Últimas 10 movimentações (linha ~78)

Adiciona filtro WHERE para excluir retroativos da lista de movimentações recentes.

---

### 4. `admin/pages/movimentacoes.php` — Tela de Movimentações

#### `$whereStr` (linha ~24)

Adiciona filtro WHERE para excluir retroativos de ambas as queries (listagem e totais), já que ambas usam `$whereStr`.

---

### 5. `admin/pages/ruta_detalhe.php` — Detalhe da Ruta

#### `$metricas` (linha ~37)

Adiciona filtro WHERE para excluir retroativos das métricas consolidadas da ruta.

#### `$recebidoHoje` (linha ~43)

Adiciona filtros explícitos `NOT LIKE` sobre `p.motivo` para excluir retroativos do total recebido hoje da ruta.

#### `$whereStr` de movimentações (linha ~99)

Adiciona filtro WHERE para excluir retroativos da listagem e totais de movimentações da ruta.

---

## O que NÃO foi alterado (intencionalmente)

| Consulta | Motivo |
|---|---|
| `totalPagoPelosClientes` em `route.resumo` | Deve incluir retroativos pois abate corretamente o saldo da venda |
| `total_a_receber` em `ruta.get` | Deve incluir retroativos pois reflete o saldo real devedor |
| `total_recebido` em `ruta.get` | Deve incluir retroativos pois reflete o total acumulado recebido |
| `pagamentos.registrar_transacional` | É um pagamento normal do operador, sem campo motivo |
| `vendas.listar` / `vendas.buscar` / `vendas.porCliente` | Não fazem referência direta a pagamentos |
| `parcelas.*` | Parcelas são estrutura de dívida, não dependem de pagamentos |
| `multas.*` | Multas são entidades independentes |

---

---

## Correção: Consistência Financeira (Total Recebido + Total em Aberto)

### Problema

Antes desta alteração, o campo **"Total de Parcelas Recebidas"** (`totalParcelasRecebidas`) no Resumo Geral era calculado a partir da tabela `movimentacoes` (tipo='pagamento'), que agora exclui pagamentos retroativos. Porém, o **"Total em Aberto"** (`totalAReceber`) é calculado a partir da tabela `pagamentos`, que inclui retroativos.

Isso criava uma inconsistência: **Total Emprestado + Juros ≠ Total Recebido + Total em Aberto**.

Exemplo do usuário: Empréstimo de 10600 a 30% (total = 13780), Total em Aberto = 7164, Total Recebido = 6723. A soma dava 13887, mas deveria ser 13780. A diferença de 107 reais era exatamente o valor dos pagamentos retroativos.

### Solução

Agora ambos os campos são calculados diretamente da tabela **`pagamentos`** (tipo='pagamento'), que é a fonte de verdade financeira:

- **`totalParcelasRecebidas`**: `SUM(valor_pago)` da tabela `pagamentos` onde `tipo = 'pagamento'` (incluindo retroativos).
- **`totalJuros`** (Total de Juros Recebidos): Calculado proporcionalmente usando `valor_pago * (juros_valor / total_com_juros)` para cada pagamento, também direto da tabela `pagamentos` (incluindo retroativos).

### Resultado

A equação agora sempre bate:

**Total Emprestado + Juros Contratados = Total de Parcelas Recebidas + Total em Aberto**

No exemplo do usuário:
- Total Emprestado + Juros = 10600 + 3180 = **13780**
- Total Recebido + Total em Aberto = 7057 + 6723 = **13780** ✓

---

## Estratégia de Defesa em Profundidade

O sistema usa **duas camadas** de proteção:

1. **Camada 1 (prevenção)**: `pagamentos.salvar` não registra movimentação quando o pagamento é retroativo. Novos retroativos nunca geram registro em `movimentacoes`.

2. **Camada 2 (filtro SQL)**: Todas as queries que consomem `movimentacoes` ou `pagamentos` incluem cláusulas `NOT LIKE '%Retroativo%'` como defesa contra registros legados que possam ter sido criados antes desta alteração.

3. **Camada 3 (frontend)**: O endpoint `pagamentos.listar` já filtra retroativos no backend, então o painel e o histórico do operador automaticamente não exibem esses registros.
