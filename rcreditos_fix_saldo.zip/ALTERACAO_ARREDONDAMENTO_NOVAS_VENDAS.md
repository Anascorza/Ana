# Arredondamento oficial de novas vendas

A criação de novas vendas agora usa a seguinte regra financeira única:

> Valor da parcela = teto(Total calculado com juros ÷ quantidade de parcelas).
>
> Total oficial do contrato = Valor da parcela × quantidade de parcelas.

O valor da parcela é inteiro e sempre arredondado para cima. Assim, R$ 650 ÷ 20 resulta em parcela de R$ 33 e total oficial de R$ 660; R$ 1.040 ÷ 24 resulta em parcela de R$ 44 e total oficial de R$ 1.056; e R$ 390 ÷ 3 permanece em R$ 130 por parcela e R$ 390 no total.

A API recalcula e valida a regra antes do `INSERT`, usando comparação em centavos para impedir divergências de ponto flutuante. O dashboard aplica a mesma regra antes do envio e a geração de parcelas reutiliza o total oficial e o valor da parcela já persistidos, sem recalcular valores decimais.

A regra de edição financeira somente é aplicada a contratos criados a partir de **17/08/2026**, data de publicação desta alteração. Contratos anteriores permanecem com seus valores históricos. Os cálculos derivados já utilizam `total_com_juros`, `valor_parcela`, `valor_pago` e os campos persistidos, portanto passam a refletir automaticamente o novo total oficial em saldos, totais em aberto, percentuais, ruta, dashboard, relatórios e fechamento.

## Validação executada

A API passou no `php -l`. O JavaScript extraído do dashboard passou no `node --check`. Também foram validados os exemplos solicitados e um caso com juros: R$ 1.000 com 10% em 3 parcelas resulta em R$ 367 por parcela e R$ 1.101 de total oficial.
