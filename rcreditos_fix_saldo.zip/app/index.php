<?php
/**
 * R. Créditos — Ponto de entrada do App (operadores)
 */
require_once __DIR__ . '/config/app.php';

if (isAuthenticated()) {
    header('Location: ' . BASE_URL . '/app/pages/dashboard.php');
} else {
    header('Location: ' . BASE_URL . '/app/auth/login.php');
}
exit;
