<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * R. CRÉDITOS — Guard de Autenticação (JWT + Sessão)
 * Versão: 2.1.0 (CORRIGIDA)
 * ════════════════════════════════════════════════════════════════════════════
 */

/**
 * Verificar se o usuário está autenticado via JWT (header) ou Sessão
 */
function isAuthenticated(): bool {
    // 1. Tenta JWT no Header Authorization (prioridade — usado pelo dashboard)
    $authHeader = '';
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    if (empty($authHeader)) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    }

    if (!empty($authHeader) && strpos($authHeader, 'Bearer ') === 0) {
        $token = substr($authHeader, 7);
        if (empty($token)) return false;

        try {
            $payload = JWT::decode($token);
            if (!$payload) return false;

            // Verifica se token foi revogado (logout)
            try {
                $db = getDB();
                $stmt = $db->prepare('SELECT id FROM tokens_invalidados WHERE token_hash = ? LIMIT 1');
                $stmt->execute([hash('sha256', $token)]);
                if ($stmt->fetch()) return false;
            } catch (Exception $e) {
                // Se a tabela não existir, ignora a verificação
                error_log('[GUARD] tokens_invalidados check failed: ' . $e->getMessage());
            }

            // Popula sessão temporária para que currentUser() funcione
            $_SESSION['jwt_payload'] = $payload;
            $_SESSION['jwt_token']   = $token;
            return true;

        } catch (Exception $e) {
            error_log('[GUARD JWT ERROR] ' . $e->getMessage());
            return false;
        }
    }

    // 2. Fallback: Sessão Tradicional (login HTML direto)
    if (empty($_SESSION['usuario_id'])) return false;

    // Verifica expiração
    if (!empty($_SESSION['last_activity']) &&
        (time() - $_SESSION['last_activity']) > SESSION_LIFETIME) {
        session_unset();
        session_destroy();
        return false;
    }

    $_SESSION['last_activity'] = time();
    return true;
}

function isAppAuthenticated() { return isAuthenticated(); }

/**
 * Exige autenticação ou retorna 401 (API) / redireciona (HTML)
 */
function requireAuth(): void {
    if (!isAuthenticated()) {
        $isApi = strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false
              || strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false
              || strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

        if ($isApi) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(401);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Token inválido ou expirado', 'dados' => null]);
            exit;
        }

        header('Location: ' . BASE_URL . '/app/auth/login.php');
        exit;
    }
}

function requireAppAuth() { requireAuth(); }

/**
 * Redireciona para dashboard se já autenticado
 */
function redirectIfAuthenticated(): void {
    if (isAuthenticated()) {
        header('Location: ' . BASE_URL . '/app/pages/dashboard.php');
        exit;
    }
}

function redirectIfAppAuthenticated() { redirectIfAuthenticated(); }

/**
 * Retorna os dados do usuário atual (JWT ou Sessão)
 */
function currentUser(): ?array {
    if (!isAuthenticated()) return null;

    // Via JWT (prioridade)
    if (!empty($_SESSION['jwt_payload'])) {
        $p = $_SESSION['jwt_payload'];
        return [
            'id'        => $p['usuario_id'],
            'nome'      => $p['nome']     ?? '',
            'email'     => $p['email']    ?? '',
            'tipo'      => $p['tipo']     ?? '',
            'admin_id'  => $p['admin_id'] ?? null,
            'auth_type' => 'jwt',
        ];
    }

    // Via Sessão Tradicional
    return [
        'id'        => $_SESSION['usuario_id'],
        'nome'      => $_SESSION['usuario_nome']  ?? '',
        'email'     => $_SESSION['usuario_email'] ?? '',
        'tipo'      => $_SESSION['usuario_tipo']  ?? '',
        'admin_id'  => $_SESSION['admin_id'] ?? $_SESSION['usuario_admin_id'] ?? null,
        'auth_type' => 'session',
    ];
}
?>
