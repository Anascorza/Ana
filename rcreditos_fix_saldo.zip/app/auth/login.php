<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * R. CRÉDITOS — Login com JWT
 * CORRIGIDO: Login via fetch JSON → salva token → redireciona
 * ════════════════════════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config/app.php';

// ── Fluxo JSON (fetch do frontend) ───────────────────────────────
$isJson = (strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false);

if ($isJson) {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    $email = trim($input['email'] ?? '');
    $senha = trim($input['senha'] ?? '');

    if (!$email || !$senha) {
        resposta(false, 'E-mail e senha são obrigatórios', null, 400);
    }

    try {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($senha, $user['senha'])) {
            JWT::setSecret(JWT_SECRET);
            $token = gerarToken($user, JWT_EXPIRATION);

            // Salva também na sessão (fallback)
            if (session_status() === PHP_SESSION_NONE) session_start();
            session_regenerate_id(true);
            $_SESSION['usuario_id']    = $user['id'];
            $_SESSION['usuario_nome']  = $user['nome'];
            $_SESSION['usuario_email'] = $user['email'];
            $_SESSION['usuario_tipo']  = $user['tipo'];
            $_SESSION['admin_id']      = $user['admin_id'];
            $_SESSION['last_activity'] = time();

            registrarTentativaLogin($email, true, null, $db);

            resposta(true, 'Login realizado com sucesso', [
                'token' => $token,
                'usuario' => [
                    'id'       => $user['id'],
                    'nome'     => $user['nome'],
                    'email'    => $user['email'],
                    'tipo'     => $user['tipo'],
                    'admin_id' => $user['admin_id'],
                ],
            ]);
        } else {
            registrarTentativaLogin($email, false, 'Credenciais inválidas', $db);
            resposta(false, 'E-mail ou senha incorretos', null, 401);
        }
    } catch (Exception $e) {
        error_log('[LOGIN ERROR] ' . $e->getMessage());
        resposta(false, 'Erro interno no servidor', null, 500);
    }
}

// ── Redireciona se já autenticado ────────────────────────────────
redirectIfAppAuthenticated();

$erro = '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta name="theme-color" content="#0f1117"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-title" content="R. Créditos"/>
<title>R. Créditos — Entrar</title>
<link rel="manifest" href="<?= BASE_URL ?>/manifest.webmanifest">
<link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>/assets/icons/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>/assets/icons/apple-touch-icon.png">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg-base:#0f1117;--bg-surface:#161920;--bg-input:#252830;--border-strong:#363b47;
  --accent:#4f8ef7;--accent-hover:#3a7ae6;--accent-dim:rgba(79,142,247,.13);
  --red:#e85656;--red-dim:rgba(232,86,86,.12);
  --text-primary:#eef0f3;--text-secondary:#8b929e;--text-muted:#50565f;
  --font:'Noto Sans', sans-serif;--radius-sm:6px;
}
html,body{height:100%;font-family:var(--font);background:var(--bg-base);color:var(--text-primary);}
body{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.card{background:var(--bg-surface);border:1px solid var(--border-strong);border-radius:16px;
  width:100%;max-width:400px;padding:36px 32px;box-shadow:0 8px 48px rgba(0,0,0,.6);}
.logo-area{display:flex;flex-direction:column;align-items:center;gap:12px;margin-bottom:32px;}
.logo-sub{font-size:11px;font-weight:600;color:var(--text-muted);letter-spacing:1px;text-transform:uppercase;}
.title{font-size:20px;font-weight:800;text-align:center;margin-bottom:4px;}
.subtitle{font-size:13px;color:var(--text-muted);text-align:center;margin-bottom:24px;}
.form-group{display:flex;flex-direction:column;gap:6px;margin-bottom:14px;}
.form-group label{font-size:11px;font-weight:700;color:var(--text-secondary);letter-spacing:.3px;text-transform:uppercase;}
input{width:100%;background:var(--bg-input);color:var(--text-primary);border:1px solid var(--border-strong);
  border-radius:var(--radius-sm);padding:12px 14px;font-size:14px;font-family:var(--font);
  outline:none;transition:border-color .15s,box-shadow .15s;}
input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-dim);}
input:disabled{opacity:.6;cursor:not-allowed;}
.btn{width:100%;color:#fff;font-weight:700;font-size:15px;padding:13px;border-radius:var(--radius-sm);
  border:none;cursor:pointer;font-family:var(--font);transition:background .15s,opacity .15s;margin-top:8px;}
.btn-primary{background:var(--accent);}
.btn-primary:hover:not(:disabled){background:var(--accent-hover);}
.btn-primary:disabled{opacity:.6;cursor:not-allowed;}
.alerta{border-radius:var(--radius-sm);padding:10px 14px;font-size:13px;font-weight:600;margin-bottom:14px;}
.alerta-erro{background:var(--red-dim);border:1px solid rgba(232,86,86,.3);color:var(--red);}
.link-cadastro{display:block;text-align:center;font-size:13px;color:var(--text-secondary);margin-top:20px;}
.link-cadastro a{color:var(--accent);text-decoration:none;font-weight:600;}
</style>
</head>
<body>
<div class="card">
  <div class="logo-area">
    <span class="logo-sub">R. Créditos</span>
  </div>

  <div class="title">Bem-vindo</div>
  <div class="subtitle">Entre com suas credenciais para acessar</div>

  <div class="alerta alerta-erro" id="erro-msg" style="display:none"></div>

  <div id="form-login">
    <div class="form-group">
      <label>E-mail</label>
      <input type="email" id="campo-email" placeholder="seu@email.com" required autofocus/>
    </div>
    <div class="form-group">
      <label>Senha</label>
      <input type="password" id="campo-senha" placeholder="••••••••" required/>
    </div>
    <button type="button" class="btn btn-primary" id="btn-entrar" onclick="fazerLogin()">Entrar</button>
  </div>

  <p class="link-cadastro">
    Não tem conta? <a href="<?= BASE_URL ?>/app/auth/cadastro.php">Criar cadastro via Vínculo</a>
  </p>
</div>

<script>
// ════════════════════════════════════════════════════════
// LOGIN VIA FETCH JSON → SALVA JWT → REDIRECIONA
// CORRIGIDO: garante que o token seja salvo antes de ir ao dashboard
// ════════════════════════════════════════════════════════
const BASE_URL = '<?= BASE_URL ?>';

async function fazerLogin() {
  const email = document.getElementById('campo-email').value.trim();
  const senha = document.getElementById('campo-senha').value;
  const btn   = document.getElementById('btn-entrar');
  const erroEl = document.getElementById('erro-msg');

  erroEl.style.display = 'none';

  if (!email || !senha) {
    mostrarErro('Preencha e-mail e senha.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Entrando…';

  try {
    const res = await fetch(window.location.href, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, senha }),
    });

    let json;
    try {
      json = await res.json();
    } catch(e) {
      mostrarErro('Erro de resposta do servidor. Tente novamente.');
      btn.disabled = false;
      btn.textContent = 'Entrar';
      return;
    }

    if (json.sucesso && json.dados && json.dados.token) {
      // Salva o token JWT no sessionStorage
      sessionStorage.setItem('rc_token', json.dados.token);
      // Salva também dados do usuário (útil para exibir nome)
      sessionStorage.setItem('rc_usuario', JSON.stringify(json.dados.usuario));
      // Redireciona para o dashboard
      window.location.href = BASE_URL + '/app/pages/dashboard.php';
    } else {
      mostrarErro(json.mensagem || 'E-mail ou senha incorretos.');
      btn.disabled = false;
      btn.textContent = 'Entrar';
    }
  } catch(err) {
    console.error('Erro de rede:', err);
    mostrarErro('Erro de conexão. Verifique sua internet e tente novamente.');
    btn.disabled = false;
    btn.textContent = 'Entrar';
  }
}

function mostrarErro(msg) {
  const el = document.getElementById('erro-msg');
  el.textContent = '⚠ ' + msg;
  el.style.display = 'block';
}

// Enter nos campos dispara o login
document.addEventListener('DOMContentLoaded', () => {
  ['campo-email','campo-senha'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.key === 'Enter') fazerLogin();
    });
  });
});
</script>
</body>
</html>
