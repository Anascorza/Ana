<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * R. CRÉDITOS — Cadastro de Operador via Vínculo (SISTEMA BRANCO)
 * ════════════════════════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config/app.php';

// Redirecionar se já autenticado
redirectIfAppAuthenticated();

$erro    = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome           = trim($_POST['nome']           ?? '');
    $email          = trim($_POST['email']          ?? '');
    $senha          = $_POST['senha']               ?? '';
    $conf           = $_POST['senha_confirma']      ?? '';
    $codigo_vinculo = trim($_POST['codigo_vinculo']  ?? '');

    // ── Validações ──────────────────────────────────────────────
    if (!$nome || !$email || !$senha || !$conf || !$codigo_vinculo) {
        $erro = 'Todos os campos são obrigatórios.';
    } elseif (strlen($nome) < 2 || strlen($nome) > 150) {
        $erro = 'O nome deve ter entre 2 e 150 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($senha !== $conf) {
        $erro = 'As senhas não coincidem.';
    } else {
        try {
            $db = getDB();

            // 1. Validar Código de Vínculo — busca em usuarios.codigo_vinculo
            //    (gerado pelo Sistema Branco em usuarios, NÃO em rutas)
            $stAdmin = $db->prepare(
                'SELECT id, nome as admin_nome FROM usuarios WHERE codigo_vinculo = ? AND tipo = "admin" AND ativo = 1 LIMIT 1'
            );
            $stAdmin->execute([$codigo_vinculo]);
            $admin = $stAdmin->fetch();

            if (!$admin) {
                $erro = 'Código de vinculação inválido ou expirado. Solicite um novo ao seu administrador.';
            } else {
                // O admin_id é o ID do usuário que gerou o código de vínculo (que é um admin)
                $adminIdDoVinculo = $admin['id'];
                // 2. Verificar se e-mail já existe
                $check = $db->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
                $check->execute([$email]);
                if ($check->fetch()) {
                    $erro = 'Este e-mail já está cadastrado no sistema.';
                } else {
                    // 3. Criar Operador (Inativo até vincular)
                    $hash = password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
                    
                    // Iniciar transação para garantir integridade
                    $db->beginTransaction();

                    // Criar usuário operador vinculado ao admin
                    $stmt = $db->prepare(
                        'INSERT INTO usuarios (nome, email, senha, tipo, admin_id, ativo) VALUES (?, ?, ?, "operador", ?, 1)'
                    );
                    $stmt->execute([$nome, $email, $hash, $admin['id']]);
                    $newUserId = $db->lastInsertId();

                    // 4. Criar Registro de Vínculo
                    $nome_ruta_padrao = "Ruta - " . $nome;
                    
                    $stVinculo = $db->prepare('
                        INSERT INTO vinculacoes (admin_id, usuario_id, codigo_vinculo_usado, nome_ruta, status, ip_vinculacao, user_agent_vinculacao)
                        VALUES (?, ?, ?, ?, "ativo", ?, ?)
                    ');
                    $stVinculo->execute([
                        $admin['id'], 
                        $newUserId, 
                        $codigo_vinculo, 
                        $nome_ruta_padrao,
                        $_SERVER['REMOTE_ADDR'] ?? null,
                        $_SERVER['HTTP_USER_AGENT'] ?? null
                    ]);
                    $vinculoId = $db->lastInsertId();

                    // 5. Criar a Ruta correspondente para o operador (Schema v8.1)
                    // Bug fix: Adicionar admin_id à tabela rutas para que as listagens funcionem corretamente
                    $stRuta = $db->prepare('
                        INSERT INTO rutas (usuario_id, admin_id, nome, ativa)
                        VALUES (?, ?, ?, 1)
                    ');
                    $stRuta->execute([
                        $newUserId,
                        $admin['id'], // Adiciona o admin_id aqui
                        $nome_ruta_padrao
                    ]);


                    $db->commit();

                    // Registrar Log
                    logAcao('CADASTRO_OPERADOR', "Operador $nome cadastrado e vinculado ao admin " . $admin['admin_nome'], 'usuarios', $newUserId);

                    $sucesso = 'Cadastro realizado com sucesso! Você já pode entrar.';
                    
                    // Redirecionar para login após 3 segundos
                    header('Refresh: 3; url=' . BASE_URL . '/app/auth/login.php');
                }
            }
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $erro = 'Erro ao processar cadastro: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta name="theme-color" content="#0f1117"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-title" content="R. Créditos"/>
<title>R. Créditos — Cadastro de Operador</title>
<link rel="manifest" href="<?= BASE_URL ?>/manifest.webmanifest">
<link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>/assets/icons/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>/assets/icons/apple-touch-icon.png">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg-base:#0f1117;--bg-surface:#161920;
  --bg-input:#252830;--border-strong:#363b47;
  --accent:#4f8ef7;--accent-hover:#3a7ae6;--accent-dim:rgba(79,142,247,.13);
  --red:#e85656;--red-dim:rgba(232,86,86,.12);
  --green:#4fbe87;--green-dim:rgba(79,190,135,.12);
  --text-primary:#eef0f3;--text-secondary:#8b929e;--text-muted:#50565f;
  --font:'Noto Sans', sans-serif;
  --radius-sm:6px;
}
html,body{height:100%;font-family:var(--font);background:var(--bg-base);color:var(--text-primary);}
body{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.card{background:var(--bg-surface);border:1px solid var(--border-strong);border-radius:16px;width:100%;max-width:420px;padding:36px 32px;box-shadow:0 8px 48px rgba(0,0,0,.6);}
.logo-area{display:flex;flex-direction:column;align-items:center;gap:12px;margin-bottom:28px;}
.logo-sub{font-size:11px;font-weight:600;color:var(--text-muted);letter-spacing:1px;text-transform:uppercase;}
.title{font-size:20px;font-weight:800;text-align:center;margin-bottom:4px;}
.subtitle{font-size:13px;color:var(--text-muted);text-align:center;margin-bottom:22px;}
.form-group{display:flex;flex-direction:column;gap:6px;margin-bottom:13px;}
.form-group label{font-size:11px;font-weight:700;color:var(--text-secondary);letter-spacing:.3px;text-transform:uppercase;}
input{width:100%;background:var(--bg-input);color:var(--text-primary);border:1px solid var(--border-strong);border-radius:var(--radius-sm);padding:12px 14px;font-size:14px;font-family:var(--font);outline:none;transition:border-color .15s,box-shadow .15s;}
input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-dim);}
.btn{width:100%;color:#fff;font-weight:700;font-size:15px;padding:13px;border-radius:var(--radius-sm);border:none;cursor:pointer;font-family:var(--font);transition:background .15s;margin-top:8px;}
.btn-primary{background:var(--accent);}
.btn-primary:hover{background:var(--accent-hover);}
.alerta{border-radius:var(--radius-sm);padding:10px 14px;font-size:13px;font-weight:600;margin-bottom:14px;}
.alerta-erro{background:var(--red-dim);border:1px solid rgba(232,86,86,.3);color:var(--red);}
.alerta-ok{background:var(--green-dim);border:1px solid rgba(79,190,135,.3);color:var(--green);}
.link-login{display:block;text-align:center;font-size:13px;color:var(--text-secondary);margin-top:20px;}
.link-login a{color:var(--accent);text-decoration:none;font-weight:600;}
</style>
</head>
<body>
<div class="card">
  <div class="logo-area">
    <span class="logo-sub">R. Créditos</span>
  </div>

  <div class="title">Cadastro de Operador</div>
  <div class="subtitle">Use o código enviado pelo seu administrador</div>

  <?php if ($erro): ?>
  <div class="alerta alerta-erro">⚠ <?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>
  <?php if ($sucesso): ?>
  <div class="alerta alerta-ok"><?= htmlspecialchars($sucesso) ?></div>
  <?php endif; ?>

  <?php if (!$sucesso): ?>
  <form method="POST" action="">
    <div class="form-group">
      <label>Código de Vínculo</label>
      <input type="text" name="codigo_vinculo" placeholder="ABC-123-XYZ" 
             value="<?= htmlspecialchars($_POST['codigo_vinculo'] ?? '') ?>" required/>
    </div>

    <div class="form-group">
      <label>Nome completo</label>
      <input type="text" name="nome" placeholder="Seu nome"
             value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required/>
    </div>

    <div class="form-group">
      <label>E-mail</label>
      <input type="email" name="email" placeholder="seu@email.com"
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required/>
    </div>

    <div class="form-group">
      <label>Senha</label>
      <input type="password" name="senha" placeholder="Mínimo 6 caracteres" minlength="6" required/>
    </div>

    <div class="form-group">
      <label>Confirmar Senha</label>
      <input type="password" name="senha_confirma" placeholder="Repita a senha" required/>
    </div>

    <button type="submit" class="btn btn-primary">Cadastrar e Vincular</button>
  </form>
  <?php endif; ?>

  <div class="link-login">
    Já tem conta? <a href="<?= BASE_URL ?>/app/auth/login.php">Fazer Login</a>
  </div>
</div>
</body>
</html>
