<?php
/**
 * R. Créditos — Logout (JWT + Sessão)
 */
require_once __DIR__ . '/../config/app.php';

// Invalidar token JWT se existir
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
if (strpos($authHeader, 'Bearer ') === 0) {
    $token = substr($authHeader, 7);
    $user  = currentUser();
    if ($user && $token) {
        try {
            invalidarToken($token, $user['id'], getDB(), 'logout');
        } catch (Exception $e) {
            error_log('[LOGOUT] Falha ao invalidar token: ' . $e->getMessage());
        }
    }
}

// Destroi a sessão
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

// Instrui o frontend a limpar o token do sessionStorage
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>Saindo...</title></head>
<body>
<script>
  // Limpa token JWT do sessionStorage
  sessionStorage.removeItem('rc_token');
  sessionStorage.removeItem('rc_usuario');
  // Redireciona para login
  window.location.href = '<?= BASE_URL ?>/app/auth/login.php';
</script>
</body>
</html>
