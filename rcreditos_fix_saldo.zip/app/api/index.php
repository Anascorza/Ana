<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * R. CRÉDITOS — API REST Central
 * Versão: 4.1-DEFENSIVA
 *
 * MUDANÇAS DESTA VERSÃO:
 *   1. Handler global de exceções — nenhum erro 500 sem JSON válido.
 *   2. Detecção automática de schema (INFORMATION_SCHEMA) uma única vez
 *      por requisição: inserts incluem colunas novas SOMENTE se existirem.
 *   3. try/catch em todas as operações de escrita com error_log detalhado.
 *   4. Compatível com banco antigo (sem novas colunas) E com banco migrado.
 *
 * PARA CORRIGIR O BANCO: rodar correcoes_ruta_ids.sql no phpMyAdmin.
 * ════════════════════════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config/app.php';

header('Content-Type: application/json; charset=utf-8');

// ─────────────────────────────────────────────────────────────────
// HANDLER GLOBAL — qualquer exceção não capturada vira JSON 500
// Impede que o PHP retorne uma página HTML de erro.
// ─────────────────────────────────────────────────────────────────
set_exception_handler(function (Throwable $e): void {
    $action = $GLOBALS['_rc_action'] ?? '?';
    $msg    = $e->getMessage();
    error_log('[API UNCAUGHT] action=' . $action
        . ' | ' . get_class($e) . ': ' . $msg
        . ' | file=' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode([
        'sucesso'  => false,
        'mensagem' => 'Erro interno no servidor. Veja os logs para detalhes.',
        'dados'    => null,
    ]);
    exit;
});

requireAuth();

$user = currentUser();
if (!$user) {
    error_log('[API] currentUser() retornou null — token inválido ou sessão expirada');
    resposta(false, 'Erro de autenticação interno');
}

$usuarioId = (int)$user['id'];
// Para operadores: admin_id vem do JWT.
// Para o próprio admin usando o R Créditos: admin_id = seu próprio ID,
// garantindo que seus registros apareçam corretamente no Sistema Branco.
$adminId   = !empty($user['admin_id'])
    ? (int)$user['admin_id']
    : (($user['tipo'] === 'admin') ? (int)$usuarioId : null);
$db        = getDB();
$isClosed  = isRouteClosed();

$raw    = file_get_contents('php://input');
$body   = json_decode($raw, true) ?? [];
$action = $body['action'] ?? $_GET['action'] ?? '';

// Expõe $action ao handler global acima
$GLOBALS['_rc_action'] = $action;

// ─────────────────────────────────────────────────────────────────
// DETECÇÃO DE SCHEMA (uma query, resultado cacheado por request)
//
// Detecta quais colunas "novas" já existem no banco.
// Se o SQL correcoes_ruta_ids.sql ainda não foi rodado, as colunas
// não existem e os inserts são feitos sem elas — sem crash.
// ─────────────────────────────────────────────────────────────────
$_existingCols = [];
try {
    $__st = $db->query(
        "SELECT CONCAT(TABLE_NAME,'.',COLUMN_NAME)
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND (
                 (TABLE_NAME = 'vendas'     AND COLUMN_NAME = 'ruta_id')
              OR (TABLE_NAME = 'parcelas'   AND COLUMN_NAME IN ('usuario_id','ruta_id'))
              OR (TABLE_NAME = 'pagamentos' AND COLUMN_NAME IN ('usuario_id','ruta_id','data_pagamento'))
              OR (TABLE_NAME = 'multas'     AND COLUMN_NAME IN ('usuario_id','ruta_id','admin_id'))
              OR (TABLE_NAME = 'fotos'      AND COLUMN_NAME IN ('usuario_id','ruta_id','imagem_base64'))
           )"
    );
    $_existingCols = array_flip($__st->fetchAll(PDO::FETCH_COLUMN));
} catch (Exception $__e) {
    error_log('[API SCHEMA CHECK] Falha ao ler INFORMATION_SCHEMA: ' . $__e->getMessage());
    // Continua sem detecção — inserts usarão apenas colunas originais
}

/**
 * Verifica se uma coluna opcional existe no banco atual.
 * Formato: 'tabela.coluna'  ex: 'vendas.ruta_id'
 */


/**
 * Verifica se uma venda possui multas pendentes.
 */
function vendaTemMultasPendentes(PDO $db, int $vendaId): bool
{
    $st = $db->prepare("SELECT COUNT(*) FROM multas WHERE venda_id = ? AND status IN ('pendente', 'atrasado', 'aberto')");
    $st->execute([$vendaId]);
    return (int)$st->fetchColumn() > 0;
}

function hasCol(string $tableCol): bool
{
    return isset($GLOBALS['_existingCols'][$tableCol]);
}

/**
 * Regra financeira oficial para NOVAS vendas.
 * O valor da parcela é inteiro e sempre arredondado para cima; o total
 * oficial passa a ser exatamente parcela x quantidade. Valores antigos não
 * passam por esta função e permanecem inalterados.
 */
const REGRA_ARREDONDAMENTO_VENDAS_DESDE = '2026-08-17';

function historicoTabelaDisponivel(PDO $db): bool
{
    static $disponivel = null;
    if ($disponivel !== null) return $disponivel;
    try {
        $st = $db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'historico_cobrancas'");
        $st->execute();
        $disponivel = ((int)$st->fetchColumn() > 0);
    } catch (Throwable $e) {
        $disponivel = false;
    }
    return $disponivel;
}

function historicoDataHoje(): string
{
    return (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d');
}

function sincronizarHistoricoCobrancas(PDO $db, int $usuarioId, ?int $adminId, int $vendaId): void
{
    if (!historicoTabelaDisponivel($db)) return;
    $st = $db->prepare("SELECT id, cliente_id, numero, data_vencimento, valor, status FROM parcelas WHERE venda_id = ? AND data_vencimento <= ? AND DAYOFWEEK(data_vencimento) <> 1 ORDER BY numero");
    $st->execute([$vendaId, historicoDataHoje()]);
    $parcelas = $st->fetchAll(PDO::FETCH_ASSOC);
    if (!$parcelas) return;

    $stVenda = $db->prepare('SELECT cliente_id FROM vendas WHERE id = ? AND usuario_id = ?');
    $stVenda->execute([$vendaId, $usuarioId]);
    $venda = $stVenda->fetch(PDO::FETCH_ASSOC);
    if (!$venda) return;

    $sql = "INSERT INTO historico_cobrancas
        (usuario_id, admin_id, venda_id, cliente_id, parcela_numero, data_cobranca, situacao, valor_pago, evento_chave)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
        ON DUPLICATE KEY UPDATE
          situacao = CASE WHEN situacao IN ('nao-pagou', 'pago') THEN situacao ELSE VALUES(situacao) END";
    $ins = $db->prepare($sql);
    $hoje = historicoDataHoje();
    foreach ($parcelas as $p) {
        $data = (string)$p['data_vencimento'];
        $situacao = (($p['status'] ?? '') === 'pago') ? 'pago' : (($data < $hoje) ? 'nao-pagou' : 'pendente');
        $chave = 'cobranca:' . $vendaId . ':' . (int)$p['numero'] . ':' . $data;
        $ins->execute([$usuarioId, $adminId, $vendaId, $venda['cliente_id'], (int)$p['numero'], $data, $situacao, $chave]);
    }
}

function registrarHistoricoPagamento(PDO $db, int $usuarioId, ?int $adminId, int $vendaId, int $pagamentoId, int $parcelaNumero, string $dataPagamento, float $valor, string $observacao = 'Pagamento realizado'): void
{
    if ($valor <= 0 || !historicoTabelaDisponivel($db)) return;
    $st = $db->prepare('SELECT cliente_id FROM vendas WHERE id = ? AND usuario_id = ?');
    $st->execute([$vendaId, $usuarioId]);
    $venda = $st->fetch(PDO::FETCH_ASSOC);
    if (!$venda) return;
    $chave = 'pagamento:' . $pagamentoId . ':' . $parcelaNumero . ':' . number_format($valor, 2, '.', '');
    $ins = $db->prepare("INSERT INTO historico_cobrancas
      (usuario_id, admin_id, venda_id, cliente_id, parcela_numero, data_cobranca, situacao, observacao, pagamento_id, data_pagamento, valor_pago, evento_chave)
      VALUES (?, ?, ?, ?, ?, ?, 'pagamento', ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE valor_pago = VALUES(valor_pago), observacao = VALUES(observacao)");
    $ins->execute([$usuarioId, $adminId, $vendaId, $venda['cliente_id'], $parcelaNumero, $dataPagamento, $observacao, $pagamentoId, $dataPagamento, $valor, $chave]);
}

function marcarHistoricoNaoPagou(PDO $db, int $usuarioId, ?int $adminId, int $vendaId, int $parcelaNumero, string $dataCobranca, int $pagamentoId): void
{
    if (!historicoTabelaDisponivel($db)) return;
    sincronizarHistoricoCobrancas($db, $usuarioId, $adminId, $vendaId);
    $st = $db->prepare("UPDATE historico_cobrancas SET situacao = 'nao-pagou', observacao = NULL
        WHERE venda_id = ? AND parcela_numero = ? AND data_cobranca = ? AND evento_chave LIKE 'cobranca:%'");
    $st->execute([$vendaId, $parcelaNumero, $dataCobranca]);
}

function calcularFinanceiroNovaVenda(array $d): array
{
    $valorEmprestimo = round((float)($d['valorEmprestimo'] ?? 0), 2);
    $jurosPct = round((float)($d['jurosPct'] ?? 0), 2);
    $numParcelas = (int)($d['numParcelas'] ?? 0);
    if ($valorEmprestimo <= 0 || $numParcelas <= 0) {
        throw new InvalidArgumentException('Valor emprestado e número de parcelas devem ser válidos.');
    }

    $jurosValor = round($valorEmprestimo * $jurosPct / 100, 2);
    $totalCalculado = round($valorEmprestimo + $jurosValor, 2);
    $valorParcela = (int)ceil(($totalCalculado / $numParcelas) - 0.00000001);
    $totalOficial = $valorParcela * $numParcelas;

    // Validação em centavos para não depender de comparação de floats.
    $parcelaCentavos = (int)round($valorParcela * 100);
    $totalCentavos = (int)round($totalOficial * 100);
    if ($parcelaCentavos * $numParcelas !== $totalCentavos) {
        throw new RuntimeException('Inconsistência financeira: parcela x quantidade não corresponde ao total oficial.');
    }

    return [
        'valorEmprestimo' => $valorEmprestimo,
        'jurosPct' => $jurosPct,
        'jurosValor' => $jurosValor,
        'totalComJuros' => (float)$totalOficial,
        'numParcelas' => $numParcelas,
        'valorParcela' => (float)$valorParcela,
    ];
}

// ─────────────────────────────────────────────────────────────────
// HELPER atualizarStatusParcela
// Recalcula e persiste o status correto de uma parcela com base nos
// pagamentos registrados. Idempotente — pode ser chamada múltiplas
// vezes sem efeito colateral.
// ─────────────────────────────────────────────────────────────────
/**
 * Recalcula e persiste o status correto de uma parcela.
 *
 * MODELO DO SISTEMA: pagamentos são registrados por venda_id, não por parcela_id.
 * O estado acumulado vive em vendas.parcelas_pagas + vendas.saldo_parcial_pago.
 * O status de uma parcela número N é:
 *   - 'pago'     se N <= parcelas_pagas  (crédito total cobriu a parcela)
 *   - 'parcial'  se N == parcelas_pagas+1 e saldo_parcial_pago > 0  (crédito parcial)
 *   - 'atrasado' se data_vencimento < hoje e N > parcelas_pagas
 *   - 'pendente' caso contrário
 *
 * Idempotente — pode ser chamada múltiplas vezes sem efeito colateral.
 * Nunca retorna antecipadamente por status anterior: sempre recalcula do banco.
 *
 * @param PDO $db
 * @param int $parcela_id
 * @return string  O novo status aplicado
 */
function atualizarStatusParcela(PDO $db, int $parcela_id): string
{
    // 1. Buscar dados da parcela + estado acumulado da venda (fonte de verdade)
    $stParcela = $db->prepare("
        SELECT p.id, p.numero, p.valor, p.status, p.data_vencimento,
               v.parcelas_pagas, v.saldo_parcial_pago, v.valor_parcela
        FROM parcelas p
        JOIN vendas v ON v.id = p.venda_id
        WHERE p.id = ?
    ");
    $stParcela->execute([$parcela_id]);
    $row = $stParcela->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        throw new RuntimeException("Parcela #{$parcela_id} não encontrada.");
    }

    $numero       = (int)   $row['numero'];
    $parcelas_pagas    = (int)   $row['parcelas_pagas'];
    $saldo_parcial     = (float) $row['saldo_parcial_pago'];
    $statusAtual  =             $row['status'];

    // 2. Derivar status a partir do estado acumulado da venda — sem flags manuais
    if ($numero <= $parcelas_pagas) {
        // Crédito acumulado cobriu esta parcela integralmente (R1)
        $novoStatus = 'pago';
    } elseif ($numero === $parcelas_pagas + 1 && $saldo_parcial > 0.005) {
        // Próxima parcela com crédito parcial acumulado — apenas visual (R2)
        $novoStatus = 'parcial';
    } else {
        // Sem crédito: pendente ou atrasado por data de vencimento (R4)
        $hoje = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d');
        $novoStatus = ($row['data_vencimento'] < $hoje) ? 'atrasado' : 'pendente';
    }

    // 3. Só escreve se mudou — evita writes desnecessários (idempotência)
    if ($novoStatus !== $statusAtual) {
        $dataNow = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d H:i:s');
        $stUp = $db->prepare("
            UPDATE parcelas SET status = ?, atualizado_em = ? WHERE id = ?
        ");
        $stUp->execute([$novoStatus, $dataNow, $parcela_id]);
    }

    return $novoStatus;
}

// ─────────────────────────────────────────────────────────────────
// HELPER buildAdminFilter
// ─────────────────────────────────────────────────────────────────
function buildAdminFilter(?int $adminId, string $prefix = ''): array
{
    $col = $prefix ? "{$prefix}.admin_id" : 'admin_id';
    if ($adminId !== null) {
        return ["($col = ? OR $col IS NULL)", [$adminId]];
    }
    return ['1=1', []];
}

// ─────────────────────────────────────────────────────────────────
// HELPER getRutaAtiva
// ─────────────────────────────────────────────────────────────────
function getRutaAtiva(PDO $db, int $usuarioId): ?array
{
    try {
        $st = $db->prepare("SELECT * FROM rutas WHERE usuario_id = ? AND ativa = 1 LIMIT 1");
        $st->execute([$usuarioId]);
        return $st->fetch() ?: null;
    } catch (Exception $e) {
        error_log('[getRutaAtiva] ' . $e->getMessage());
        return null;
    }
}

// ─────────────────────────────────────────────────────────────────
// HELPER registrarMovimentacao
// ─────────────────────────────────────────────────────────────────
function registrarMovimentacao(
    PDO $db, int $usuarioId, ?int $adminId, string $tipo, float $valor,
    ?string $descricao = null, ?int $referenciaId = null,
    ?string $clienteNome = null, ?string $data = null
): void {
    try {
        $ruta = getRutaAtiva($db, $usuarioId);
        if (!$ruta) return;
        $st = $db->prepare("
            INSERT INTO movimentacoes
                (ruta_id, usuario_id, admin_id, tipo, valor, descricao,
                 referencia_id, cliente_nome, data_mov, criado_em)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $st->execute([
            (int)$ruta['id'], $usuarioId, $adminId, $tipo, $valor,
            $descricao, $referenciaId, $clienteNome, $data ?? date('Y-m-d'),
        ]);
    } catch (Exception $e) {
        error_log('[registrarMovimentacao] tipo=' . $tipo . ' | ' . $e->getMessage());
    }
}

// ─────────────────────────────────────────────────────────────────
// HELPER isRetroativo / SQL fragment para ajuste retroativo
// ─────────────────────────────────────────────────────────────────
// Identifica registros de pagamento que são ajustes retroativos / reconciliação
// de dados — nunca movimentação operacional.
const RETROATIVO_KEYWORDS = [
    'Ajuste retroativo', 'Reconciliação', 'Correção histórica',
    'ajuste retroativo', 'reconciliação', 'correção histórica',
    'retroativo',
];

function isRetroativo(?string $motivo): bool
{
    if (empty($motivo)) return false;
    foreach (RETROATIVO_KEYWORDS as $kw) {
        if (mb_stripos($motivo, $kw) !== false) return true;
    }
    return false;
}

// Retorna trecho SQL para filtrar pagamentos NÃO retroativos.
// Pode ser appendado com "AND" na WHERE de qualquer consulta.
// Suporta alias opcional para a tabela pagamentos.
function retroativoSql(string $alias = 'p'): string
{
    // Usa FIND_IN_SET-like com LIKE para cobrir keywords no campo motivo.
    // O resultado é: p.motivo IS NULL OR p.motivo NOT LIKE '%Ajuste retroativo%' ...
    // Para colunas que podem não existir (motivo), envolver em COALESCE.
    $parts = [];
    foreach (RETROATIVO_KEYWORDS as $kw) {
        $parts[] = "COALESCE({$alias}.motivo, '') NOT LIKE '%{$kw}%'";
    }
    return '(' . implode(' AND ', $parts) . ')';
}

// ══════════════════════════════════════════════════════════════════
// CLIENTES
// ══════════════════════════════════════════════════════════════════
if ($action === 'clientes.listar') {
    try {
        [$adminWhere, $adminParams] = buildAdminFilter($adminId, 'c');
        $sql    = "SELECT * FROM clientes c WHERE c.usuario_id = ? AND $adminWhere
                   ORDER BY COALESCE(NULLIF(c.nome_comercial,''), c.nome)";
        $params = array_merge([$usuarioId], $adminParams);
        $st     = $db->prepare($sql);
        $st->execute($params);
        $clientes = $st->fetchAll();
        error_log("[clientes.listar] uid=$usuarioId admin_id=" . ($adminId ?? 'NULL') . " total=" . count($clientes));
        resposta(true, '', $clientes);
    } catch (Exception $e) {
        error_log('[clientes.listar] ' . $e->getMessage());
        resposta(false, 'Erro ao listar clientes.');
    }
}

if ($action === 'clientes.buscar') {
    try {
        $id = $body['id'] ?? $_GET['id'] ?? '';
        $st = $db->prepare('SELECT * FROM clientes WHERE id = ? AND usuario_id = ?');
        $st->execute([$id, $usuarioId]);
        $c = $st->fetch();
        $c ? resposta(true, '', $c) : resposta(false, 'Cliente não encontrado.');
    } catch (Exception $e) {
        error_log('[clientes.buscar] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar cliente.');
    }
}

if ($action === 'clientes.excluir') {
    try {
        $id = $body['id'] ?? '';
        logAcao('CLIENTE_EXCLUIR_BLOQUEADO', 'Tentou excluir cliente ID: ' . $id . ' (operação bloqueada)', 'clientes', $id);
    } catch (Exception $e) {
        error_log('[clientes.excluir] ' . $e->getMessage());
    }
    resposta(false, 'A exclusão de clientes está desativada.');
}

if ($action === 'clientes.salvar') {
    if ($isClosed) resposta(false, 'Rota fechada ou antes das 08:00.');
    $d = $body['dados'] ?? [];
    if (empty($d['nome'])) resposta(false, 'Nome do cliente é obrigatório.');

    try {
        $id = $d['id'] ?? '';
        $st = $db->prepare('SELECT id FROM clientes WHERE id = ? AND usuario_id = ?');
        $st->execute([$id, $usuarioId]);
        $existe = $st->fetch();

        if ($existe) {
            $st = $db->prepare('UPDATE clientes SET
                nome=?, id_numerico=?, nome_comercial=?, cpf=?, rg=?, celular=?,
                tipo_endereco=?, endereco_res=?, endereco_com=?, obs=?, foto_thumb=?
                WHERE id=? AND usuario_id=?');
            $st->execute([
                $d['nome'],                      $d['idNumerico']??null,
                $d['nomeComercial']??null,       $d['cpf']??null,
                $d['rg']??null,                  $d['celular']??null,
                $d['tipoEndereco']??'residencial',
                $d['enderecoRes']??null,         $d['enderecoCom']??null,
                $d['obs']??null,                 $d['_fotoThumb']??null,
                $id,                             $usuarioId,
            ]);
            logAcao('CLIENTE_EDITAR', 'Editou cliente: ' . $d['nome'], 'clientes', $id);
            resposta(true, 'Cliente atualizado.');
        } else {
            $newId = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff),
                mt_rand(0,0x0fff)|0x4000, mt_rand(0,0x3fff)|0x8000,
                mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff));

            if (empty($d['idNumerico'])) {
                $stMax = $db->prepare('SELECT MAX(id_numerico) FROM clientes WHERE usuario_id = ?');
                $stMax->execute([$usuarioId]);
                $max = (int)$stMax->fetchColumn();
                $d['idNumerico'] = $max + 1;
            }

            // Buscar ruta ativa para vincular o cliente
            $rutaCliente   = getRutaAtiva($db, $usuarioId);
            $rutaClienteId = $rutaCliente ? (int)$rutaCliente['id'] : null;

            $st = $db->prepare('INSERT INTO clientes
                (id, usuario_id, admin_id, ruta_id, nome, id_numerico, nome_comercial, cpf, rg, celular,
                 tipo_endereco, endereco_res, endereco_com, obs, foto_thumb, criado_em)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $st->execute([
                $newId,                          $usuarioId,
                $adminId,                        $rutaClienteId,
                $d['nome'],                      $d['idNumerico'],
                $d['nomeComercial']??null,       $d['cpf']??null,
                $d['rg']??null,                  $d['celular']??null,
                $d['tipoEndereco']??'residencial',
                $d['enderecoRes']??null,         $d['enderecoCom']??null,
                $d['obs']??null,                 $d['_fotoThumb']??null,
                $d['criadoEm']??date('Y-m-d'),
            ]);
            logAcao('CLIENTE_CADASTRAR', 'Cadastrou cliente: ' . $d['nome'], 'clientes', $newId);
            resposta(true, 'Cliente criado.', ['id' => $newId]);
        }
    } catch (Exception $e) {
        error_log('[clientes.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar cliente: ' . $e->getMessage());
    }
}

// ══════════════════════════════════════════════════════════════════
// VENDAS
// ══════════════════════════════════════════════════════════════════
if ($action === 'vendas.listar') {
    try {
        [$adminWhere, $adminParams] = buildAdminFilter($adminId, 'v');
        $sql    = "SELECT v.*, c.nome as cliente_nome, c.nome_comercial as cliente_nome_comercial
                   FROM vendas v LEFT JOIN clientes c ON v.cliente_id = c.id
                   WHERE v.usuario_id = ? AND $adminWhere ORDER BY v.id DESC";
        $params = array_merge([$usuarioId], $adminParams);
        $st     = $db->prepare($sql);
        $st->execute($params);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[vendas.listar] ' . $e->getMessage());
        resposta(false, 'Erro ao listar vendas.');
    }
}

if ($action === 'vendas.buscar') {
    try {
        $id = (int)($body['id'] ?? $_GET['id'] ?? 0);
        $st = $db->prepare('SELECT v.*, c.nome as cliente_nome, c.nome_comercial as cliente_nome_comercial
                            FROM vendas v LEFT JOIN clientes c ON v.cliente_id = c.id
                            WHERE v.id = ? AND v.usuario_id = ?');
        $st->execute([$id, $usuarioId]);
        $v = $st->fetch();
        $v ? resposta(true, '', $v) : resposta(false, 'Venda não encontrada.');
    } catch (Exception $e) {
        error_log('[vendas.buscar] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar venda.');
    }
}

if ($action === 'vendas.porCliente') {
    try {
        $clienteId = $body['clienteId'] ?? $_GET['clienteId'] ?? '';
        $st = $db->prepare('SELECT * FROM vendas WHERE cliente_id = ? AND usuario_id = ? ORDER BY id DESC');
        $st->execute([$clienteId, $usuarioId]);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[vendas.porCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar vendas do cliente.');
    }
}

if ($action === 'vendas.excluir') {
    try {
        $id = (int)($body['id'] ?? 0);
        if (!$id) resposta(false, 'ID obrigatório.');
        // CORREÇÃO CIRÚRGICA: Multas não são mais excluídas automaticamente com a venda.
        // Apenas pagamentos e a venda em si são removidos.
        $db->prepare('DELETE FROM pagamentos WHERE venda_id = ?')->execute([$id]);
        $db->prepare('DELETE FROM vendas     WHERE id = ? AND usuario_id = ?')->execute([$id, $usuarioId]);
        logAcao('VENDA_EXCLUIR', 'Excluiu venda ID: ' . $id, 'vendas', $id);
        resposta(true, 'Venda excluída.');
    } catch (Exception $e) {
        error_log('[vendas.excluir] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir venda.');
    }
}

if ($action === 'venda.editar') {
    if ($isClosed) resposta(false, 'Rota fechada ou antes das 08:00.');
    try {
        $d  = $body['dados'] ?? [];
        $id = $d['id'] ?? 0;
        if (!$id) resposta(false, 'ID da venda obrigatório.');

        $st = $db->prepare('SELECT criado_em FROM vendas WHERE id = ? AND usuario_id = ?');
        $st->execute([$id, $usuarioId]);
        $venda = $st->fetch();
        if (!$venda) resposta(false, 'Venda não encontrada.');

        if (time() - strtotime($venda['criado_em']) > 86400) {
            resposta(false, 'Esta venda não pode mais ser editada (limite de 24 horas excedido).');
        }

        // Uma venda criada após a publicação da regra continua sujeita à
        // igualdade oficial durante a janela de edição. Contratos anteriores
        // permanecem com seus valores históricos.
        if (substr((string)$venda['criado_em'], 0, 10) >= REGRA_ARREDONDAMENTO_VENDAS_DESDE) {
            $d = array_merge($d, calcularFinanceiroNovaVenda($d));
            $pCents = (int)round((float)$d['valorParcela'] * 100);
            $tCents = (int)round((float)$d['totalComJuros'] * 100);
            if ($pCents * (int)$d['numParcelas'] !== $tCents) {
                resposta(false, 'Venda não salva: o valor da parcela multiplicado pela quantidade deve ser igual ao total oficial.');
            }
        }

        $st = $db->prepare('UPDATE vendas SET
            valor_emprestimo=?, juros_pct=?, juros_valor=?, total_com_juros=?,
            num_parcelas=?, valor_parcela=?, data_inicio=?, tipo_venc=?, dias_multa=?, valor_multa=?
            WHERE id=? AND usuario_id=?');
        $st->execute([
            $d['valorEmprestimo'], $d['jurosPct'], $d['jurosValor'], $d['totalComJuros'],
            $d['numParcelas'],     $d['valorParcela'], $d['dataInicio'], $d['tipoVenc'], $d['diasMulta'], $d['valorMulta'],
            $id,                   $usuarioId
        ]);
        logAcao('VENDA_EDITAR_COMPLETO', 'Editou dados da venda ID: ' . $id, 'vendas', $id);
        resposta(true, 'Venda atualizada com sucesso.');
    } catch (Exception $e) {
        error_log('[venda.editar] ' . $e->getMessage());
        resposta(false, 'Erro ao editar venda: ' . $e->getMessage());
    }
}

if ($action === 'vendas.salvar') {
    if ($isClosed) resposta(false, 'Rota fechada ou antes das 08:00.');
    try {
        $d = $body['dados'] ?? [];

        if (!empty($d['id'])) {
            // ── Atualização de venda existente ──────────────────────────────
            $st = $db->prepare('UPDATE vendas SET
                parcelas_pagas=?, saldo_parcial_pago=?, ultimo_pagamento=?, ultima_forma_pag=?,
                num_parcelas=?, edicoes_restantes = edicoes_restantes - 1
                WHERE id=? AND usuario_id=?');
            // CORREÇÃO CIRÚRGICA: Multas são independentes, mas bloqueiam a quitação da venda.
            $isQuiting = (int)($d["parcelasPagas"]??0) >= (int)($d["numParcelas"]??1)
                         && ((float)($d["saldoParcialPago"]??0) <= 0.005);
            if ($isQuiting && vendaTemMultasPendentes($db, (int)$d["id"])) {
                resposta(false, "Esta venda possui multas pendentes. Quite todas as multas na Gestão de Multas antes de finalizar a venda.", null, 200, "MULTAS_PENDENTES");
            }
            // ---------------------------------------------------

            $st->execute([
                $d["parcelasPagas"]??0,          $d["saldoParcialPago"]??0,
                $d["ultimoPagamentoData"]??null,  $d["ultimoFormaPag"]??null,
                $d["numParcelas"]??1,             $d["id"],
                $usuarioId,
            ]);
            logAcao('VENDA_EDITAR', 'Editou venda ID: ' . $d['id'], 'vendas', $d['id']);
            resposta(true, 'Venda atualizada.');
        }

        // ── Nova venda ──────────────────────────────────────────────────────
        // Buscar ruta ativa (obrigatório para vínculo correto)
        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;
        if (!$rutaId) {
            resposta(false, 'Nenhuma ruta ativa encontrada. Abra sua ruta antes de cadastrar empréstimos.');
        }

        // Determinar tipo: 'nova' ou 'renovacao'
        $tipo_venda = 'nova';
        $criado_em  = $d['criado_em'] ?? date('Y-m-d');

        $stUlt = $db->prepare('SELECT id FROM vendas WHERE cliente_id = ? AND usuario_id = ? ORDER BY id DESC LIMIT 1');
        $stUlt->execute([$d['clienteId'], $usuarioId]);
        $ultimaVenda = $stUlt->fetch();
        if ($ultimaVenda) {
            $stPagas = $db->prepare("SELECT COUNT(*) FROM parcelas WHERE venda_id = ? AND status NOT IN ('pago','quitado')");
            $stPagas->execute([$ultimaVenda['id']]);
            $parcelasPendentes = (int)$stPagas->fetchColumn();

            // CORREÇÃO CIRÚRGICA: Tipo renovação depende de parcelas e multas quitadas.
            $stMult = $db->prepare("SELECT COUNT(*) FROM multas WHERE venda_id = ? AND status IN ('pendente', 'atrasado', 'aberto')");
            $stMult->execute([$ultimaVenda['id']]);
            $multasAbertas = (int)$stMult->fetchColumn();

            if ($parcelasPendentes === 0 && $multasAbertas === 0) {
                $tipo_venda = 'renovacao';
            }
        }

        // Regra oficial somente para NOVAS vendas: parcela inteira para cima e
        // total recalculado como parcela x quantidade. A API é a última barreira
        // contra divergências, independentemente do cliente que enviar o pedido.
        $financeiro = calcularFinanceiroNovaVenda($d);
        $d = array_merge($d, $financeiro);
        $parcelaCentavos = (int)round((float)$d['valorParcela'] * 100);
        $totalCentavos = (int)round((float)$d['totalComJuros'] * 100);
        if ($parcelaCentavos * (int)$d['numParcelas'] !== $totalCentavos) {
            resposta(false, 'Venda não salva: o valor da parcela multiplicado pela quantidade deve ser igual ao total oficial.');
        }

        // ── INSERT defensivo: inclui ruta_id somente se a coluna existir ──
        $cols = [
            'usuario_id','admin_id','cliente_id','valor_emprestimo','juros_pct',
            'juros_valor','total_com_juros','num_parcelas','tipo_venc',
            'parcelas_pagas','saldo_parcial_pago','valor_parcela','data_inicio',
            'dias_multa','valor_multa','edicoes_restantes','tipo','criado_em',
        ];
        $vals = [
            $usuarioId,              $adminId,
            $d['clienteId'],         $d['valorEmprestimo'],
            $d['jurosPct'],          $d['jurosValor'],
            $d['totalComJuros'],     $d['numParcelas'],
            $d['tipoVenc'],          $d['parcelasPagas']??0,
            $d['saldoParcialPago']??0, $d['valorParcela'],
            $d['dataInicio'],        $d['diasMulta']??2,
            $d['valorMulta']??0,     $d['edicoes_restantes']??3,
            $tipo_venda,             $criado_em,
        ];
        if (hasCol('vendas.ruta_id')) {
            array_splice($cols, 2, 0, ['ruta_id']);
            array_splice($vals, 2, 0, [$rutaId]);
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $st = $db->prepare("INSERT INTO vendas ($cl) VALUES ($ph)");
        $st->execute($vals);
        $newId = (int)$db->lastInsertId();

        registrarMovimentacao($db, $usuarioId, $adminId, 'emprestimo',
            -(float)$d['valorEmprestimo'], 'Novo empréstimo', $newId, $d['clienteNome']??null);
        logAcao('VENDA_CADASTRAR', 'Novo empréstimo ID: ' . $newId, 'vendas', $newId);
        resposta(true, 'Venda criada.', ['id' => $newId]);

    } catch (Exception $e) {
        error_log('[vendas.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar venda: ' . $e->getMessage());
    }
}

// ══════════════════════════════════════════════════════════════════
// HISTÓRICO DIÁRIO DE COBRANÇA
// ══════════════════════════════════════════════════════════════════
if ($action === 'historico_cobrancas.porVenda') {
    try {
        $vendaId = (int)($body['vendaId'] ?? $_GET['vendaId'] ?? 0);
        sincronizarHistoricoCobrancas($db, $usuarioId, $adminId, $vendaId);
        $st = $db->prepare('SELECT * FROM historico_cobrancas WHERE venda_id = ? ORDER BY data_cobranca ASC, id ASC');
        $st->execute([$vendaId]);
        resposta(true, '', $st->fetchAll(PDO::FETCH_ASSOC));
    } catch (Exception $e) {
        error_log('[historico_cobrancas.porVenda] ' . $e->getMessage());
        resposta(false, 'Erro ao listar histórico diário. Execute a migração historico_cobrancas.sql.');
    }
}

// ══════════════════════════════════════════════════════════════════
// PARCELAS
// ══════════════════════════════════════════════════════════════════
if ($action === 'parcelas.listar' || $action === 'parcelas.porVenda') {
    try {
        $vendaId = (int)($body['vendaId'] ?? $_GET['vendaId'] ?? 0);
        $st = $db->prepare('SELECT * FROM parcelas WHERE venda_id = ? ORDER BY numero ASC');
        $st->execute([$vendaId]);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[parcelas.listar] ' . $e->getMessage());
        resposta(false, 'Erro ao listar parcelas.');
    }
}

if ($action === 'parcelas.salvar') {
    try {
        $d = $body['dados'] ?? [];

        if (!empty($d['id'])) {
            // Atualiza apenas data_pagamento e forma_pagamento — nunca status diretamente.
            // O status é sempre derivado dos pagamentos via atualizarStatusParcela().
            // Bloqueio de segurança: tentativas de gravar status 'pago'/'parcial'/'quitado'
            // via API genérica são silenciosamente ignoradas.
            if (isset($d['status']) && in_array($d['status'], ['pago', 'parcial', 'quitado'])) {
                error_log("[SECURITY] Tentativa de alteração direta de status de parcela para {$d['status']} bloqueada. ID: " . $d['id']);
            }

            $st = $db->prepare('UPDATE parcelas SET data_pagamento=?, forma_pagamento=?, atualizado_em=? WHERE id=?');
            $st->execute([
                $d['dataPagamento']??null,
                $d['formaPagamento']??null,
                $d['atualizadoEm']??date('Y-m-d'),
                $d['id'],
            ]);

            // Recalcula status a partir dos pagamentos registrados
            atualizarStatusParcela($db, (int)$d['id']);

            logAcao('PARCELA_ATUALIZAR', 'Atualizou parcela ID: ' . $d['id'], 'parcelas', $d['id']);
            resposta(true, 'Parcela atualizada.', ['id' => $d['id']]);
        }

        // ── Nova parcela — INSERT defensivo ─────────────────────────────────
        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;

        $cols = ['venda_id','cliente_id','numero','data_vencimento','valor','status'];
        $vals = [
            $d['vendaId'],       $d['clienteId'],
            $d['numero'],        $d['dataVencimento'],
            $d['valor'],         $d['status']??'pendente',
        ];
        // Adicionar usuario_id e ruta_id somente se as colunas existirem
        if (hasCol('parcelas.usuario_id')) {
            $cols[] = 'usuario_id';
            $vals[] = $usuarioId;
        }
        if (hasCol('parcelas.ruta_id') && $rutaId) {
            $cols[] = 'ruta_id';
            $vals[] = $rutaId;
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $st = $db->prepare("INSERT INTO parcelas ($cl) VALUES ($ph)");
        $st->execute($vals);
        $parcelaId = (int)$db->lastInsertId();
        logAcao('PARCELA_CRIAR', 'Criou parcela #' . $d['numero'] . ' (Venda ID: ' . $d['vendaId'] . ')', 'parcelas', $parcelaId);
        resposta(true, 'Parcela criada.', ['id' => $parcelaId]);

    } catch (Exception $e) {
        error_log('[parcelas.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar parcela: ' . $e->getMessage());
    }
}

if ($action === 'parcelas.excluirPorVenda') {
    try {
        $vendaId = (int)($body['vendaId'] ?? 0);
        $db->prepare('DELETE FROM parcelas WHERE venda_id = ?')->execute([$vendaId]);
        logAcao('PARCELAS_EXCLUIR_VENDA', 'Excluiu parcelas da venda ID: ' . $vendaId, 'parcelas', $vendaId);
        resposta(true, 'Parcelas da venda excluídas.');
    } catch (Exception $e) {
        error_log('[parcelas.excluirPorVenda] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir parcelas.');
    }
}

if ($action === 'parcelas.excluirPorCliente') {
    try {
        $clienteId = $body['clienteId'] ?? '';
        $db->prepare('DELETE FROM parcelas WHERE cliente_id = ?')->execute([$clienteId]);
        logAcao('PARCELAS_EXCLUIR_CLIENTE', 'Excluiu parcelas do cliente ID: ' . $clienteId, 'parcelas', $clienteId);
        resposta(true, 'Parcelas do cliente excluídas.');
    } catch (Exception $e) {
        error_log('[parcelas.excluirPorCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir parcelas do cliente.');
    }
}

if ($action === 'pagamentos.excluirPorCliente') {
    try {
        $clienteId = $body['clienteId'] ?? '';
        $db->prepare('DELETE FROM pagamentos WHERE cliente_id = ?')->execute([$clienteId]);
        logAcao('PAGAMENTO_EXCLUIR_CLIENTE', 'Excluiu pagamentos do cliente ID: ' . $clienteId);
        resposta(true, 'Pagamentos do cliente excluídos.');
    } catch (Exception $e) {
        error_log('[pagamentos.excluirPorCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir pagamentos do cliente.');
    }
}

// ══════════════════════════════════════════════════════════════════
// PAGAMENTOS
// ══════════════════════════════════════════════════════════════════

if ($action === 'pagamentos.registrar_transacional') {
    if ($isClosed) resposta(false, 'Rota fechada ou antes das 08:00.');
    try {
        $d = $body['dados'] ?? [];
        $vendaId = (int)($d['vendaId'] ?? 0);
        $valorPago = (float)($d['valorPago'] ?? 0);
        $formaPagamento = $d['formaPagamento'] ?? 'dinheiro';
        $dataPagamento = $d['data'] ?? date('Y-m-d');

        if ($vendaId <= 0 || $valorPago <= 0) {
            resposta(false, 'Dados de pagamento inválidos.');
        }

        $db->beginTransaction();

        // 1. Buscar a venda e parcelas
        $stVenda = $db->prepare("SELECT * FROM vendas WHERE id = ? AND usuario_id = ? FOR UPDATE");
        $stVenda->execute([$vendaId, $usuarioId]);
        $venda = $stVenda->fetch();
        if (!$venda) {
            $db->rollBack();
            resposta(false, 'Venda não encontrada.');
        }

        $stParc = $db->prepare("SELECT * FROM parcelas WHERE venda_id = ? ORDER BY numero ASC FOR UPDATE");
        $stParc->execute([$vendaId]);
        $parcelas = $stParc->fetchAll();

        // 2. Calcular novo estado
        $valorParcela = (float)$venda['valor_parcela'];
        $pagasIntAntes = (int)$venda['parcelas_pagas'];
        $saldoAntes = (float)$venda['saldo_parcial_pago'];

        $credito = round($saldoAntes + $valorPago, 2);
        $qtdQuit = 0;
        $restamInt = (int)$venda['num_parcelas'] - $pagasIntAntes;

        while ($qtdQuit < $restamInt && $credito >= ($valorParcela - 0.005)) {
            $credito = round($credito - $valorParcela, 2);
            $qtdQuit++;
        }
        $novoSaldoParcial = ($credito > 0.005) ? $credito : 0;
        $pagasIntAgora = min($pagasIntAntes + $qtdQuit, (int)$venda['num_parcelas']);

        // Alocação da baixa atual, separada do crédito parcial que já existia.
        // Assim o histórico usa o valor real desta baixa, e não o valor padrão
        // da parcela quando parte dela já havia sido paga anteriormente.
        $alocacoesHistorico = [];
        $restanteBaixa = $valorPago;
        $creditoAnterior = $saldoAntes;
        $numeroAlocacao = $pagasIntAntes + 1;
        while ($restanteBaixa > 0.005 && $numeroAlocacao <= (int)$venda['num_parcelas']) {
            $necessario = max(0, $valorParcela - $creditoAnterior);
            if ($necessario <= 0.005) {
                $numeroAlocacao++;
                $creditoAnterior = 0;
                continue;
            }
            $alocado = min($restanteBaixa, $necessario);
            $alocacoesHistorico[] = ['numero' => $numeroAlocacao, 'valor' => round($alocado, 2)];
            $restanteBaixa = round($restanteBaixa - $alocado, 2);
            $creditoAcumulado = round($creditoAnterior + $alocado, 2);
            if ($creditoAcumulado >= ($valorParcela - 0.005)) {
                $numeroAlocacao++;
                $creditoAnterior = 0;
            } else {
                $creditoAnterior = $creditoAcumulado;
                break;
            }
        }
        
        // CORREÇÃO CIRÚRGICA: Multas são independentes no registro, mas BLOQUEIAM a quitação da venda.
        $isQuiting = ($pagasIntAgora >= (int)$venda['num_parcelas'] && $novoSaldoParcial <= 0.005);
        if ($isQuiting && vendaTemMultasPendentes($db, $vendaId)) {
            $db->rollBack();
            resposta(false, "Esta venda possui multas pendentes. Quite todas as multas antes de finalizar a venda.", null, 200, "MULTAS_PENDENTES");
        }

        // ── PASSO 3: INSERT do pagamento ─────────────────────────────────────
        // Deve vir ANTES de atualizarStatusParcela() para que o recálculo via
        // SUM(pagamentos WHERE parcela_id=?) já enxergue este valor.
        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;

        $cols = ['venda_id','cliente_id','admin_id','tipo','valor_pago','forma_pagamento',
                 'pagas_int_antes','pagas_int_agora','saldo_parcial_antes','saldo_parcial_depois',
                 'quantidade_parcelas','data'];
        $vals = [$vendaId, $venda['cliente_id'], $adminId, 'pagamento', $valorPago,
                 $formaPagamento, $pagasIntAntes, $pagasIntAgora, $saldoAntes,
                 $novoSaldoParcial, $qtdQuit, $dataPagamento];

        if (hasCol('pagamentos.usuario_id')) {
            array_splice($cols, 2, 0, ['usuario_id']);
            array_splice($vals, 2, 0, [$usuarioId]);
        }
        if (hasCol('pagamentos.ruta_id') && $rutaId) {
            $pos = array_search('admin_id', $cols);
            array_splice($cols, $pos, 0, ['ruta_id']);
            array_splice($vals, $pos, 0, [$rutaId]);
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $stIns = $db->prepare("INSERT INTO pagamentos ($cl) VALUES ($ph)");
        $stIns->execute($vals);
        $pagamentoId = (int)$db->lastInsertId();

        // Cada baixa é um evento separado no histórico. O registro diário
        // original nunca é alterado; a baixa posterior é adicionada com a
        // data real do pagamento e o número da parcela efetivamente baixada.
        foreach ($alocacoesHistorico as $alocacao) {
            $n = (int)$alocacao['numero'];
            $valorAlocado = (float)$alocacao['valor'];
            $ehParcial = $valorAlocado < ($valorParcela - 0.005);
            registrarHistoricoPagamento(
                $db, $usuarioId, $adminId, $vendaId, $pagamentoId, $n, $dataPagamento,
                $valorAlocado,
                ($ehParcial ? 'Pagamento parcial da parcela ' : 'Pagamento da parcela ') . $n
            );
        }

        // ── PASSO 4: Atualizar resumo da venda ──────────────────────────────
        // Deve vir ANTES de atualizarStatusParcela(), pois o helper lê
        // v.parcelas_pagas / v.saldo_parcial_pago de `vendas` (linha ~143)
        // para decidir o status. Se rodasse antes, calcularia com os
        // valores antigos (pagasIntAntes/saldoAntes) em vez dos novos.
        $stUpVenda = $db->prepare("UPDATE vendas SET parcelas_pagas=?, saldo_parcial_pago=?, ultimo_pagamento=?, ultima_forma_pag=? WHERE id=?");
        $stUpVenda->execute([$pagasIntAgora, $novoSaldoParcial, $dataPagamento, $formaPagamento, $vendaId]);

        // ── PASSO 5: atualizarStatusParcela() ───────────────────────────────
        // O INSERT em pagamentos e o UPDATE em vendas já estão no banco —
        // tanto SUM(pagamentos) quanto v.parcelas_pagas/saldo_parcial_pago
        // refletem o estado novo. Grava metadados (data/forma) e delega
        // o status ao helper. PROIBIDO qualquer UPDATE direto de status aqui.
        foreach ($parcelas as $p) {
            $n = (int)$p['numero'];
            if ($n <= $pagasIntAntes) continue; // já quitada antes, metadados não tocam

            if ($n <= $pagasIntAgora) {
                // Apenas metadados: data e forma de pagamento
                $stUp = $db->prepare("UPDATE parcelas SET data_pagamento=?, forma_pagamento=?, atualizado_em=? WHERE id=?");
                $stUp->execute([$dataPagamento, $formaPagamento, $dataPagamento, $p['id']]);
            } elseif ($n === $pagasIntAgora + 1 && $novoSaldoParcial > 0) {
                // Próxima parcela com crédito parcial: registra forma de pagamento
                $stUp = $db->prepare("UPDATE parcelas SET forma_pagamento=?, atualizado_em=? WHERE id=?");
                $stUp->execute([$formaPagamento, $dataPagamento, $p['id']]);
            }
        }

        // Reprocessa TODAS as parcelas da venda via atualizarStatusParcela().
        // Garante consistência total: remove parcelas presas como "atrasado",
        // atualiza as quitadas para "pago" e as com crédito parcial para
        // "parcial", independente de terem sido tocadas pelos metadados acima.
        // Status sempre via helper — idempotente, deriva do SUM(pagamentos).
        foreach ($parcelas as $p) {
            atualizarStatusParcela($db, (int)$p['id']);
        }

        // ── PASSO 6: Resumo da rota — movimentação e log ────────────────────
        // registrarMovimentacao() insere em `movimentacoes`, que é a fonte de
        // verdade do route.resumo (total_recebido, saldo_final, caixa, etc.).
        // O resumo não tem cache em `rutas` — é sempre recalculado on-demand.
        registrarMovimentacao($db, $usuarioId, $adminId, 'pagamento', (float)$valorPago, 'Recebimento', $pagamentoId, $d['clienteNome']??null);
        logAcao('PAGAMENTO_REGISTRAR', 'Recebeu R$ ' . number_format($valorPago, 2) . ' (Transacional)', 'pagamentos', $pagamentoId);

        $db->commit();
        resposta(true, 'Pagamento registrado com sucesso.', [
            'id' => $pagamentoId,
            'pagasIntAgora' => $pagasIntAgora,
            'novoSaldoParcial' => $novoSaldoParcial,
            'quitadoTotal' => ($pagasIntAgora >= (int)$venda['num_parcelas'] && $novoSaldoParcial <= 0)
        ]);

    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[pagamentos.registrar_transacional] ' . $e->getMessage());
        resposta(false, 'Erro ao processar pagamento: ' . $e->getMessage());
    }
}

if ($action === 'pagamentos.listar') {
    try {
        [$adminWhere, $adminParams] = buildAdminFilter($adminId, 'p');
        // Exclui pagamentos de ajuste retroativo — estes são apenas
        // regularizações do banco de dados e não devem aparecer como
        // movimentação operacional na tela do operador.
        $retroExcl = retroativoSql('p');
        $sql = "
            SELECT p.*, c.nome as cliente_nome
            FROM pagamentos p
            LEFT JOIN clientes c ON p.cliente_id = c.id
            WHERE p.venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?)
            AND $adminWhere
            AND $retroExcl
            ORDER BY p.data_pagamento DESC
        ";
        $params = array_merge([$usuarioId], $adminParams);
        $st = $db->prepare($sql);
        $st->execute($params);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[pagamentos.listar] ' . $e->getMessage());
        resposta(false, 'Erro ao listar pagamentos.');
    }
}

if ($action === 'pagamentos.salvar') {
    if ($isClosed) resposta(false, 'Rota fechada ou antes das 08:00.');
    try {
        $d = $body['dados'] ?? [];

        // Buscar ruta ativa
        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;
        if (!$rutaId) {
            resposta(false, 'Nenhuma ruta ativa encontrada. Abra sua ruta antes de registrar pagamentos.');
        }

        // ── INSERT defensivo ────────────────────────────────────────────────
        $cols = [
            'venda_id','cliente_id','admin_id','tipo','valor_pago','forma_pagamento',
            'motivo','pagas_int_antes','pagas_int_agora','saldo_parcial_antes',
            'saldo_parcial_depois','quantidade_parcelas','data',
        ];
        $vals = [
            $d['vendaId'],              $d['clienteId'],
            $adminId,                   $d['tipo']??'pagamento',
            $d['valorPago'],            $d['formaPagamento']??null,
            $d['motivo']??null,         $d['pagasIntAntes']??0,
            $d['pagasIntAgora']??0,     $d['saldoParcialAntes']??0,
            $d['saldoParcialDepois']??0, $d['quantidadeParcelas']??0,
            $d['data']??date('Y-m-d'),
        ];
        if (hasCol('pagamentos.usuario_id')) {
            array_splice($cols, 2, 0, ['usuario_id']);
            array_splice($vals, 2, 0, [$usuarioId]);
        }
        if (hasCol('pagamentos.ruta_id')) {
            // Insere ruta_id depois de usuario_id (ou depois de cliente_id)
            $pos = array_search('admin_id', $cols);
            array_splice($cols, $pos, 0, ['ruta_id']);
            array_splice($vals, $pos, 0, [$rutaId]);
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $st = $db->prepare("INSERT INTO pagamentos ($cl) VALUES ($ph)");
        $st->execute($vals);
        $newId = (int)$db->lastInsertId();

        if (($d['tipo'] ?? 'pagamento') === 'nao-pagou' && !empty($d['parcelaNumero'])) {
            marcarHistoricoNaoPagou($db, $usuarioId, $adminId, (int)$d['vendaId'], (int)$d['parcelaNumero'], (string)($d['data'] ?? date('Y-m-d')), $newId);
        }

        // Ajustes retroativos não geram movimentação operacional.
        // Eles abatem o saldo da venda e entram nos cálculos financeiros,
        // mas não alteram o caixa, estatísticas diárias nem aparecem na
        // tela de Movimentações.
        if (!isRetroativo($d['motivo'] ?? null)) {
            registrarMovimentacao($db, $usuarioId, $adminId, 'pagamento',
                (float)$d['valorPago'], 'Recebimento', $newId, $d['clienteNome']??null);
        }
        logAcao('PAGAMENTO_REGISTRAR', 'Recebeu R$ ' . number_format($d['valorPago'], 2), 'pagamentos', $newId);
        resposta(true, 'Pagamento registrado.', ['id' => $newId]);

    } catch (Exception $e) {
        error_log('[pagamentos.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao registrar pagamento: ' . $e->getMessage());
    }
}

// ══════════════════════════════════════════════════════════════════
// MULTAS
// ══════════════════════════════════════════════════════════════════
if ($action === 'multas.listar') {
    try {
        $st = $db->prepare('
            SELECT m.*, c.nome as cliente_nome
            FROM multas m
            LEFT JOIN clientes c ON m.cliente_id = c.id
            WHERE m.venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?)
            ORDER BY m.criado_em DESC
        ');
        $st->execute([$usuarioId]);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[multas.listar] ' . $e->getMessage());
        resposta(false, 'Erro ao listar multas.');
    }
}

if ($action === 'multas.porVenda') {
    try {
        $vendaId = (int)($body['vendaId'] ?? $_GET['vendaId'] ?? 0);
        $st = $db->prepare('SELECT * FROM multas WHERE venda_id = ? ORDER BY criado_em DESC');
        $st->execute([$vendaId]);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[multas.porVenda] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar multas da venda.');
    }
}

if ($action === 'multas.buscar') {
    try {
        $id = (int)($body['id'] ?? 0);
        $st = $db->prepare('SELECT * FROM multas WHERE id = ?');
        $st->execute([$id]);
        $m = $st->fetch();
        $m ? resposta(true, '', $m) : resposta(false, 'Multa não encontrada.');
    } catch (Exception $e) {
        error_log('[multas.buscar] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar multa.');
    }
}

if ($action === 'multas.salvar') {
    try {
        $d = $body['dados'] ?? [];

        if (!empty($d['id'])) {
            $st = $db->prepare('UPDATE multas SET valor=?, motivo=?, status=?, pago_em=? WHERE id=?');
            $st->execute([
                $d['valor'],
                $d['motivo']??'Multa',
                $d['status']??'aberto', 
                $d['pagoEm']??null, 
                $d['id']
            ]);
            logAcao('MULTA_ATUALIZAR', 'Atualizou multa ID: ' . $d['id'] . ' (Valor: ' . $d['valor'] . ')', 'multas', $d['id']);
            resposta(true, 'Multa atualizada.', ['id' => $d['id']]);
        }

        // ── Nova multa — INSERT defensivo ───────────────────────────────────
        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;

        $cols = ['venda_id','cliente_id','parcela_ref','valor','motivo','origem','status','criado_em'];
        $vals = [
            $d['vendaId'],    $d['clienteId'],
            $d['parcelaRef']??null, $d['valor'],
            $d['motivo']??'Multa automática',
            $d['origem']??'auto', $d['status']??'aberto',
            $d['criadoEm']??date('Y-m-d'),
        ];
        if (hasCol('multas.usuario_id')) {
            $cols[] = 'usuario_id';
            $vals[] = $usuarioId;
        }
        if (hasCol('multas.ruta_id') && $rutaId) {
            $cols[] = 'ruta_id';
            $vals[] = $rutaId;
        }
        if (hasCol('multas.admin_id')) {
            $cols[] = 'admin_id';
            $vals[] = $adminId;
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $st = $db->prepare("INSERT INTO multas ($cl) VALUES ($ph)");
        $st->execute($vals);
        $multaId = (int)$db->lastInsertId();
        logAcao('MULTA_CRIAR', 'Criou multa: R$ ' . number_format($d['valor'], 2) . ' (' . ($d['motivo']??'Multa automática') . ')', 'multas', $multaId);
        resposta(true, 'Multa salva.', ['id' => $multaId]);

    } catch (Exception $e) {
        error_log('[multas.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar multa: ' . $e->getMessage());
    }
}

if ($action === 'multas.excluir') {
    try {
        $id = (int)($body['id'] ?? 0);
        
        $db->beginTransaction();
        
        // 1. Buscar a multa para saber o valor e limpar pagamentos/movimentações relacionados
        $stM = $db->prepare("SELECT * FROM multas WHERE id = ?");
        $stM->execute([$id]);
        $multa = $stM->fetch();
        
        if ($multa) {
            // NOTA IMPORTANTE — histórico de movimentações nunca é apagado.
            // Apenas a multa em si é removida (ela deixa de existir como
            // pendência); os pagamentos e as movimentações financeiras já
            // registrados permanecem no histórico, pois representam
            // dinheiro que já circulou de fato.
            //
            // Antes este bloco apagava (DELETE) os pagamentos e as
            // movimentações vinculadas à multa, o que fazia o histórico
            // "sumir". Isso foi removido de propósito.

            // Excluir a multa
            $db->prepare('DELETE FROM multas WHERE id = ?')->execute([$id]);

            logAcao('MULTA_EXCLUIR', 'Excluiu multa ID: ' . $id . ' (histórico de pagamentos/movimentações preservado)', 'multas', $id);
        }
        
        $db->commit();
        resposta(true, 'Multa excluída. Histórico de pagamentos e movimentações preservado.');
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[multas.excluir] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir multa: ' . $e->getMessage());
    }
}

if ($action === 'multas.excluirPorVenda') {
    try {
        $vendaId = (int)($body['vendaId'] ?? 0);
        $db->prepare('DELETE FROM multas WHERE venda_id = ?')->execute([$vendaId]);
        logAcao('MULTAS_EXCLUIR_VENDA', 'Excluiu multas da venda ID: ' . $vendaId, 'multas', $vendaId);
        resposta(true, 'Multas da venda excluídas.');
    } catch (Exception $e) {
        error_log('[multas.excluirPorVenda] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir multas da venda.');
    }
}

if ($action === 'multas.excluirPorCliente') {
    try {
        $clienteId = $body['clienteId'] ?? '';
        $db->prepare('DELETE FROM multas WHERE cliente_id = ?')->execute([$clienteId]);
        logAcao('MULTAS_EXCLUIR_CLIENTE', 'Excluiu multas do cliente ID: ' . $clienteId, 'multas', $clienteId);
        resposta(true, 'Multas do cliente excluídas.');
    } catch (Exception $e) {
        error_log('[multas.excluirPorCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir multas do cliente.');
    }
}

// ══════════════════════════════════════════════════════════════════
// FOTOS
// ══════════════════════════════════════════════════════════════════
if ($action === 'fotos.porCliente') {
    try {
        $clienteId = $body['clienteId'] ?? '';
        $st = $db->prepare('SELECT * FROM fotos WHERE cliente_id = ? ORDER BY ordem ASC, data_foto DESC');
        $st->execute([$clienteId]);
        resposta(true, '', $st->fetchAll());
    } catch (Exception $e) {
        error_log('[fotos.porCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar fotos.');
    }
}

if ($action === 'fotos.salvar') {
    try {
        $d = $body['dados'] ?? [];

        $ruta   = getRutaAtiva($db, $usuarioId);
        $rutaId = $ruta ? (int)$ruta['id'] : null;

        // ── INSERT defensivo ────────────────────────────────────────────────
        $imgData = $d['data'] ?? $d['base64'] ?? null;

        $cols = ['cliente_id','pagamento_id','data_foto','label','ordem'];
        $vals = [
            $d['clienteId'],
            $d['pagamentoId']??null,
            $d['dataFoto']??date('Y-m-d'),
            $d['label']??'',
            $d['ordem']??0,
        ];
        if (hasCol('fotos.imagem_base64')) {
            // Coluna moderna: salva base64 em imagem_base64, label fica como texto
            $cols[] = 'imagem_base64';
            $vals[] = $imgData;
        } elseif ($imgData !== null) {
            // Fallback legado: banco ainda não migrado, salva base64 no campo label
            $vals[3] = $imgData; // sobrescreve label com o base64
        }
        if (hasCol('fotos.usuario_id')) {
            $cols[] = 'usuario_id';
            $vals[] = $usuarioId;
        }
        if (hasCol('fotos.ruta_id') && $rutaId) {
            $cols[] = 'ruta_id';
            $vals[] = $rutaId;
        }

        $ph = implode(',', array_fill(0, count($vals), '?'));
        $cl = implode(',', $cols);
        $st = $db->prepare("INSERT INTO fotos ($cl) VALUES ($ph)");
        $st->execute($vals);
        $fotoId = (int)$db->lastInsertId();
        logAcao('FOTO_SALVAR', 'Salvou foto do cliente ID: ' . $d['clienteId'], 'fotos', $fotoId);
        resposta(true, 'Foto salva.', ['id' => $fotoId]);

    } catch (Exception $e) {
        error_log('[fotos.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar foto: ' . $e->getMessage());
    }
}

if ($action === 'fotos.excluir') {
    try {
        $id = (int)($body['id'] ?? 0);
        $db->prepare('DELETE FROM fotos WHERE id = ?')->execute([$id]);
        logAcao('FOTO_EXCLUIR', 'Excluiu foto ID: ' . $id, 'fotos', $id);
        resposta(true, 'Foto excluída.');
    } catch (Exception $e) {
        error_log('[fotos.excluir] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir foto.');
    }
}

if ($action === 'fotos.excluirPorCliente') {
    try {
        $clienteId = $body['clienteId'] ?? '';
        $db->prepare('DELETE FROM fotos WHERE cliente_id = ?')->execute([$clienteId]);
        logAcao('FOTOS_EXCLUIR_CLIENTE', 'Excluiu fotos do cliente ID: ' . $clienteId, 'fotos', $clienteId);
        resposta(true, 'Fotos do cliente excluídas.');
    } catch (Exception $e) {
        error_log('[fotos.excluirPorCliente] ' . $e->getMessage());
        resposta(false, 'Erro ao excluir fotos do cliente.');
    }
}

// ══════════════════════════════════════════════════════════════════
// RUTA / ROUTE
// ══════════════════════════════════════════════════════════════════
if ($action === 'ruta.get') {
    try {
        $ruta = getRutaAtiva($db, $usuarioId);
        if ($ruta) {
            $hoje = date('Y-m-d');
            // CORREÇÃO P2: filtro reforçado com ruta_id para evitar cruzamento entre rutas.
            // Usa data_pagamento (quando disponível) e prioriza pagamentos.ruta_id.
            $dateExprDia = hasCol('pagamentos.data_pagamento')
                ? 'COALESCE(p.data_pagamento, p.data)'
                : 'p.data';
            // Exclui ajustes retroativos do recebido_hoje — não contam
            // como recebimento do operador nem entram no caixa do dia.
            $retroExclDia = retroativoSql('p');
            if ($ruta && hasCol('pagamentos.ruta_id')) {
                $stDia = $db->prepare("
                    SELECT COALESCE(SUM(p.valor_pago),0) as recebido_hoje, COUNT(*) as pagamentos_hoje
                    FROM pagamentos p
                    WHERE p.ruta_id = ?
                      AND DATE({$dateExprDia}) = ?
                      AND $retroExclDia
                ");
                $stDia->execute([(int)$ruta['id'], $hoje]);
            } else {
                $stDia = $db->prepare("
                    SELECT COALESCE(SUM(p.valor_pago),0) as recebido_hoje, COUNT(*) as pagamentos_hoje
                    FROM pagamentos p
                    WHERE p.venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?)
                      AND DATE({$dateExprDia}) = ?
                      AND $retroExclDia
                ");
                $stDia->execute([$usuarioId, $hoje]);
            }
            $dia = $stDia->fetch();

            $stC = $db->prepare('SELECT COUNT(*) as total_clientes FROM clientes WHERE usuario_id = ?');
            $stC->execute([$usuarioId]);

            // Total em Aberto = SUM(total_com_juros) das vendas ainda ativas - SUM(valor_pago)
            // dessas mesmas vendas. Mesma fórmula usada em route.resumo (totalAReceber):
            // empréstimo + juros - parcelas recebidas. Antes esta consulta somava só o
            // total_com_juros das vendas em aberto sem descontar o que já foi pago nelas.
            $stE = $db->prepare("
                SELECT COALESCE(SUM(v.total_com_juros),0)
                     - COALESCE((SELECT SUM(p.valor_pago) FROM pagamentos p
                                 WHERE p.tipo = 'pagamento' AND p.venda_id IN (
                                     SELECT id FROM vendas WHERE usuario_id = ? AND parcelas_pagas < num_parcelas
                                 )), 0) as total_a_receber
                FROM vendas v WHERE v.usuario_id = ? AND v.parcelas_pagas < v.num_parcelas
            ");
            $stE->execute([$usuarioId, $usuarioId]);

            $stRec = $db->prepare('SELECT COALESCE(SUM(p.valor_pago),0) as total_recebido FROM pagamentos p WHERE p.venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?)');
            $stRec->execute([$usuarioId]);

            $ruta = array_merge($ruta, $dia, $stC->fetch(), $stE->fetch(), $stRec->fetch());
        }
        resposta(true, '', $ruta ?: null);
    } catch (Exception $e) {
        error_log('[ruta.get] ' . $e->getMessage());
        resposta(false, 'Erro ao buscar ruta.');
    }
}

if ($action === 'route.resumo') {
    try {
        $ruta = getRutaAtiva($db, $usuarioId);
        if (!$ruta) resposta(false, 'Ruta não encontrada.');
        $rutaId = (int)$ruta['id'];

        $data = $body['data'] ?? $_GET['data'] ?? date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) $data = date('Y-m-d');

        // 1) CLIENTES — 3 SELECT COUNT(*) combinados em 1 única consulta (agregação condicional)
        $st = $db->prepare("
            SELECT
                SUM(CASE WHEN DATE(criado_em) < :data THEN 1 ELSE 0 END) AS clientes_inicio,
                SUM(CASE WHEN DATE(criado_em) = :data THEN 1 ELSE 0 END) AS clientes_novos,
                COUNT(*) AS total_clientes
            FROM clientes WHERE usuario_id = :usuario_id
        ");
        $st->execute(['data' => $data, 'usuario_id' => $usuarioId]);
        $rowClientes = $st->fetch() ?: [];
        $clientesInicio = (int)($rowClientes['clientes_inicio'] ?? 0);
        $clientesNovos  = (int)($rowClientes['clientes_novos']  ?? 0);
        $totalClientes  = (int)($rowClientes['total_clientes']  ?? 0);
        $clientesFinal  = $clientesInicio + $clientesNovos;

        // 4) VENDAS — clientesRenovacao + totais do dia + totais acumulados,
        // antes espalhados em 4 SELECTs (clientesRenovacao, valorInvestidoDia, vDia, vendasTotais).
        // Uma única varredura da tabela `vendas` com agregação condicional resolve todos.
        $st = $db->prepare("
            SELECT
                COUNT(DISTINCT CASE WHEN tipo = 'renovacao' AND DATE(criado_em) = :data THEN cliente_id END) AS clientes_renovacao,
                SUM(CASE WHEN DATE(criado_em) = :data THEN 1 ELSE 0 END) AS vendas_qtd_dia,
                COALESCE(SUM(CASE WHEN DATE(criado_em) = :data THEN valor_emprestimo ELSE 0 END),0) AS vendas_valor_dia,
                SUM(CASE WHEN DATE(criado_em) = :data AND tipo = 'nova'      THEN 1 ELSE 0 END) AS vendas_novas_qtd,
                SUM(CASE WHEN DATE(criado_em) = :data AND tipo = 'renovacao' THEN 1 ELSE 0 END) AS vendas_renov_qtd,
                COALESCE(SUM(CASE WHEN DATE(criado_em) = :data AND tipo = 'nova'      THEN valor_emprestimo ELSE 0 END),0) AS vendas_novas_valor,
                COALESCE(SUM(CASE WHEN DATE(criado_em) = :data AND tipo = 'renovacao' THEN valor_emprestimo ELSE 0 END),0) AS vendas_renov_valor,
                COALESCE(SUM(valor_emprestimo),0) AS total_emprestado,
                COALESCE(SUM(juros_valor),0) AS total_juros
            FROM vendas WHERE usuario_id = :usuario_id
        ");
        $st->execute(['data' => $data, 'usuario_id' => $usuarioId]);
        $vAgg = $st->fetch() ?: [];

        $clientesRenovacao = (int)($vAgg['clientes_renovacao']  ?? 0);
        $vendasQtd          = (int)($vAgg['vendas_qtd_dia']      ?? 0);
        $vendasValor        = (float)($vAgg['vendas_valor_dia']   ?? 0);
        $vendasNovasQtd     = (int)($vAgg['vendas_novas_qtd']    ?? 0);
        $vendasRenovQtd     = (int)($vAgg['vendas_renov_qtd']    ?? 0);
        $vendasNovasValor   = (float)($vAgg['vendas_novas_valor'] ?? 0);
        $vendasRenovValor   = (float)($vAgg['vendas_renov_valor'] ?? 0);
        // valorInvestidoDia é exatamente o mesmo agregado que vendas_valor_dia — reutiliza, sem nova query.
        $valorInvestidoDia  = $vendasValor;
        $vendasTotais = [
            'totalEmprestado' => (float)($vAgg['total_emprestado'] ?? 0),
            'totalJuros'      => (float)($vAgg['total_juros']      ?? 0),
        ];

        // 2) COBRANÇA — clientesCobrados, baixasQtd, clientesPagaram e valorEsperado
        // antes eram 4 SELECTs separados sobre "parcelas JOIN vendas"; agora é 1 só.
        //
        // REGRA CRÍTICA DO RESUMO DIÁRIO:
        // valorEsperado é a previsão original do dia. Portanto, soma TODAS as
        // parcelas cuja data_vencimento é exatamente a data consultada, sem
        // excluir parcelas pagas, parciais ou baixadas. Pagamentos influenciam
        // somente os indicadores de recebido/baixado e de saldo em aberto.
        // Fallback: data_pagamento pode ser NULL em registros antigos — usa data_vencimento.
        $dateExprParcelas = hasCol('parcelas.data_pagamento')
            ? 'COALESCE(p.data_pagamento, p.data_vencimento)'
            : 'p.data_vencimento';

        $st = $db->prepare("
            SELECT
                COUNT(DISTINCT CASE WHEN p.data_vencimento = :data THEN p.cliente_id END) AS clientes_cobrados,
                SUM(CASE WHEN p.status IN ('pago','quitado') AND DATE({$dateExprParcelas}) = :data THEN 1 ELSE 0 END) AS baixas_qtd,
                COUNT(DISTINCT CASE WHEN p.status IN ('pago','quitado') AND DATE({$dateExprParcelas}) = :data THEN p.cliente_id END) AS clientes_pagaram,
                COALESCE(SUM(CASE WHEN p.data_vencimento = :data THEN p.valor ELSE 0 END),0) AS valor_esperado
            FROM parcelas p JOIN vendas v ON v.id = p.venda_id
            WHERE v.usuario_id = :usuario_id
        ");
        $st->execute(['data' => $data, 'usuario_id' => $usuarioId]);
        $pAgg = $st->fetch() ?: [];

        $clientesCobrados  = (int)($pAgg['clientes_cobrados'] ?? 0);
        $baixasQtd         = (int)($pAgg['baixas_qtd']        ?? 0);
        $clientesPagaram   = (int)($pAgg['clientes_pagaram']  ?? 0);
        $clientesPendentes = max(0, $clientesCobrados - $clientesPagaram);
        $valorEsperado     = (float)($pAgg['valor_esperado']  ?? 0);

        // 3) FINANCEIRO — movimentações "antes", "do dia" e "acumuladas" antes eram
        // 3 SELECTs GROUP BY tipo separados; agora uma única varredura com 3 somas condicionais.
        // Exclui movimentações de pagamentos retroativos (defesa em profundidade).
        $st = $db->prepare("
            SELECT tipo,
                COALESCE(SUM(CASE WHEN data_mov < :data THEN valor ELSE 0 END),0) AS total_antes,
                COALESCE(SUM(CASE WHEN DATE(data_mov) = :data THEN valor ELSE 0 END),0) AS total_dia,
                COALESCE(SUM(valor),0) AS total_acum
            FROM movimentacoes WHERE ruta_id = :ruta_id
              AND (tipo != 'pagamento' OR COALESCE(descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(descricao, '') NOT LIKE '%retroativo%')
            GROUP BY tipo
        ");
        $st->execute(['data' => $data, 'ruta_id' => $rutaId]);
        $movsAntes = []; $movsDia = []; $movsAcum = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $tipo = $row['tipo'];
            $movsAntes[$tipo] = (float)$row['total_antes'];
            $movsDia[$tipo]   = (float)$row['total_dia'];
            $movsAcum[$tipo]  = (float)$row['total_acum'];
        }

        $pagAntes     = (float)($movsAntes['pagamento']  ?? 0);
        $empAntes     = abs((float)($movsAntes['emprestimo'] ?? 0));
        $mulAntes     = (float)($movsAntes['multa']      ?? 0);
        $apoAntes     = (float)($movsAntes['aporte']     ?? 0);
        $retAntes     = abs((float)($movsAntes['retirada']?? 0));
        $depAntes     = abs((float)($movsAntes['despesa'] ?? 0));
        $ajuAntes     = (float)($movsAntes['ajuste']     ?? 0);
        $saldoInicial = (float)$ruta['capital_base']
                        + $pagAntes - $empAntes + $mulAntes
                        + $apoAntes - $retAntes  - $depAntes + $ajuAntes;

        // TOTAL RECEBIDO (base financeira do dia)
        // Exclui pagamentos de ajuste retroativo — não contam para caixa
        // do dia, estatísticas diárias nem eficiência de cobrança.
        {
            $dateExpr = hasCol('pagamentos.data_pagamento')
                ? 'COALESCE(p.data_pagamento, p.data)'
                : 'p.data';
            $retroExcl = retroativoSql('p');

            // Query base para pagamentos
            $sqlBase = "SELECT 
                            COALESCE(SUM(CASE WHEN p.tipo = 'pagamento' THEN p.valor_pago ELSE 0 END), 0) as recebido_parcelas,
                            COALESCE(SUM(CASE WHEN p.tipo LIKE 'multa%' THEN p.valor_pago ELSE 0 END), 0) as recebido_multas
                        FROM pagamentos p";

            if (hasCol('pagamentos.ruta_id')) {
                $stR = $db->prepare("$sqlBase WHERE p.ruta_id = ? AND DATE({$dateExpr}) = ? AND $retroExcl");
                $stR->execute([$rutaId, $data]);
            } elseif (hasCol('vendas.ruta_id')) {
                $stR = $db->prepare("$sqlBase JOIN vendas v ON v.id = p.venda_id WHERE v.ruta_id = ? AND DATE({$dateExpr}) = ? AND $retroExcl");
                $stR->execute([$rutaId, $data]);
            } else {
                $stR = $db->prepare("$sqlBase JOIN vendas v ON v.id = p.venda_id WHERE v.usuario_id = ? AND DATE({$dateExpr}) = ? AND $retroExcl");
                $stR->execute([$usuarioId, $data]);
            }
            $rowRecebido = $stR->fetch();
            $recebidoParcelas = (float)$rowRecebido['recebido_parcelas'];
            $recebidoMultas   = (float)$rowRecebido['recebido_multas'];
            $totalRecebido    = $recebidoParcelas + $recebidoMultas;
        }

        // A eficiência de cobrança compara somente parcelas previstas com
        // pagamentos de parcelas. Multas não fazem parte do Total esperado.
        $valorRecebidoParcelas = $recebidoParcelas;
        $valorEmAberto = max(0.0, $valorEsperado - $valorRecebidoParcelas);
        $percentualCobranca = $valorEsperado > 0
            ? round(($valorRecebidoParcelas / $valorEsperado) * 100, 2)
            : 0.0;

        // JUROS RECEBIDOS HOJE — proporcional ao valor pago hoje em relação ao
        // percentual de juros de cada venda (juros_valor / total_com_juros).
        // Não há coluna de juros por parcela/pagamento, então o rateio usa
        // a proporção contratada na venda.
        // Exclui ajustes retroativos — não contam como juros recebidos hoje.
        {
            $dateExprJuros = hasCol('pagamentos.data_pagamento')
                ? 'COALESCE(p.data_pagamento, p.data)'
                : 'p.data';
            $retroExclJ = retroativoSql('p');

            $sqlJuros = "SELECT COALESCE(SUM(
                            CASE WHEN v.total_com_juros > 0
                                 THEN p.valor_pago * (v.juros_valor / v.total_com_juros)
                                 ELSE 0 END
                         ), 0) AS juros_recebidos_hoje
                         FROM pagamentos p
                         JOIN vendas v ON v.id = p.venda_id
                         WHERE p.tipo = 'pagamento' AND DATE({$dateExprJuros}) = ? AND $retroExclJ";

            if (hasCol('pagamentos.ruta_id')) {
                $stJ = $db->prepare("$sqlJuros AND p.ruta_id = ?");
                $stJ->execute([$data, $rutaId]);
            } elseif (hasCol('vendas.ruta_id')) {
                $stJ = $db->prepare("$sqlJuros AND v.ruta_id = ?");
                $stJ->execute([$data, $rutaId]);
            } else {
                $stJ = $db->prepare("$sqlJuros AND v.usuario_id = ?");
                $stJ->execute([$data, $usuarioId]);
            }
            $jurosRecebidosHoje = (float)$stJ->fetchColumn();
        }

        // 5) OUTROS EVENTOS DO DIA (já extraídos do agregado único de movimentações acima)
        $despesas      = abs((float)($movsDia['despesa']  ?? 0));
        $retiradas     = abs((float)($movsDia['retirada'] ?? 0));
        $ingressosAdic = (float)($movsDia['aporte']  ?? 0);
        $ajusteCaixa   = (float)($movsDia['ajuste']  ?? 0);
        $multasDia     = (float)($movsDia['multa']   ?? 0);

        // 6) SALDO FINAL
        $saldoFinal = $saldoInicial + $totalRecebido + $multasDia
                    + $ingressosAdic + $ajusteCaixa
                    - $valorInvestidoDia - $despesas - $retiradas;

        // Indicadores acumulados (compat UI antiga) — também já vêm do agregado único acima
        $pagAcum  = (float)($movsAcum['pagamento']  ?? 0);
        $empAcum  = abs((float)($movsAcum['emprestimo'] ?? 0));
        $mulAcum  = (float)($movsAcum['multa']      ?? 0);
        $apoAcum  = (float)($movsAcum['aporte']     ?? 0);
        $retAcum  = abs((float)($movsAcum['retirada']?? 0));
        $depAcum  = abs((float)($movsAcum['despesa'] ?? 0));
        $ajuAcum  = (float)($movsAcum['ajuste']     ?? 0);
        // ════════════════════════════════════════════════════════════════
        // SALDO FINAL DA ROTA — fórmula fixa, não alterar sem atualizar este comentário:
        //   Saldo Final da Rota = Investido + Aporte + Recolhido (pagamentos) - Vendido (emprestado) - Despesa
        // ════════════════════════════════════════════════════════════════
        $caixa      = (float)$ruta['capital_base'] + $apoAcum + $pagAcum - $empAcum - $depAcum;
        $lucro      = $pagAcum + $mulAcum;

        // ════════════════════════════════════════════════════════════════
        // TOTAL DE PARCELAS RECEBIDAS (fonte de verdade = tabela pagamentos)
        // Antes vinha de $pagAcum (movimentacoes), que excluía retroativos.
        // Agora é calculado direto da tabela pagamentos (tipo='pagamento'),
        // incluindo retroativos, para que:
        //   Total Emprestado + Juros = Total Parcelas Recebidas + Total em Aberto
        // sempre bata corretamente.
        // ════════════════════════════════════════════════════════════════
        if (hasCol('pagamentos.ruta_id')) {
            $stRecAcum = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE ruta_id = ? AND tipo = 'pagamento'");
            $stRecAcum->execute([$rutaId]);
        } elseif (hasCol('vendas.ruta_id')) {
            $stRecAcum = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE venda_id IN (SELECT id FROM vendas WHERE ruta_id = ?) AND tipo = 'pagamento'");
            $stRecAcum->execute([$rutaId]);
        } else {
            $stRecAcum = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?) AND tipo = 'pagamento'");
            $stRecAcum->execute([$usuarioId]);
        }
        $totalParcelasRecebidas = (float)$stRecAcum->fetchColumn();

        // ════════════════════════════════════════════════════════════════
        // TOTAL DE JUROS RECEBIDOS (fonte de verdade = tabela pagamentos)
        // Calcula a proporção de juros recebidos sobre o total pago,
        // usando a proporção contratada em cada venda (juros_valor / total_com_juros).
        // Inclui retroativos para manter consistência com Total Parcelas Recebidas.
        // ════════════════════════════════════════════════════════════════
        if (hasCol('pagamentos.ruta_id')) {
            $stJurosAcum = $db->prepare("
                SELECT COALESCE(SUM(
                    CASE WHEN v.total_com_juros > 0
                         THEN p.valor_pago * (v.juros_valor / v.total_com_juros)
                         ELSE 0 END
                ), 0) AS juros_recebidos_acum
                FROM pagamentos p
                JOIN vendas v ON v.id = p.venda_id
                WHERE p.tipo = 'pagamento' AND p.ruta_id = ?
            ");
            $stJurosAcum->execute([$rutaId]);
        } elseif (hasCol('vendas.ruta_id')) {
            $stJurosAcum = $db->prepare("
                SELECT COALESCE(SUM(
                    CASE WHEN v.total_com_juros > 0
                         THEN p.valor_pago * (v.juros_valor / v.total_com_juros)
                         ELSE 0 END
                ), 0) AS juros_recebidos_acum
                FROM pagamentos p
                JOIN vendas v ON v.id = p.venda_id
                WHERE p.tipo = 'pagamento' AND v.ruta_id = ?
            ");
            $stJurosAcum->execute([$rutaId]);
        } else {
            $stJurosAcum = $db->prepare("
                SELECT COALESCE(SUM(
                    CASE WHEN v.total_com_juros > 0
                         THEN p.valor_pago * (v.juros_valor / v.total_com_juros)
                         ELSE 0 END
                ), 0) AS juros_recebidos_acum
                FROM pagamentos p
                JOIN vendas v ON v.id = p.venda_id
                WHERE p.tipo = 'pagamento' AND v.usuario_id = ?
            ");
            $stJurosAcum->execute([$usuarioId]);
        }
        $totalJurosRecebidos = (float)$stJurosAcum->fetchColumn();

        // ════════════════════════════════════════════════════════════════
        // EMPRESTADO ATUALMENTE NA RUA — fórmula fixa, não alterar sem atualizar
        // este comentário:
        //   Emprestado Atualmente = SUM(valor_emprestimo) das vendas AINDA ABERTAS
        //   (parcelas_pagas < num_parcelas), ou seja, o capital de empréstimo que
        //   ainda está "na rua". Diferente de Total Emprestado (histórico/acumulado
        //   de tudo que já foi emprestado, incluindo vendas já quitadas).
        // Efeito esperado:
        //   - Nova venda criada  -> soma o valor_emprestimo (entra na rua).
        //   - Venda quitada      -> some deste total (sai da rua), pois passa a
        //                           ter parcelas_pagas >= num_parcelas.
        // ════════════════════════════════════════════════════════════════
        if (hasCol('vendas.ruta_id')) {
            $stEmpAtual = $db->prepare("SELECT COALESCE(SUM(valor_emprestimo),0) FROM vendas WHERE ruta_id = ? AND parcelas_pagas < num_parcelas");
            $stEmpAtual->execute([$rutaId]);
        } else {
            $stEmpAtual = $db->prepare("SELECT COALESCE(SUM(valor_emprestimo),0) FROM vendas WHERE usuario_id = ? AND parcelas_pagas < num_parcelas");
            $stEmpAtual->execute([$usuarioId]);
        }
        $emprestadoAtualmente = (float)$stEmpAtual->fetchColumn();

        // ════════════════════════════════════════════════════════════════
        // SALDO GERAL — fórmula fixa, não alterar sem atualizar este comentário:
        //   Saldo Geral = Valor Investido na Ruta + Aportes + Valor Recolhido da Ruta - Valor Emprestado
        // ════════════════════════════════════════════════════════════════
        $valorInvestidoRuta = (float)($ruta['capital_base'] ?? 0);
        $saldoGeral = $valorInvestidoRuta + $apoAcum + $retAcum - $empAcum;

        // MULTAS — totalMultas e multasAbertas antes eram 2 SELECTs separados; agora 1 só.
        $st = $db->prepare("
            SELECT
                COALESCE(SUM(valor),0) AS total_multas,
                COALESCE(SUM(CASE WHEN status = 'aberto' THEN valor ELSE 0 END),0) AS multas_abertas
            FROM multas WHERE venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?)
        ");
        $st->execute([$usuarioId]);
        $mAgg = $st->fetch() ?: [];
        $totalMultas   = (float)($mAgg['total_multas']   ?? 0);
        $multasAbertas = (float)($mAgg['multas_abertas'] ?? 0);

        // TOTAL QUE OS CLIENTES AINDA DEVEM (saldo devedor real, dados reais do banco)
        //   = SUM(total_com_juros) das vendas da RUTA - SUM(valor_pago) dos pagamentos dessas vendas.
        // Escopado por ruta_id (com fallback para usuario_id em bancos antigos) para não
        // misturar/duplicar dados de outras rutas do mesmo usuário.
        if (hasCol('vendas.ruta_id')) {
            $stD = $db->prepare("SELECT COALESCE(SUM(total_com_juros),0) FROM vendas WHERE ruta_id = ?");
            $stD->execute([$rutaId]);
        } else {
            $stD = $db->prepare("SELECT COALESCE(SUM(total_com_juros),0) FROM vendas WHERE usuario_id = ?");
            $stD->execute([$usuarioId]);
        }
        $totalEmprestadoComJuros = (float)$stD->fetchColumn();

        // IMPORTANTE: filtra tipo = 'pagamento' para contar SOMENTE baixas de parcela
        // (empréstimo + juros). Pagamentos de multa (tipo 'multa', 'multa-pago',
        // 'multa-convertida') NÃO fazem parte de total_com_juros e por isso não podem
        // entrar nesta subtração — senão o Total em Aberto ficaria contaminado por
        // valores que não são parcela e deixaria de refletir "quanto falta em parcelas".
        if (hasCol('pagamentos.ruta_id')) {
            $stP = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE ruta_id = ? AND tipo = 'pagamento'");
            $stP->execute([$rutaId]);
        } elseif (hasCol('vendas.ruta_id')) {
            $stP = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE venda_id IN (SELECT id FROM vendas WHERE ruta_id = ?) AND tipo = 'pagamento'");
            $stP->execute([$rutaId]);
        } else {
            $stP = $db->prepare("SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?) AND tipo = 'pagamento'");
            $stP->execute([$usuarioId]);
        }
        $totalPagoPelosClientes = (float)$stP->fetchColumn();

        $totalClientesDevem = $totalEmprestadoComJuros - $totalPagoPelosClientes;

        // ════════════════════════════════════════════════════════════════
        // TOTAL EM ABERTO — fórmula fixa, não alterar sem atualizar este comentário:
        //   Total em Aberto = Total que os Clientes Devem - Total Recolhido (só parcelas)
        //   onde:
        //     Total que os Clientes Devem = SUM(total_com_juros) das vendas da ruta
        //     Total Recolhido             = SUM(valor_pago) dos pagamentos com
        //                                    tipo = 'pagamento' (baixas de PARCELA),
        //                                    excluindo pagamentos de multa
        // Representa exatamente quantos reais em PARCELAS ainda faltam os clientes
        // pagarem (saldo devedor de empréstimo + juros). Não inclui multas, capital
        // investido, aportes ou retiradas — isso é assunto de outros campos (Total
        // de Multas, Saldo Geral), não do Total em Aberto.
        // ════════════════════════════════════════════════════════════════
        $totalAReceber = $totalClientesDevem;


        // TOTAL ESPERADO HOJE — mesma previsão fixa exibida no Resumo Diário.
        // Nunca subtrai pagamentos e nunca filtra por status de baixa.
        $totalEsperadoHoje = $valorEsperado;

        // TOTAL RECEBIDO HOJE (apenas parcelas; multas ficam separadas)
        $totalRecebidoHoje = $valorRecebidoParcelas;

        // EFICIÊNCIA DE COBRANÇA
        // Fórmula: (total_recebido_parcelas / total_esperado_parcelas) * 100
        $eficienciaCobranca = $totalEsperadoHoje > 0
            ? round(($totalRecebidoHoje / $totalEsperadoHoje) * 100, 2)
            : 0.0;

        resposta(true, '', [
            'data' => $data, 'rutaId' => $rutaId, 'rutaNome' => $ruta['nome'] ?? '',
            'valorInvestidoRuta' => $valorInvestidoRuta,
            'totalEsperadoHoje' => $totalEsperadoHoje,
            'totalRecebidoHoje' => $totalRecebidoHoje,
            'recebidoMultasHoje' => $recebidoMultas,
            'recebidoTotalHoje' => $totalRecebido,
            'eficienciaCobranca' => $eficienciaCobranca,
            'clientesInicio' => $clientesInicio, 'clientesNovos' => $clientesNovos,
            'clientesRenovacao' => $clientesRenovacao,
            'clientesFinal' => $clientesFinal, 'totalClientes' => $totalClientes,
            'clientesCobrados' => $clientesCobrados, 'baixasQtd' => $baixasQtd,
            'clientesPagaram' => $clientesPagaram, 'clientesPendentes' => $clientesPendentes,
            'saldoInicial' => $saldoInicial, 'valorInvestidoDia' => $valorInvestidoDia,
            'valorEsperado' => $valorEsperado, 'valorRecebido' => $valorRecebidoParcelas,
            'valorEmAberto' => $valorEmAberto,
            'percentualCobranca' => $percentualCobranca, 'totalRecebido' => $totalRecebido,
            'totalEsperadoFixo' => $valorEsperado,
            'totalRecebidoParcelas' => $valorRecebidoParcelas,
            'totalEmAberto' => $valorEmAberto,
            'vendasQtd' => $vendasQtd, 'vendasValor' => $vendasValor,
            'vendasNovasQtd' => $vendasNovasQtd, 'vendasNovasValor' => $vendasNovasValor,
            'vendasRenovQtd' => $vendasRenovQtd, 'vendasRenovValor' => $vendasRenovValor,
            'despesas' => $despesas, 'retiradas' => $retiradas,
            'ingressosAdicionais' => $ingressosAdic, 'ajusteCaixa' => $ajusteCaixa,
            'multasDia' => $multasDia, 'entradas' => $ingressosAdic,
            // Movimentações do dia — chaves explícitas (mesmos valores, sem nova query)
            'entradasHoje'  => $ingressosAdic,
            'retiradasHoje' => $retiradas,
            'despesasHoje'  => $despesas,
            'ajustesHoje'   => $ajusteCaixa,
            'saldoFinal' => $saldoFinal,
            'recaldo' => $totalRecebido - $valorInvestidoDia, 'caixa' => $caixa,
            'lucro' => $lucro, 'saldoGeral' => $saldoGeral,
            'totalEmprestado' => (float)$vendasTotais['totalEmprestado'],
            'emprestadoAtualmente' => $emprestadoAtualmente,
            'totalJuros' => $totalJurosRecebidos,
            'totalMultas' => $totalMultas, 'totalAReceber' => $totalAReceber,
            'totalClientesDevem' => $totalClientesDevem,
            'totalAportes' => $apoAcum, 'totalRetiradas' => $retAcum,
            'totalParcelasRecebidas' => $totalParcelasRecebidas,
            'jurosRecebidosHoje' => $jurosRecebidosHoje,
        ]);
    } catch (Exception $e) {
        error_log('[route.resumo] ' . $e->getMessage());
        resposta(false, 'Erro ao gerar resumo da ruta: ' . $e->getMessage());
    }
}

if ($action === 'ruta.salvar') {
    try {
        $d    = $body['dados'] ?? [];
        $ruta = getRutaAtiva($db, $usuarioId);
        if ($ruta) {
            $fields = ['nome=?', 'capital_base=?'];
            $params = [$d['nome']??$ruta['nome'], (float)($d['capital_base']??$ruta['capital_base'])];
            if (!empty($d['pin'])) { $fields[] = 'pin=?'; $params[] = $d['pin']; }
            $params[] = $usuarioId;
            $db->prepare('UPDATE rutas SET ' . implode(',', $fields) . ' WHERE usuario_id=? AND ativa=1')->execute($params);
            logAcao('RUTA_SALVAR', 'Salvou configurações da RUTA');
            resposta(true, 'Configurações da RUTA salvas.');
        } else {
            resposta(false, 'Nenhuma RUTA ativa encontrada para este usuário. Apenas atualizações são permitidas.');
        }
    } catch (Exception $e) {
        error_log('[ruta.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao salvar ruta: ' . $e->getMessage());
    }
}

if ($action === 'ruta.gerarCodigo') {
    try {
        $codigo = strtoupper(bin2hex(random_bytes(5)));
        $ruta   = getRutaAtiva($db, $usuarioId);
        if (!$ruta) resposta(false, 'Nenhuma RUTA ativa encontrada.');
        $db->prepare('UPDATE rutas SET codigo_vinculo = ? WHERE id = ?')->execute([$codigo, $ruta['id']]);
        logAcao('RUTA_GERAR_CODIGO', 'Gerou novo código de vínculo: ' . $codigo);
        resposta(true, '', ['codigo' => $codigo]);
    } catch (Exception $e) {
        error_log('[ruta.gerarCodigo] ' . $e->getMessage());
        resposta(false, 'Erro ao gerar código de vínculo.');
    }
}

if ($action === 'route.eventos.salvar') {
    try {
        $d     = $body['dados'] ?? $body;
        $tipo  = $d['tipo']  ?? 'aporte';
        $valor = (float)($d['valor'] ?? 0);
        $desc  = $d['descricao'] ?? null;
        if ($valor <= 0) resposta(false, 'Valor deve ser maior que zero.');
        if (!in_array($tipo, ['aporte','retirada','ajuste','despesa'])) resposta(false, 'Tipo inválido.');
        registrarMovimentacao($db, $usuarioId, $adminId, $tipo, $valor, $desc);
        try {
            $db->prepare('INSERT INTO route_eventos (usuario_id, tipo, valor, descricao, data_evento) VALUES (?,?,?,?,?)')
               ->execute([$usuarioId, $tipo, $valor, $desc, date('Y-m-d')]);
        } catch (Exception $e2) { /* tabela pode não existir em versões antigas */ }
        logAcao('RUTA_EVENTO', 'Evento ' . $tipo . ': R$ ' . number_format($valor, 2));
        resposta(true, 'Evento registrado.');
    } catch (Exception $e) {
        error_log('[route.eventos.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao registrar evento: ' . $e->getMessage());
    }
}

// ══════════════════════════════════════════════════════════════════
// FECHAMENTO
// ══════════════════════════════════════════════════════════════════
if ($action === 'fechamento.status') {
    resposta(true, '', ['fechado' => $isClosed]);
}

if ($action === 'fechamento.salvar' || $action === 'fechamento.executar') {
    try {
        $data = $body['data'] ?? date('Y-m-d');
        $db->prepare('INSERT IGNORE INTO fechamentos (usuario_id, admin_id, data_fechamento) VALUES (?,?,?)')
           ->execute([$usuarioId, $adminId, $data]);
        logAcao('FECHAMENTO_ROTA', 'Fechou a rota do dia ' . $data);
        resposta(true, 'Rota fechada com sucesso.');
    } catch (Exception $e) {
        error_log('[fechamento.salvar] ' . $e->getMessage());
        resposta(false, 'Erro ao fechar rota: ' . $e->getMessage());
    }
}

// ══════════════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════════════
if ($action === 'dashboard.dados') {
    try {
        $retroExclDash = retroativoSql('p');
        $st = $db->prepare("
            SELECT
                (SELECT COUNT(*) FROM clientes WHERE usuario_id = ?) as total_clientes,
                (SELECT COUNT(*) FROM vendas WHERE usuario_id = ? AND parcelas_pagas < num_parcelas) as total_vendas_ativas,
                (SELECT COALESCE(SUM(p.valor_pago),0) FROM pagamentos p
                 WHERE p.venda_id IN (SELECT id FROM vendas WHERE usuario_id = ?) AND p.data = CURDATE()
                   AND $retroExclDash
                ) as total_recebido_hoje
        ");
        $st->execute([$usuarioId, $usuarioId, $usuarioId]);
        resposta(true, '', $st->fetch());
    } catch (Exception $e) {
        error_log('[dashboard.dados] ' . $e->getMessage());
        resposta(false, 'Erro ao carregar dashboard.');
    }
}

// ══════════════════════════════════════════════════════════════════
// FALLBACK
// ══════════════════════════════════════════════════════════════════
resposta(false, 'Ação não reconhecida: ' . htmlspecialchars($action));
?>
