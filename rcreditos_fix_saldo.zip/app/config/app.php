<?php
/**
 * ════════════════════════════════════════════════════════════════════════════
 * R. CRÉDITOS — Configuração Global com JWT
 * Versão: 2.1.0 (CORRIGIDA — sem conflito de constantes)
 * Otimizado para InfinityFree - PHP 7.2+
 * ════════════════════════════════════════════════════════════════════════════
 */

// ── Banco compartilhado ───────────────────────────────────────────
require_once __DIR__ . '/../../shared/db.php';

// ── Constantes do App (protegidas contra redeclaração) ────────────
if (!defined('APP_NAME'))         define('APP_NAME',         'R. Créditos');
if (!defined('APP_VERSION'))      define('APP_VERSION',      '2.1.1');
if (!defined('SESSION_LIFETIME')) define('SESSION_LIFETIME', 28800); // 8 horas

// ── Configuração JWT (Centralizada aqui) ──────────────────────────
if (!defined('JWT_SECRET'))     define('JWT_SECRET',     'a3f9c2e1d8b4f7a9c3e5d2f8a1b4c7e9d2f5a8b1c4e7a0d3f6b9c2e5a8b1c4');
if (!defined('JWT_ALGORITHM'))  define('JWT_ALGORITHM',  'HS256');
if (!defined('JWT_EXPIRATION')) define('JWT_EXPIRATION', 28800); // 8 horas

// ── BASE_URL dinâmica (CORRIGIDA para InfinityFree) ───────────────
if (!defined('BASE_URL')) {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');

    // Determina a raiz removendo todos os caminhos de subpastas conhecidos
    $raiz = $script;
    $subpastas = [
        '/app/pages/', '/app/auth/', '/app/config/', '/app/api/',
        '/app/pages',  '/app/auth',  '/app/config',  '/app/api',
        '/app/',       '/app',
        '/admin/pages/', '/admin/includes/', '/admin/',
        '/admin/pages',  '/admin/includes',  '/admin',
    ];
    foreach ($subpastas as $sub) {
        $pos = strpos($raiz, $sub);
        if ($pos !== false) {
            $raiz = substr($raiz, 0, $pos);
            break;
        }
    }
    // Remove o arquivo final (ex: /index.php)
    $raiz = dirname($raiz);
    if ($raiz === '.') $raiz = '';
    $raiz = rtrim($raiz, '/');

    define('BASE_URL', '//' . $host . $raiz);
}

// ── Timezone ──────────────────────────────────────────────────────
date_default_timezone_set('America/Sao_Paulo');

// ── Sessão (CORRIGIDA: strip de porta para compatibilidade LiteSpeed) ─
if (session_status() === PHP_SESSION_NONE) {
    session_name('RCREDITOS_APP');
    // Remove porta do host (ex: "site.com:80" → "site.com") para evitar
    // falha de cookie no LiteSpeed/InfinityFree
    $cookieDomain = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    session_set_cookie_params(0, '/', $cookieDomain, false, true);
    session_start();
}

// ── Inclusão de Componentes de Autenticação ───────────────────────
require_once __DIR__ . '/../../includes/jwt.php';
JWT::setSecret(JWT_SECRET);

require_once __DIR__ . '/../../includes/auth_helper.php';
require_once __DIR__ . '/../auth/guard.php';

/**
 * Log de Ações (integrado com logs_acoes do banco compartilhado)
 * CORRIGIDO: protegido contra redeclaração
 */
if (!function_exists('logAcao')) {
    function logAcao(string $acao, ?string $detalhes = null, $tabela = null, $itemId = null): void {
        $db   = getDB();
        $user = currentUser();
        if (!$user) return;

        $userId  = $user['id'];
        $adminId = !empty($user['admin_id']) ? (int)$user['admin_id'] : null;

        $sql = "INSERT INTO logs_acoes (usuario_id, admin_id, acao, tabela, item_id, dados_novos, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $params = [
            $userId,
            $adminId,
            $acao,
            $tabela,
            $itemId,
            $detalhes ? json_encode(['mensagem' => $detalhes]) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null,
        ];

        try {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
        } catch (PDOException $e) {
            // Fallback para tabela logs (versões antigas do schema)
            if ($e->getCode() == '42S02') {
                try {
                    $sqlFallback = "INSERT INTO logs (usuario_id, admin_id, acao, detalhes, ip, criado_em) VALUES (?, ?, ?, ?, ?, NOW())";
                    $stmt = $db->prepare($sqlFallback);
                    $stmt->execute([$userId, $adminId, $acao, $detalhes, $_SERVER['REMOTE_ADDR'] ?? null]);
                } catch (Exception $e2) {
                    error_log('[LOG ERROR FALLBACK] ' . $e2->getMessage());
                }
            } else {
                error_log('[LOG ERROR] ' . $e->getMessage());
            }
        } catch (Exception $e) {
            error_log('[LOG ERROR GENERIC] ' . $e->getMessage());
        }
    }
}

/**
 * Verificar se a rota está fechada
 */
function isRouteClosed(): bool {
    $user = currentUser();
    if (!$user) return true;

    if ($user['tipo'] === 'admin') return false;

    $db   = getDB();
    $hoje = date('Y-m-d');
    $hora = (int)date('H');

    if ($hora < 8) return true;

    try {
        $stmt = $db->prepare("SELECT id FROM fechamentos WHERE data_fechamento = ? AND usuario_id = ? LIMIT 1");
        $stmt->execute([$hoje, $user['id']]);
        if ($stmt->fetch()) return true;
        return false;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Resposta JSON padronizada
 */
function resposta($sucesso, $mensagem = '', $dados = null, $httpCode = 200, $codigoErro = null): void {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'sucesso'  => $sucesso,
        'mensagem' => $mensagem,
        'dados'    => $dados,
        'erro'     => $codigoErro,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
?>
