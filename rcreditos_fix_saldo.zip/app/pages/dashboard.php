<?php
/**
 * R. Créditos — Dashboard Principal
 */
require_once __DIR__ . '/../config/app.php';
requireAuth();
$usuario = currentUser();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
<meta name="theme-color" content="#0f1117"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="apple-mobile-web-app-title" content="R. Créditos"/>
<meta name="application-name" content="R. Créditos"/>
<title>R. Créditos — Gestão</title>
<link rel="manifest" href="<?= BASE_URL ?>/manifest.webmanifest">
<link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>/assets/icons/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>/assets/icons/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════════════════
   DESIGN TOKENS
══════════════════════════════════════════ */
:root{
  --bg-base:#0f1117;--bg-surface:#161920;--bg-elevated:#1e2128;
  --bg-input:#252830;--bg-hover:#2a2d36;--border:#272b34;--border-strong:#363b47;
  --accent:#4f8ef7;--accent-hover:#3a7ae6;--accent-dim:rgba(79,142,247,.13);
  --green:#2ecc8a;--green-dim:rgba(46,204,138,.12);
  --yellow:#f5b731;--yellow-dim:rgba(245,183,49,.12);
  --red:#e85656;--red-dim:rgba(232,86,86,.12);
  --purple:#a78bfa;--purple-dim:rgba(167,139,250,.12);
  --orange:#f97316;--orange-dim:rgba(249,115,22,.12);
  --text-primary:#eef0f3;--text-secondary:#8b929e;--text-muted:#50565f;
  --font:-apple-system,BlinkMacSystemFont,'Segoe UI','Helvetica Neue',Arial,sans-serif;
  --radius:10px;--radius-sm:6px;--radius-lg:16px;
  --shadow-sm:0 1px 4px rgba(0,0,0,.5);--shadow-md:0 4px 24px rgba(0,0,0,.6);
  --shadow-lg:0 8px 48px rgba(0,0,0,.7);
}
.badge-count{background:var(--bg-input);color:var(--text-secondary);font-size:10px;font-weight:800;padding:2px 6px;border-radius:10px;margin-left:6px;border:1px solid var(--border-strong);}
.form-separator{font-size:11px;font-weight:800;text-transform:uppercase;color:var(--text-muted);letter-spacing:1px;margin:20px 0 10px;display:flex;align-items:center;gap:10px;}
.form-separator::after{content:'';flex:1;height:1px;background:var(--border);}
.btn-copy-parcelas{background:var(--bg-elevated);color:var(--text-secondary);font-size:10px;font-weight:700;padding:4px 8px;border-radius:4px;border:1px solid var(--border-strong);text-transform:uppercase;transition:all .15s;cursor:pointer;}
.btn-copy-parcelas:hover{background:var(--bg-hover);color:var(--text-primary);border-color:var(--accent);}
.btn-whatsapp{background:#1a3d27;color:#25d366;font-size:10px;font-weight:700;padding:4px 8px;border-radius:4px;border:1px solid #25d36640;text-transform:uppercase;transition:all .15s;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
.btn-whatsapp:hover{background:#25d36620;border-color:#25d366;color:#25d366;}
.btn-copy-mini{background:var(--bg-elevated);color:var(--text-muted);font-size:10px;padding:2px 5px;border-radius:4px;border:1px solid var(--border);transition:all .15s;cursor:pointer;}
.btn-copy-mini:hover{color:var(--accent);border-color:var(--accent);}
.status-fechado-tag{background:var(--red-dim);color:var(--red);font-size:11px;font-weight:800;padding:7px 12px;border-radius:var(--radius-sm);text-transform:uppercase;letter-spacing:0.5px;border:1px solid rgba(232,86,86,0.3);white-space:nowrap;}
.btn-fechar-rota{background:rgba(232,86,86,.12);color:var(--red);font-size:12.5px;font-weight:700;
  padding:8px 14px;border-radius:var(--radius-sm);border:1px solid rgba(232,86,86,.28);
  white-space:nowrap;transition:background .15s;}
.btn-fechar-rota:hover{background:rgba(232,86,86,.22);}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{height:100%;font-size:15px;}
body{font-family:var(--font);background:var(--bg-base);color:var(--text-primary);
  min-height:100%;-webkit-font-smoothing:antialiased;overscroll-behavior:none;line-height:1.5;}
img{max-width:100%;display:block;}
button{cursor:pointer;border:none;background:none;font-family:var(--font);}
input,select,textarea{font-family:var(--font);font-size:14px;width:100%;
  background:var(--bg-input);color:var(--text-primary);
  border:1px solid var(--border-strong);border-radius:var(--radius-sm);
  padding:10px 13px;outline:none;transition:border-color .15s,box-shadow .15s;
  -webkit-appearance:none;}
input:focus,select:focus,textarea:focus{
  border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-dim);}
input::placeholder,textarea::placeholder{color:var(--text-muted);}
select option{background:var(--bg-elevated);color:var(--text-primary);}
textarea{resize:vertical;min-height:70px;}

/* ── HEADER ── */
.app-header{background:var(--bg-surface);border-bottom:1px solid var(--border);
  position:sticky;top:0;z-index:100;box-shadow:var(--shadow-sm);}
.header-inner{display:flex;align-items:center;justify-content:space-between;
  padding:0 18px;height:56px;max-width:960px;margin:0 auto;}
.logo-area{display:flex;align-items:center;gap:10px;}
.logo-text{display:flex;flex-direction:column;line-height:1.2;}
.logo-title{font-size:16px;font-weight:800;letter-spacing:.2px;}
.logo-sub{font-size:10px;font-weight:500;color:var(--text-muted);
  letter-spacing:.6px;text-transform:uppercase;}
.header-actions{display:flex;gap:8px;align-items:center;}

/* ── BUTTONS ── */
.btn-add-client{background:var(--accent);color:#fff;font-weight:600;font-size:13px;
  padding:8px 15px;border-radius:var(--radius-sm);letter-spacing:.2px;
  transition:background .15s,transform .1s;white-space:nowrap;}
.btn-add-client:hover{background:var(--accent-hover);}
.btn-add-client:active{transform:scale(.96);}
.btn-settings{font-size:20px;width:36px;height:36px;border-radius:var(--radius-sm);
  display:flex;align-items:center;justify-content:center;
  transition:background .15s;}
.btn-settings:hover{background:var(--bg-elevated);}
.btn-logout{font-size:13px;font-weight:600;padding:8px 12px;border-radius:var(--radius-sm);
  color:var(--text-muted);border:1px solid var(--border-strong);
  transition:all .15s;white-space:nowrap;}
.btn-logout:hover{background:var(--red-dim);color:var(--red);border-color:rgba(232,86,86,.3);}
.btn-primary{background:var(--accent);color:#fff;font-weight:600;font-size:14px;
  padding:11px 20px;border-radius:var(--radius-sm);transition:background .15s;flex:1;}
.btn-primary:hover{background:var(--accent-hover);}
.btn-primary:disabled{opacity:.4;cursor:not-allowed;}
.btn-secondary{background:var(--bg-elevated);color:var(--text-secondary);font-weight:600;
  font-size:14px;padding:11px 18px;border-radius:var(--radius-sm);
  border:1px solid var(--border-strong);transition:background .15s,color .15s;}
.btn-secondary:hover{background:var(--bg-hover);color:var(--text-primary);}
.btn-warning{background:var(--yellow-dim);color:var(--yellow);font-weight:600;font-size:14px;
  padding:11px 18px;border-radius:var(--radius-sm);
  border:1px solid rgba(245,183,49,.25);transition:background .15s;}
.btn-warning:hover{background:rgba(245,183,49,.2);}
.btn-danger{background:var(--red-dim);color:var(--red);font-weight:600;font-size:14px;
  padding:11px 18px;border-radius:var(--radius-sm);
  border:1px solid rgba(232,86,86,.25);transition:background .15s;}
.btn-danger:hover{background:rgba(232,86,86,.2);}
.btn-multa-action{background:var(--orange-dim);color:var(--orange);font-weight:600;
  font-size:13px;padding:9px 12px;border-radius:var(--radius-sm);
  border:1px solid rgba(249,115,22,.25);transition:background .15s;}
.btn-multa-action:hover{background:rgba(249,115,22,.2);}

/* ── TABS ── */
.tab-nav{display:flex;background:var(--bg-surface);border-bottom:1px solid var(--border);
  position:sticky;top:56px;z-index:99;overflow-x:auto;scrollbar-width:none;}
.tab-nav::-webkit-scrollbar{display:none;}
.tab-btn{flex:1;padding:0 6px;height:43px;font-size:12px;font-weight:600;
  color:var(--text-muted);border-bottom:2px solid transparent;
  transition:color .15s,border-color .15s;letter-spacing:.2px;
  white-space:nowrap;min-width:64px;}
.tab-btn:hover{color:var(--text-secondary);}
.tab-btn.active{color:var(--accent);border-bottom-color:var(--accent);}

/* ── MAIN ── */
.app-main{max-width:960px;margin:0 auto;padding:18px 14px 80px;}
.tab-content{display:none;}
.tab-content.active{display:block;}

/* ── SEARCH ── */
.search-bar{margin-bottom:14px;}
.search-bar input{background:var(--bg-surface);border-color:var(--border);}

/* ── STAT CARDS ── */
.painel-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:24px;}
.card-stat{background:var(--bg-surface);border:1px solid var(--border);
  border-radius:var(--radius-lg);padding:16px 10px 14px;
  display:flex;flex-direction:column;align-items:center;gap:3px;
  transition:transform .15s;}
.card-stat:hover{transform:translateY(-2px);}
.stat-icon{font-size:18px;margin-bottom:1px;}
.stat-num{font-size:32px;font-weight:800;line-height:1;}
.stat-label{font-size:10px;font-weight:700;color:var(--text-muted);
  text-align:center;text-transform:uppercase;letter-spacing:.6px;}
.em-dia{border-top:2px solid var(--green);}
.em-dia .stat-num{color:var(--green);}
.pendente{border-top:2px solid var(--yellow);}
.pendente .stat-num{color:var(--yellow);}
.atrasado{border-top:2px solid var(--red);}
.atrasado .stat-num{color:var(--red);}

/* ── PAINEL SECTIONS ── */
.painel-section{margin-bottom:28px;}
.section-title{font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;
  padding:0 0 10px;margin-bottom:10px;border-bottom:1px solid var(--border);}
.em-dia-title{color:var(--green);}
.pendente-title{color:var(--yellow);}
.atrasado-title{color:var(--red);}

/* ── CLIENT CARD ── */
.cliente-card{background:var(--bg-surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:12px 14px;margin-bottom:8px;
  display:flex;align-items:center;gap:12px;cursor:pointer;
  transition:background .15s,border-color .15s,transform .1s;}
.cliente-card:hover{background:var(--bg-hover);border-color:var(--border-strong);
  transform:translateX(2px);}
.cliente-card.status-em-dia{border-left:3px solid var(--green);}
.cliente-card.status-pendente{border-left:3px solid var(--yellow);}
.cliente-card.status-atrasado{border-left:3px solid var(--red);}
.cliente-avatar{width:42px;height:42px;border-radius:50%;background:var(--bg-elevated);
  flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:19px;
  overflow:hidden;border:1px solid var(--border-strong);}
.cliente-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%;}
.cliente-info{flex:1;min-width:0;}
.cliente-nome{font-size:14px;font-weight:700;white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis;}
.cliente-sub{font-size:12px;color:var(--text-muted);margin-top:2px;}
.cliente-meta{text-align:right;flex-shrink:0;}
.cliente-divida{font-size:15px;font-weight:700;}
.cliente-badge{display:inline-block;font-size:9px;font-weight:700;padding:2px 7px;
  border-radius:20px;margin-top:4px;text-transform:uppercase;letter-spacing:.4px;}
.badge-em-dia{background:var(--green-dim);color:var(--green);}
.badge-pendente{background:var(--yellow-dim);color:var(--yellow);}
.badge-atrasado{background:var(--red-dim);color:var(--red);}

/* ── VENDA CARD (baixa do cliente) ── */
.venda-card{background:var(--bg-surface);border:1px solid var(--border);
  border-radius:var(--radius-lg);padding:16px;margin-bottom:12px;
  transition:border-color .15s;}
.venda-card:hover{border-color:var(--border-strong);}
.venda-header{display:flex;justify-content:space-between;align-items:flex-start;}
.venda-titulo{font-size:14px;font-weight:700;}
.venda-cliente-nome{font-size:12px;color:var(--text-muted);margin-top:2px;}
.venda-valor{font-size:20px;font-weight:800;text-align:right;}
.venda-subvalor{font-size:11px;color:var(--text-muted);text-align:right;margin-top:1px;}

/* Seções internas do card: cada bloco (Resumo / Parcelas / Multas / Ações)
   é separado por um divisor sutil e um rótulo em caixa alta — sem criar
   um novo card para cada grupo. */
.venda-section{margin-top:14px;padding-top:12px;border-top:1px solid var(--border);}
.venda-section-title{font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:.6px;color:var(--text-muted);margin-bottom:8px;
  display:flex;align-items:center;justify-content:space-between;}
.venda-section-title.is-alert{color:var(--red);}

.venda-breakdown{background:var(--bg-base);border:1px solid var(--border);
  border-radius:var(--radius-sm);padding:10px 12px;
  display:flex;flex-direction:column;gap:5px;}
.bd-row{display:flex;justify-content:space-between;align-items:center;
  font-size:12px;color:var(--text-muted);}
.bd-row span:last-child{font-weight:600;color:var(--text-secondary);}
.bd-juros span:last-child,span.bd-juros{color:var(--yellow)!important;}
.bd-border{border-top:1px solid var(--border);padding-top:5px;margin-top:2px;}
.bd-border span:last-child{color:var(--text-primary)!important;font-weight:700;}
	.bd-multa-row{background:var(--red-dim);border-radius:4px;padding:4px 6px;margin-top:2px;display:none !important;}
	.bd-multa-row span:last-child{color:var(--red)!important;font-weight:700;}
.bd-saldo-parcial span:last-child{color:var(--purple)!important;}

/* Bloco de multas em aberto — mesma lógica de seção, com destaque discreto */
.venda-multas-alerta{display:flex;justify-content:space-between;align-items:center;
  background:var(--red-dim);border:1px solid rgba(232,86,86,.25);
  border-radius:var(--radius-sm);padding:9px 12px;font-size:12px;}
.venda-multas-alerta strong{color:var(--red);font-weight:700;}
.venda-multas-alerta span{color:var(--red);font-weight:700;}

/* ── PROGRESS BAR ── */
.parcelas-bar{background:var(--bg-elevated);border-radius:20px;height:4px;
  overflow:hidden;margin:0 0 5px;}
.parcelas-fill{height:100%;border-radius:20px;background:var(--accent);
  transition:width .5s ease;}
.parcelas-info{display:flex;justify-content:space-between;font-size:11px;
  color:var(--text-muted);}

/* ── VENDA AÇÕES ── */
/* Hierarquia: uma ação primária em destaque + ações secundárias discretas
   alinhadas abaixo, sem competir visualmente entre si. */
.acoes-primaria{margin-bottom:7px;}
.acoes-primaria .btn-pagar{width:100%;}
.btn-pagar{padding:12px 14px;background:var(--accent);color:#fff;
  font-weight:700;font-size:13.5px;border-radius:var(--radius-sm);
  transition:background .15s;}
.btn-pagar:hover{background:var(--accent-hover);}
.btn-pagar:disabled{opacity:.4;cursor:not-allowed;}
.acoes-secundarias{display:flex;gap:6px;flex-wrap:wrap;}
.acoes-secundarias button{flex:1;min-width:78px;padding:8px 8px;
  background:var(--bg-elevated);color:var(--text-secondary);
  font-weight:600;font-size:11.5px;border-radius:var(--radius-sm);
  border:1px solid var(--border-strong);transition:background .15s,color .15s;}
.acoes-secundarias button:hover{background:var(--bg-hover);color:var(--text-primary);}
.btn-nao-pagou{color:var(--red)!important;}
.btn-nao-pagou:hover{background:var(--red-dim)!important;}
.btn-ver-multas.tem-pendencia{color:var(--orange)!important;border-color:rgba(249,115,22,.3)!important;}
.btn-ver-multas.tem-pendencia:hover{background:var(--orange-dim)!important;}
.acoes-terciarias{margin-top:6px;}
.btn-historico-parcelas{width:100%;font-weight:600;font-size:12px;cursor:pointer;
  background:var(--bg-elevated);color:var(--text-secondary);
  border:1px solid var(--border-strong)!important;border-radius:var(--radius-sm);
  padding:9px 8px;transition:background .15s,color .15s;}
.btn-historico-parcelas:hover{background:var(--bg-hover);color:var(--text-primary);}
.btn-copy-mini-icon{width:26px;height:26px;border-radius:var(--radius-sm);
  background:var(--bg-elevated);border:1px solid var(--border-strong);
  display:flex;align-items:center;justify-content:center;color:var(--text-muted);
  transition:color .15s,border-color .15s;flex-shrink:0;}
.btn-copy-mini-icon:hover{color:var(--accent);border-color:var(--accent);}
.btn-copy-mini-icon svg{width:13px;height:13px;}

.historico-parcelas-table{width:100%;border-collapse:collapse;font-size:12px;min-width:680px;}
.historico-parcelas-table th{padding:9px 8px;text-align:left;background:var(--bg-elevated);color:var(--text-muted);font-size:10px;text-transform:uppercase;letter-spacing:.4px;}
.historico-parcelas-table td{padding:9px 8px;border-top:1px solid var(--border);color:var(--text-secondary);}
.historico-parcelas-table td:first-child,.historico-parcelas-table th:first-child{text-align:center;width:40px;}
.historico-parcelas-table td:nth-child(3),.historico-parcelas-table td:nth-child(4){text-align:right;font-weight:600;color:var(--text-primary);}
.historico-parcelas-table tr:hover td{background:var(--bg-hover);}

/* ── PARCELAS GRID ── */
.parcelas-grid{margin-top:10px;border:1px solid var(--border);
  border-radius:var(--radius-sm);overflow:hidden;display:none;}
.parcelas-grid.open{display:block;}
.parcelas-grid-header{display:grid;grid-template-columns:36px 1fr 90px 70px;
  background:var(--bg-elevated);padding:7px 10px;gap:6px;
  font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.6px;}
.parcela-row{display:grid;grid-template-columns:36px 1fr 90px 70px;padding:8px 10px;gap:6px;
  border-top:1px solid var(--border);font-size:12px;align-items:center;
  transition:background .15s;}
.parcela-row:hover{background:var(--bg-hover);}
.parcela-num{font-weight:700;color:var(--text-muted);}
.parcela-data{color:var(--text-secondary);}
.parcela-valor{font-weight:600;text-align:right;}
.parcela-status{text-align:center;}
.ps-pago{background:var(--green-dim);color:var(--green);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}
.ps-atrasado{background:var(--red-dim);color:var(--red);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}
.ps-pendente{background:var(--yellow-dim);color:var(--yellow);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}
.ps-futuro{background:var(--bg-input);color:var(--text-muted);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}
.ps-parcial{background:var(--purple-dim);color:var(--purple);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}
.ps-multa{background:var(--orange-dim);color:var(--orange);padding:2px 6px;
  border-radius:10px;font-size:9px;font-weight:700;text-transform:uppercase;}

/* ── MULTAS SECTION ── */
.multas-section{margin-top:10px;border:1px solid rgba(232,86,86,.3);
  border-radius:var(--radius-sm);overflow:hidden;display:none;
  background:rgba(232,86,86,.03);}
.multas-section.open{display:block;}
.multas-section-header{background:var(--red-dim);padding:8px 12px;
  display:flex;justify-content:space-between;align-items:center;}
.multas-section-title{font-size:11px;font-weight:700;color:var(--red);
  text-transform:uppercase;letter-spacing:.6px;}
.multa-item{padding:10px 12px;border-top:1px solid rgba(232,86,86,.15);
  display:flex;justify-content:space-between;align-items:flex-start;gap:8px;}
.multa-item:first-child{border-top:none;}
.multa-info{flex:1;}
.multa-motivo{font-size:12px;font-weight:600;color:var(--text-primary);}
.multa-sub{font-size:11px;color:var(--text-muted);margin-top:2px;}
.multa-valor{font-size:14px;font-weight:700;color:var(--red);white-space:nowrap;}
.multa-status-badge{font-size:9px;font-weight:700;padding:2px 6px;border-radius:10px;
  text-transform:uppercase;margin-top:4px;display:inline-block;}
.msb-aberto{background:var(--red-dim);color:var(--red);}
.msb-pago{background:var(--green-dim);color:var(--green);}
.msb-parcela{background:var(--orange-dim);color:var(--orange);}
.multa-acoes{display:flex;gap:6px;margin-top:8px;padding:0 12px 10px;}
.btn-sm{font-size:11px;font-weight:700;padding:6px 10px;border-radius:var(--radius-sm);}

/* ── PAGAMENTO PREVIEW ── */
.pag-info{display:flex;flex-direction:column;gap:3px;
  background:var(--bg-elevated);border-radius:var(--radius-sm);padding:12px 14px;}
.pag-row{display:flex;justify-content:space-between;align-items:center;
  font-size:13px;padding:3px 0;}
.pag-row strong{color:var(--text-secondary);}
.pag-multa{background:var(--red-dim);border-radius:4px;margin-top:4px;padding:5px 8px;}
.valor-custom-box{display:flex;flex-direction:column;gap:6px;}
.valor-custom-label{font-size:11px;font-weight:700;text-transform:uppercase;
  letter-spacing:.4px;color:var(--text-muted);}
.pag-valor-input{font-size:26px;font-weight:800;text-align:center;letter-spacing:1px;
  padding:14px 12px;background:var(--bg-input);border:2px solid var(--accent);
  border-radius:var(--radius);color:var(--text-primary);}
.pag-preview-linha{display:flex;justify-content:space-between;align-items:center;
  border-radius:var(--radius-sm);padding:9px 12px;font-size:13px;margin-top:4px;}
.pag-preview-parcial{background:var(--accent-dim);border:1px solid rgba(79,142,247,.22);}
.pag-preview-saldo{background:var(--bg-elevated);border:1px solid var(--border-strong);}
.pag-preview-zerado{background:var(--green-dim);border:1px solid rgba(46,204,138,.25);}
.pag-preview-label{font-weight:700;}
.pag-preview-val{font-weight:800;font-size:14px;}
.forma-pag-row{display:flex;gap:8px;}
.forma-btn{flex:1;padding:10px 8px;background:var(--bg-elevated);color:var(--text-secondary);
  font-weight:600;font-size:13px;border-radius:var(--radius-sm);
  border:2px solid var(--border-strong);transition:all .15s;text-align:center;}
.forma-btn.selected{background:var(--accent-dim);color:var(--accent);
  border-color:var(--accent);}
.forma-btn.selected-pix{background:rgba(46,204,138,.12);color:var(--green);
  border-color:var(--green);}
.comprovante-upload{background:var(--bg-elevated);border:2px dashed var(--border-strong);
  border-radius:var(--radius-sm);padding:14px;text-align:center;cursor:pointer;
  transition:border-color .15s;position:relative;}
.comprovante-upload:hover{border-color:var(--accent);}
.comprovante-upload input[type=file]{position:absolute;inset:0;opacity:0;
  cursor:pointer;width:100%;height:100%;}
.comprovante-preview{margin-top:8px;border-radius:var(--radius-sm);overflow:hidden;
  max-height:160px;display:flex;align-items:center;justify-content:center;}
.comprovante-preview img{max-height:160px;border-radius:var(--radius-sm);
  object-fit:contain;width:100%;}

/* ── MODAIS ── */
.modal-overlay{display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.75);align-items:flex-end;justify-content:center;
  backdrop-filter:blur(4px);}
.modal-overlay.open{display:flex;}
.modal{background:var(--bg-surface);border:1px solid var(--border-strong);
  border-radius:var(--radius-lg) var(--radius-lg) 0 0;
  width:100%;max-width:580px;max-height:92vh;overflow-y:auto;
  animation:slideUp .22s ease;box-shadow:var(--shadow-lg);}
.modal-large{border-radius:var(--radius-lg);margin:14px;max-height:90vh;}
@keyframes slideUp{from{transform:translateY(40px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.modal-header{display:flex;align-items:center;justify-content:space-between;
  padding:16px 18px 14px;border-bottom:1px solid var(--border);
  position:sticky;top:0;background:var(--bg-surface);z-index:2;}
.modal-header h3{font-size:16px;font-weight:700;}
.btn-close{width:30px;height:30px;border-radius:var(--radius-sm);font-size:16px;
  color:var(--text-muted);display:flex;align-items:center;justify-content:center;
  transition:background .15s,color .15s;}
.btn-close:hover{background:var(--bg-hover);color:var(--text-primary);}
.modal-body{padding:18px;display:flex;flex-direction:column;gap:13px;}
.modal-footer{padding:13px 18px;display:flex;gap:8px;border-top:1px solid var(--border);
  position:sticky;bottom:0;background:var(--bg-surface);}

/* ── FORM ── */
.form-group{display:flex;flex-direction:column;gap:5px;}
.form-group label{font-size:11px;font-weight:700;color:var(--text-secondary);
  letter-spacing:.3px;text-transform:uppercase;}
.form-separator{font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;
  letter-spacing:1px;padding:3px 0 5px;border-bottom:1px solid var(--border);margin-top:2px;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.form-row-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;}

/* ── RESUMO VENDA ── */
.resumo-venda-box{background:var(--bg-elevated);border:1px solid var(--accent);
  border-radius:var(--radius);padding:13px 15px;display:flex;flex-direction:column;gap:7px;
  animation:fadeIn .2s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(-4px);}to{opacity:1;transform:translateY(0);}}
.resumo-titulo{font-size:11px;font-weight:700;color:var(--accent);
  text-transform:uppercase;letter-spacing:.8px;margin-bottom:1px;}
.rv-linha{display:flex;justify-content:space-between;align-items:center;font-size:13px;}
.rv-linha span:first-child{color:var(--text-muted);}
.rv-linha span:last-child{font-weight:600;color:var(--text-secondary);}
.rv-juros span:last-child{color:var(--yellow)!important;}
.rv-total{border-top:1px solid var(--border-strong);padding-top:7px;margin-top:1px;}
.rv-total span:last-child{color:var(--text-primary)!important;font-weight:700;font-size:15px;}
.rv-destaque{font-size:17px!important;color:var(--accent)!important;}

/* ── FOTOS ── */
.fotos-manager{display:flex;flex-direction:column;gap:9px;}
.fotos-manager-header{display:flex;align-items:center;justify-content:space-between;}
.fotos-manager-title{font-size:11px;font-weight:700;color:var(--text-secondary);
  text-transform:uppercase;letter-spacing:.5px;}
.btn-add-foto{padding:6px 11px;background:var(--accent-dim);color:var(--accent);
  font-weight:700;font-size:12px;border-radius:var(--radius-sm);
  border:1px solid rgba(79,142,247,.2);transition:background .15s;}
.btn-add-foto:hover{background:rgba(79,142,247,.2);}
.fotos-grid-upload{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;}
.foto-upload-cell{position:relative;border-radius:var(--radius-sm);overflow:hidden;
  background:var(--bg-elevated);border:1px solid var(--border-strong);
  aspect-ratio:1;transition:border-color .15s;}
.foto-upload-cell img{width:100%;height:100%;object-fit:cover;display:block;}
.foto-cell-overlay{position:absolute;inset:0;background:rgba(0,0,0,.55);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;
  opacity:0;transition:opacity .15s;}
.foto-upload-cell:hover .foto-cell-overlay{opacity:1;}
.foto-cell-label{font-size:9px;color:rgba(255,255,255,.8);font-weight:700;
  text-transform:uppercase;letter-spacing:.4px;text-align:center;padding:0 4px;}
.foto-cell-del{padding:4px 8px;background:var(--red);color:#fff;font-size:10px;
  font-weight:700;border-radius:4px;cursor:pointer;border:none;}
.foto-upload-placeholder{width:100%;height:100%;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:4px;cursor:pointer;
  font-size:11px;color:var(--text-muted);font-weight:600;text-align:center;padding:4px;}
.foto-upload-placeholder input[type=file]{position:absolute;inset:0;opacity:0;
  cursor:pointer;width:100%;height:100%;border:none;background:none;}

/* ── GALERIA ── */
.galeria-section{margin-bottom:14px;}
.galeria-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px;}
.galeria-title{font-size:11px;font-weight:700;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.8px;}
.btn-galeria-completa{padding:5px 10px;background:var(--accent-dim);color:var(--accent);
  font-weight:700;font-size:11px;border-radius:20px;border:1px solid rgba(79,142,247,.2);}
.btn-add-foto-galeria{padding:5px 10px;background:var(--green-dim);color:var(--green);
  font-weight:700;font-size:11px;border-radius:20px;border:1px solid rgba(46,204,138,.2);}
.galeria-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;}
.galeria-thumb{width:100%;aspect-ratio:1;border-radius:var(--radius-sm);
  overflow:hidden;border:1px solid var(--border-strong);cursor:pointer;
  position:relative;transition:transform .15s,border-color .15s;}
.galeria-thumb:hover{transform:scale(1.05);border-color:var(--accent);}
.galeria-thumb img{width:100%;height:100%;object-fit:cover;}
.galeria-thumb-label{position:absolute;bottom:0;left:0;right:0;
  background:rgba(0,0,0,.6);font-size:8px;font-weight:700;color:#fff;
  padding:2px 4px;text-align:center;text-transform:uppercase;}
.galeria-thumb-count{width:100%;height:100%;display:flex;align-items:center;
  justify-content:center;font-size:16px;font-weight:800;color:var(--text-muted);}

/* ── DETALHE CLIENTE ── */
.detalhe-header{display:flex;align-items:flex-start;gap:14px;margin-bottom:4px;}
.detalhe-avatar{width:60px;height:60px;border-radius:50%;background:var(--bg-elevated);
  flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:26px;
  overflow:hidden;border:2px solid var(--border-strong);}
.detalhe-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%;}
.detalhe-info{flex:1;}
.detalhe-info h4{font-size:17px;font-weight:800;margin:3px 0 4px;}
.detalhe-info p{font-size:12px;color:var(--text-muted);margin:2px 0;}
.id-tag{font-size:10px;font-weight:700;background:var(--accent-dim);color:var(--accent);
  padding:2px 8px;border-radius:20px;display:inline-block;}
.conta-cliente{background:var(--bg-elevated);border-radius:var(--radius);
  padding:13px 15px;display:flex;flex-direction:column;gap:6px;}
.conta-titulo{font-size:11px;font-weight:700;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.7px;margin-bottom:3px;}
.conta-linha{display:flex;justify-content:space-between;font-size:13px;}
.conta-linha span:first-child{color:var(--text-secondary);}
.cv{font-weight:600;}
.amarelo{color:var(--yellow)!important;}
.vermelho{color:var(--red)!important;}
.conta-total{border-top:1px solid var(--border-strong);padding-top:8px;margin-top:2px;
  font-weight:700;}
.conta-total span:first-child{color:var(--text-primary)!important;}
.conta-linha-destaque{background:var(--red-dim);border-radius:6px;
  padding:5px 8px;margin:-2px -4px;}
.detalhe-resumo{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;
  text-align:center;}
.resumo-item{background:var(--bg-elevated);border-radius:var(--radius-sm);padding:10px 4px;}
.r-val{font-size:20px;font-weight:800;}
.r-label{font-size:10px;color:var(--text-muted);text-transform:uppercase;
  letter-spacing:.4px;margin-top:2px;}
.detalhe-vendas-title{font-size:12px;font-weight:700;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.7px;margin-bottom:10px;}

/* ── HISTÓRICO ── */
.historico-section{margin-bottom:24px;}
.historico-title{font-size:12px;font-weight:700;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.7px;margin-bottom:10px;}
.hist-item{background:var(--bg-surface);border:1px solid var(--border);
  border-radius:var(--radius-sm);padding:11px 13px;margin-bottom:6px;
  display:flex;justify-content:space-between;align-items:flex-start;gap:10px;}
.hist-info{flex:1;}
.hist-tipo{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;}
.hist-cliente{font-size:13px;font-weight:600;margin-top:1px;}
.hist-sub{font-size:11px;color:var(--text-muted);margin-top:2px;}
.hist-valor{text-align:right;flex-shrink:0;}
.hist-valor-num{font-size:15px;font-weight:700;}
.hist-data{font-size:11px;color:var(--text-muted);margin-top:2px;}
.tipo-pagamento{color:var(--green);}
.tipo-nao-pagou{color:var(--red);}
.tipo-multa{color:var(--red);}
.tipo-multa-pag{color:var(--orange);}
.tipo-parcela-multa{color:var(--purple);}

/* ── SETTINGS ── */
.settings-section{background:var(--bg-elevated);border-radius:var(--radius);
  padding:14px 16px;display:flex;flex-direction:column;gap:10px;}
.settings-section-title{font-size:11px;font-weight:700;color:var(--accent);
  text-transform:uppercase;letter-spacing:.8px;}
.settings-row{display:flex;justify-content:space-between;align-items:center;gap:12px;}
.settings-row-left{flex:1;}
.sr-title{font-size:13px;font-weight:600;color:var(--text-primary);}
.sr-sub{font-size:11px;color:var(--text-muted);margin-top:2px;}
.toggle-switch{position:relative;width:44px;height:24px;flex-shrink:0;}
.toggle-switch input{opacity:0;width:0;height:0;position:absolute;}
.toggle-track{position:absolute;inset:0;background:var(--bg-input);
  border-radius:12px;border:1px solid var(--border-strong);
  transition:background .2s,border-color .2s;cursor:pointer;}
.toggle-track::after{content:'';position:absolute;width:18px;height:18px;
  border-radius:50%;background:var(--text-muted);top:2px;left:2px;
  transition:transform .2s,background .2s;}
.toggle-switch input:checked + .toggle-track{background:var(--accent);
  border-color:var(--accent);}
.toggle-switch input:checked + .toggle-track::after{transform:translateX(20px);
  background:#fff;}
.cor-paleta{display:flex;gap:10px;flex-wrap:wrap;}
.cor-opcao{width:30px;height:30px;border-radius:50%;cursor:pointer;
  transition:transform .15s;border:3px solid transparent;}
.cor-opcao.ativa{transform:scale(1.2);border-color:rgba(255,255,255,.5);}
.font-size-row{display:flex;gap:8px;}
.font-opt{flex:1;padding:9px 4px;background:var(--bg-input);border-radius:var(--radius-sm);
  font-weight:600;color:var(--text-muted);border:2px solid transparent;transition:all .15s;}
.font-opt.ativa{border-color:var(--accent);color:var(--accent);}
.pin-config-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.btn-pin{font-size:12px;font-weight:700;padding:9px 12px;border-radius:var(--radius-sm);
  white-space:nowrap;}
.btn-pin-set{background:var(--accent-dim);color:var(--accent);
  border:1px solid rgba(79,142,247,.25);}
.btn-pin-clear{background:var(--red-dim);color:var(--red);
  border:1px solid rgba(232,86,86,.25);}
.pin-status{font-size:12px;font-weight:600;padding:6px 10px;border-radius:var(--radius-sm);}
.pin-status.on{background:var(--green-dim);color:var(--green);}
.pin-status.off{background:var(--bg-input);color:var(--text-muted);}
.pin-dica{font-size:14px;color:var(--text-secondary);text-align:center;padding:10px 0;}
.pin-input-modal{font-size:24px!important;letter-spacing:8px;text-align:center;}
.pin-erro{font-size:12px;color:var(--red);text-align:center;display:none;padding:6px;}
.pin-erro.show{display:block;}

/* ── LIGHTBOX ── */
.lightbox-overlay{display:none;position:fixed;inset:0;z-index:300;
  background:rgba(0,0,0,.92);align-items:center;justify-content:center;
  flex-direction:column;gap:10px;}
.lightbox-overlay.open{display:flex;}
.lightbox-close{position:absolute;top:16px;right:16px;width:40px;height:40px;
  font-size:20px;color:#fff;background:rgba(255,255,255,.1);
  border-radius:50%;display:flex;align-items:center;justify-content:center;
  transition:background .15s;}
.lightbox-close:hover{background:rgba(255,255,255,.2);}
.lightbox-img{max-width:90vw;max-height:80vh;object-fit:contain;border-radius:var(--radius);}
.lightbox-caption{font-size:13px;color:rgba(255,255,255,.6);font-weight:600;
  text-transform:uppercase;letter-spacing:.5px;}

/* ── TOAST ── */
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);
  background:var(--bg-elevated);border:1px solid var(--border-strong);
  color:var(--text-primary);font-size:13px;font-weight:600;
  padding:11px 18px;border-radius:var(--radius);box-shadow:var(--shadow-md);
  z-index:500;opacity:0;transition:all .25s;pointer-events:none;
  max-width:90vw;text-align:center;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
.toast.success{background:var(--green-dim);border-color:rgba(46,204,138,.3);color:var(--green);}
.toast.error{background:var(--red-dim);border-color:rgba(232,86,86,.3);color:var(--red);}
.toast.info{background:var(--accent-dim);border-color:rgba(79,142,247,.3);color:var(--accent);}
.toast.warning{background:var(--yellow-dim);border-color:rgba(245,183,49,.3);color:var(--yellow);}

/* ── EMPTY MSG ── */
.empty-msg{text-align:center;color:var(--text-muted);font-size:13px;
  padding:24px 16px;}

/* ── QTDE PARCELAS BOX ── */
.qtd-parcelas-box{background:var(--bg-elevated);border-radius:var(--radius);
  padding:12px 14px;display:flex;flex-direction:column;gap:8px;}
.qtd-parcelas-label{font-size:11px;font-weight:700;text-transform:uppercase;
  color:var(--text-muted);letter-spacing:.4px;}
.qtd-parcelas-row{display:flex;align-items:center;justify-content:center;gap:16px;}
.qtd-btn{width:38px;height:38px;border-radius:50%;background:var(--accent);color:#fff;
  font-size:20px;font-weight:700;display:flex;align-items:center;justify-content:center;
  transition:background .15s;}
.qtd-btn:hover{background:var(--accent-hover);}
.qtd-btn:disabled{opacity:.35;cursor:not-allowed;}
.qtd-num{font-size:28px;font-weight:800;text-align:center;min-width:40px;}
.qtd-info{font-size:11px;color:var(--text-muted);text-align:center;}
.total-pagar-box{display:flex;justify-content:space-between;align-items:center;
  background:var(--bg-input);border-radius:var(--radius-sm);padding:8px 12px;font-size:13px;}

/* ── RESPONSIVE ── */
@media(min-width:600px){
  .modal{border-radius:var(--radius-lg);margin:20px;max-height:88vh;}
  .modal-overlay{align-items:center;}
  .app-main{padding:22px 22px 80px;}
  .header-inner{padding:0 22px;}
  .fotos-grid-upload{grid-template-columns:repeat(4,1fr);}
  .galeria-grid{grid-template-columns:repeat(5,1fr);}
}

/* ── DROPDOWN MENU ── */
.dropdown { position: relative; display: inline-block; }
.dropdown-content {
  display: none; position: absolute; right: 0; min-width: 220px;
  background: var(--bg-surface); border: 1px solid var(--border-strong);
  border-radius: var(--radius); box-shadow: var(--shadow-lg); z-index: 100;
  padding: 8px 0; margin-top: 5px;
}
.dropdown-content.show { display: block; }
.dropdown-content button {
  width: 100%; text-align: left; padding: 12px 16px; background: none; border: none;
  color: var(--text-primary); font-size: 14px; cursor: pointer; display: flex; align-items: center; gap: 10px;
}
.dropdown-content button:hover { background: var(--bg-hover); }
.dropdown-content hr { border: 0; border-top: 1px solid var(--border); margin: 8px 0; }
.dropdown-content .icon { font-size: 16px; width: 20px; text-align: center; }

/* ── RESUMO RUTA GRID ── */
.resumo-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.resumo-card {
  background: var(--bg-elevated); padding: 15px; border-radius: var(--radius);
  text-align: center; border: 1px solid var(--border);
}
.resumo-val { display: block; font-size: 18px; font-weight: 800; color: var(--accent); margin-bottom: 4px; }
.resumo-lab { font-size: 11px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }

.btn-icon {
  background: var(--bg-input); border: 1px solid var(--border-strong);
  color: var(--text-secondary); width: 40px; height: 40px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  transition: background .15s, color .15s;
}
.btn-icon:hover { background: var(--bg-hover); color: var(--text-primary); }
.btn-icon svg { width: 18px; height: 18px; }

</style>
</head>
<body>

<!-- ══════════ HEADER ══════════ -->
<header class="app-header">
  <div class="header-inner">
    <div class="logo-area">
      <!-- Logo R. Créditos -->
      <svg width="34" height="34" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0">
        <circle cx="36" cy="36" r="34" fill="#111" stroke="#333" stroke-width="1.5"/>
        <circle cx="36" cy="36" r="26" fill="white"/>
        <text x="36" y="44" font-family="-apple-system,Arial,sans-serif"
              font-size="26" font-weight="900" fill="#111"
              text-anchor="middle" letter-spacing="-1">R</text>
        <circle cx="57" cy="15" r="9" fill="#0f1117" stroke="#333" stroke-width="1"/>
        <text x="57" y="19" font-family="Arial,sans-serif" font-size="9"
              font-weight="700" fill="white" text-anchor="middle">®</text>
      </svg>
      <div class="logo-text">
        <span class="logo-title">R. Créditos</span>
        <span class="logo-sub">Gestão de Finanças</span>
      </div>
    </div>
    <div class="header-actions">
      <div id="statusFechamentoHeader"></div>
      <div class="dropdown">
        <button class="btn-icon" id="btnMenuOpcoes" title="Opções">
          <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>
        </button>
        <div class="dropdown-content" id="menuOpcoes">
          <button onclick="abrirResumoDiario()"><span class="icon"></span>Resumo Diário</button>
          <button onclick="abrirResumoGeral()"><span class="icon"></span>Resumo Geral</button>
          <button onclick="abrirEventosRuta()"><span class="icon"></span>Eventos (Retirada/Aporte)</button>
          <hr>
          <button id="btnSettings">Configurações</button>
        </div>
      </div>
      <button class="btn-add-client" id="btnNovoCliente">+ Cliente</button>
      <a href="<?= BASE_URL ?>/app/auth/logout.php" class="btn-logout" title="Sair">Sair</a>
    </div>
  </div>
</header>

<!-- ══════════ TABS ══════════ -->
<nav class="tab-nav">
  <button class="tab-btn active" data-tab="painel">Painel</button>
  <button class="tab-btn" data-tab="clientes">Clientes</button>
  <button class="tab-btn" data-tab="vendas">Vendas</button>
  <button class="tab-btn" data-tab="historico">Histórico</button>
</nav>

<main class="app-main">

  <!-- PAINEL -->
  <section class="tab-content active" id="tab-painel">
    <div class="painel-cards">
      <div class="card-stat em-dia">
        <span class="stat-icon"></span>
        <span class="stat-num" id="totalEmDia">0</span>
        <span class="stat-label">Em Dia</span>
      </div>
      <div class="card-stat pendente">
                <span class="stat-num" id="totalPendente">0</span>
        <span class="stat-label">Pendentes</span>
      </div>
      <div class="card-stat atrasado">
        <span class="stat-icon"></span>
        <span class="stat-num" id="totalAtrasado">0</span>
        <span class="stat-label">Atrasados</span>
      </div>
    </div>


    <div class="painel-section">
      <div class="form-group" style="margin-bottom: 15px;">
        <label>Status:</label>
        <select id="filtroPainel" onchange="renderPainelComFiltro()">
          <option value="todos">Todos</option>
          <option value="pagaram-hoje">Pagaram Hoje</option>
          <option value="nao-pagaram-hoje">Sem Baixa</option>
          <option value="pendentes">Pendentes</option>
          <option value="atrasados">Atrasados</option>
        </select>
      </div>
      <div class="form-group" style="margin-bottom: 15px;">
        <label>Filtrar por:</label>
        <select id="filtroTipoPainel" onchange="onFiltroTipoPainelChange()">
          <option value="">Selecione um filtro...</option>
          <option value="atraso">Atraso/Multa</option>
          <option value="valor">Valor do Empréstimo</option>
          <option value="vencimento">Vencimento</option>
        </select>
      </div>
      <div class="form-group" id="wrapAtrasoPainel" style="margin-bottom: 15px; display:none;">
        <label>Dias de atraso (mínimo):</label>
        <input type="number" id="diasAtrasoPainel" min="0" placeholder="Ex: 3" oninput="renderPainelComFiltro()" style="width:100px" />
      </div>
      <div class="form-group" id="wrapValorPainel" style="margin-bottom: 15px; display:none;">
        <label>Filtrar por valor do empréstimo:</label>
        <input type="number" id="filtroValorPainel" min="0" step="0.01" placeholder="Ex: 1000" oninput="renderPainelComFiltro()" style="width:140px" />
      </div>
      <div class="form-group" id="wrapVencimentoPainel" style="margin-bottom: 15px; display:none;">
        <label>Vencendo em até (dias p/ fim da venda):</label>
        <input type="number" id="diasVencimentoPainel" min="0" placeholder="Ex: 10" oninput="renderPainelComFiltro()" style="width:100px" />
      </div>
      <div id="listaPainelUnificada"><p class="empty-msg">Nenhum cliente encontrado.</p></div>
    </div>
  </section>

  <!-- CLIENTES -->
  <section class="tab-content" id="tab-clientes">
    <div class="search-bar">
      <input type="text" id="searchCliente" placeholder=" Buscar cliente..."/>
    </div>
    <div class="form-group" style="margin-bottom: 15px;">
      <label>Ordenar por:</label>
      <select id="ordenacaoClientes" onchange="renderClientesComOrdenacao()">
        <option value="padrao">Padrão (Status)</option>
        <option value="alfabetica">Ordem Alfabética</option>
        <option value="venda">Data de Venda (Cronológica)</option>
      </select>
    </div>
    <div class="form-group" style="margin-bottom: 15px;">
      <label>Filtrar por vencimento:</label>
      <select id="filtroVencimentoClientes" onchange="onFiltroVencimentoChange()">
        <option value="todos">Todos os clientes</option>
        <option value="vencendo">Vencendo em até X dias</option>
      </select>
      <div id="wrapDiasVencimento" style="display:none;margin-top:8px;">
        <label>Dias pra fim da venda (máx.):</label>
        <input type="number" id="diasVencimentoInput" min="0" value="10" oninput="renderClientesComOrdenacao(document.getElementById('searchCliente')?.value || '')" style="width:80px" />
        <label style="margin-top:8px;display:block;">Dias de atraso (mín.):</label>
        <input type="number" id="diasAtrasoInputClientes" min="0" placeholder="Ex: 3" oninput="renderClientesComOrdenacao(document.getElementById('searchCliente')?.value || '')" style="width:80px" />
      </div>
    </div>
    <div id="listaClientes"><p class="empty-msg">Nenhum cliente cadastrado.</p></div>
  </section>

  <!-- VENDAS -->
  <section class="tab-content" id="tab-vendas">
    <div class="search-bar">
      <input type="text" id="searchVenda" placeholder=" Buscar venda por cliente..."/>
    </div>
    <div class="form-group" style="margin-bottom: 15px;">
      <label>Filtrar por valor do empréstimo:</label>
      <input type="number" id="filtroValorVenda" min="0" step="0.01" placeholder="Ex: 1000" style="width:140px" />
    </div>
    <div id="listaVendas"><p class="empty-msg">Nenhuma venda registrada.</p></div>
  </section>

  <!-- HISTÓRICO -->
  <section class="tab-content" id="tab-historico">
    <div class="search-bar">
      <input type="text" id="searchHistorico" placeholder=" Buscar por cliente..."/>
    </div>
    <div class="form-group" style="margin-bottom: 15px;">
      <label>Filtrar por dia da movimentação:</label>
      <div style="display:flex; gap:8px; align-items:center;">
        <input type="date" id="searchHistoricoData" style="flex:1;">
        <button type="button" id="btnLimparDataHistorico" class="btn-secondary" style="white-space:nowrap;">Limpar</button>
      </div>
    </div>
    <div id="listaHistorico"><p class="empty-msg">Nenhum histórico ainda.</p></div>
  </section>

</main>

<!-- ══ MODAL: RESUMO DIÁRIO DA RUTA ══ -->
<div class="modal-overlay" id="modalResumoDiario">
  <div class="modal" style="max-width:720px">
    <div class="modal-header">
      <h3>Resumo Diário da Ruta</h3>
      <button class="btn-close" onclick="closeModal('modalResumoDiario')"></button>
    </div>
    <div class="modal-body">
      <!-- Filtro de data -->
      <div class="form-group" style="display:flex;gap:10px;align-items:end;margin-bottom:14px">
        <div style="flex:1">
          <label>Data da rota</label>
          <input type="date" id="resumo_data" />
        </div>
        <button class="btn-primary" id="btnRecarregarResumo" style="padding:10px 14px">Recarregar</button>
      </div>

      <div class="form-separator">Clientes</div>
      <div class="resumo-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="resumo-card"><span class="resumo-val" id="res_clientesInicio">0</span><span class="resumo-lab">Total Início</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_clientesNovos">0</span><span class="resumo-lab">Novos</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_clientesRenovacao">0</span><span class="resumo-lab">Com Renovação</span></div>
      </div>

      <div class="form-separator">Cobrança (Baixas)</div>
      <div class="resumo-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="resumo-card"><span class="resumo-val" id="res_clientesCobrados">0</span><span class="resumo-lab">Clientes Cobrados</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_baixasQtd" style="color:#22c55e">0</span><span class="resumo-lab">Baixas (Pagaram)</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_clientesPendentes" style="color:#e85656">0</span><span class="resumo-lab">Pendentes</span></div>
      </div>

      <div class="form-separator">Financeiro do Dia</div>
      <div class="resumo-grid" style="grid-template-columns:repeat(2,1fr)">
        <div class="resumo-card"><span class="resumo-val" id="res_valorInvestidoDia">R$ 0,00</span><span class="resumo-lab">Vendas</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_valorEsperado">R$ 0,00</span><span class="resumo-lab">Total Esperado</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_valorRecebido" style="color:#22c55e">R$ 0,00</span><span class="resumo-lab">Total Recebido / Baixado</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_valorEmAberto" style="color:#e85656">R$ 0,00</span><span class="resumo-lab">Total em Aberto</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_jurosRecebidosHoje" style="color:#22c55e">R$ 0,00</span><span class="resumo-lab">Juros Recebidos Hoje</span></div>
      </div>

      <div class="form-separator">Vendas do Dia</div>
      <div class="resumo-grid" style="grid-template-columns:repeat(2,1fr)">
        <div class="resumo-card"><span class="resumo-val" id="res_vendasQtd">0</span><span class="resumo-lab">Total Vendas</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_vendasValor">R$ 0,00</span><span class="resumo-lab">Valor Total Vendido</span></div>
        <div class="resumo-card"><span class="resumo-val"><span id="res_vendasNovasQtd">0</span> · <span id="res_vendasNovasValor" style="font-size:13px;color:var(--text-secondary)">R$ 0,00</span></span><span class="resumo-lab">Novas</span></div>
        <div class="resumo-card"><span class="resumo-val"><span id="res_vendasRenovQtd">0</span> · <span id="res_vendasRenovValor" style="font-size:13px;color:var(--text-secondary)">R$ 0,00</span></span><span class="resumo-lab">Renovações</span></div>
      </div>

      <div class="form-separator">Movimentações do Dia</div>
      <div class="resumo-grid" style="grid-template-columns:repeat(2,1fr)">
        <div class="resumo-card"><span class="resumo-val" id="res_entradasHoje" style="color:#22c55e">R$ 0,00</span><span class="resumo-lab">Entradas hoje</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_retiradasHoje" style="color:#e85656">R$ 0,00</span><span class="resumo-lab">Retiradas hoje</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_despesasHoje" style="color:#e85656">R$ 0,00</span><span class="resumo-lab">Despesas hoje</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_ajustesHoje">R$ 0,00</span><span class="resumo-lab">Ajustes de caixa hoje</span></div>
      </div>

      <div class="resumo-card" style="margin-top:14px;background:var(--accent-dim);border-color:var(--accent);padding:18px 8px">
        <span class="resumo-val" id="res_saldoFinal" style="font-size:26px;color:var(--accent)">R$ 0,00</span>
        <span class="resumo-lab" style="color:var(--accent)">SALDO FINAL DO DIA</span>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-primary" style="width:100%" onclick="closeModal('modalResumoDiario')">Fechar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: RESUMO GERAL DA RUTA ══ -->
<div class="modal-overlay" id="modalResumoGeral">
  <div class="modal" style="max-width:720px">
    <div class="modal-header">
      <h3>Resumo Geral da Ruta</h3>
      <button class="btn-close" onclick="closeModal('modalResumoGeral')"></button>
    </div>
    <div class="modal-body">
      <div class="resumo-card" style="margin-top:8px;background:var(--accent-dim);border-color:var(--accent);padding:18px 8px">
        <span class="resumo-val" id="res_saldoFinalRuta" style="font-size:26px;color:var(--accent)">R$ 0,00</span>
        <span class="resumo-lab" style="color:var(--accent)">Saldo Final da Rota</span>
      </div>
      <div class="resumo-grid" style="margin-top:12px">
        <div class="resumo-card"><span class="resumo-val" id="res_totalEmprestado">R$ 0,00</span><span class="resumo-lab">Total Emprestado</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_emprestadoAtualmente">R$ 0,00</span><span class="resumo-lab">Emprestado Atualmente na Rua</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_totalAReceber">R$ 0,00</span><span class="resumo-lab">Total em Aberto</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_totalJuros">R$ 0,00</span><span class="resumo-lab">Total de Juros Recebidos</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_totalAportes">R$ 0,00</span><span class="resumo-lab">Total de Aportes</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_totalRetiradas">R$ 0,00</span><span class="resumo-lab">Total de Retiradas</span></div>
        <div class="resumo-card"><span class="resumo-val" id="res_totalParcelasRecebidas">R$ 0,00</span><span class="resumo-lab">Total de Parcelas Recebidas</span></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-primary" style="width:100%" onclick="closeModal('modalResumoGeral')">Fechar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: EVENTOS DA RUTA ══ -->
<div class="modal-overlay" id="modalEventosRuta">
  <div class="modal">
    <div class="modal-header">
      <h3>Eventos da Ruta</h3>
      <button class="btn-close" onclick="closeModal('modalEventosRuta')"></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label>Tipo de Evento</label>
        <select id="ev_tipo">
          <option value="despesa">Despesa (Gasto operacional)</option>
          <option value="retirada">Retirada (Saída do dono)</option>
          <option value="aporte">Aporte / Ingresso adicional</option>
          <option value="ajuste">Ajuste de Caixa</option>
        </select>
      </div>
      <div class="form-group">
        <label>Valor (R$)</label>
        <input type="number" id="ev_valor" step="0.01" placeholder="0,00"/>
      </div>
      <div class="form-group">
        <label>Descrição / Motivo</label>
        <input type="text" id="ev_descricao" placeholder="Ex: Combustível, Almoço..."/>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" onclick="closeModal('modalEventosRuta')">Cancelar</button>
      <button class="btn-primary" id="btnSalvarEvento">Registrar Evento</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: FECHAMENTO COM PIN ══ -->
<div class="modal-overlay" id="modalFechamentoRuta">
  <div class="modal" style="max-width:320px">
    <div class="modal-header">
      <h3>Fechar Ruta</h3>
      <button class="btn-close" onclick="closeModal('modalFechamentoRuta')"></button>
    </div>
    <div class="modal-body">
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:15px;text-align:center">
        Insira o PIN de fechamento para encerrar as operações de hoje.
      </p>
      <input type="password" id="fechamentoPin" class="pin-input-modal" maxlength="4" inputmode="numeric" placeholder="0000"/>
      <div id="fechamentoErro" class="pin-erro">PIN incorreto!</div>
    </div>
    <div class="modal-footer">
      <button class="btn-primary" style="width:100%" id="btnConfirmarFechamento">Confirmar Fechamento</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: NOVO/EDITAR CLIENTE ══ -->
<div class="modal-overlay" id="modalCliente">
  <div class="modal">
    <div class="modal-header">
      <h3 id="modalClienteTitulo">Novo Cliente</h3>
      <button class="btn-close" id="closeModalCliente"></button>
    </div>
    <div class="modal-body">
      <div class="fotos-manager">
        <div class="fotos-manager-header">
          <span class="fotos-manager-title">Fotos do Cliente</span>
          <button class="btn-add-foto" id="btnAddFoto">+ Foto</button>
        </div>
        <div class="fotos-grid-upload" id="fotosGridUpload"></div>
        <div style="font-size:11px;color:var(--text-muted)">
          Toque duas vezes em uma foto para editar o rótulo.
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>ID / Nº do Cliente</label>
          <input type="text" id="clienteId" placeholder="001"/>
        </div>
        <div class="form-group">
          <label>Nome Comercial</label>
          <input type="text" id="clienteNomeComercial" placeholder="Apelido ou empresa"/>
        </div>
      </div>
      <div class="form-group">
        <label>Nome Completo *</label>
        <input type="text" id="clienteNome" placeholder="Nome completo" required/>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>CPF *</label>
          <input type="text" id="clienteCpf" placeholder="000.000.000-00" maxlength="14" inputmode="numeric" required/>
        </div>
        <div class="form-group">
          <label>RG *</label>
          <input type="text" id="clienteRg" placeholder="00.000.000-0" maxlength="12" required/>
        </div>
      </div>
      <div class="form-group">
        <label>Celular</label>
        <input type="tel" id="clienteCelular" placeholder="(00) 00000-0000"/>
      </div>
      <div class="form-group">
        <label>Tipo de Endereço</label>
        <select id="clienteTipoEndereco">
          <option value="residencial">Residencial</option>
          <option value="comercial">Comercial</option>
          <option value="ambos">Ambos</option>
        </select>
      </div>
      <div class="form-group" id="grpEnderecoRes">
        <label>Endereço Residencial</label>
        <input type="text" id="clienteEnderecoRes" placeholder="Rua, número, bairro..."/>
      </div>
      <div class="form-group" id="grpEnderecoCom">
        <label>Endereço Comercial</label>
        <input type="text" id="clienteEnderecoCom" placeholder="Rua, número, bairro..."/>
      </div>
      <div class="form-group">
        <label>Observações</label>
        <textarea id="clienteObs" placeholder="Observações sobre o cliente..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarCliente">Cancelar</button>
      <button class="btn-primary" id="salvarCliente">Salvar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: NOVA VENDA ══ -->
<div class="modal-overlay" id="modalVenda">
  <div class="modal">
    <div class="modal-header">
      <h3 id="modalVendaTitulo">Nova Venda / Empréstimo</h3>
      <button class="btn-close" id="closeModalVenda"></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label>Cliente *</label>
        <select id="vendaCliente"><option value="">Selecione o cliente</option></select>
      </div>
      <div class="form-separator">Valores</div>
      <div class="form-row">
        <div class="form-group">
          <label>Valor Emprestado (R$) *</label>
          <input type="number" id="vendaValorEmprestimo" placeholder="0,00" step="0.01" min="0.01"/>
        </div>
        <div class="form-group">
          <label>Juros (%)</label>
          <input type="number" id="vendaJurosPct" placeholder="0" step="0.01" min="0" value="0"/>
        </div>
      </div>
      <!-- Campos ocultos para jurosValor, total e valorParcela (calculados automaticamente) -->
      <input type="hidden" id="vendaJurosValor" value="0"/>
      <input type="hidden" id="vendaTotal" value="0"/>
      <input type="hidden" id="vendaParcelaValor" value="0"/>
      <div class="form-separator">Parcelas</div>
      <div class="form-row">
        <div class="form-group">
          <label>Nº de Parcelas *</label>
          <input type="number" id="vendaNumParcelas" placeholder="Ex: 12" min="1"/>
        </div>
        <div class="form-group">
          <label>Tipo de Vencimento *</label>
          <select id="vendaTipoVenc">
            <option value="mensal">Mensal</option>
            <option value="quinzenal">Quinzenal</option>
            <option value="semanal">Semanal</option>
            <option value="diario">Diário</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Data da 1ª Parcela *</label>
        <input type="date" id="vendaDataInicio"/>
      </div>
      <div class="form-separator">Regra de multa por atraso</div>
      <div class="form-row">
        <div class="form-group">
          <label>Dias para multa aumentar</label>
          <input type="number" id="vendaDiasMulta" placeholder="Ex: 2" min="1" value="2"/>
        </div>
        <div class="form-group">
          <label>Valor da multa (R$)</label>
          <input type="number" id="vendaValorMulta" placeholder="Ex: 10,00" step="0.01" min="0"/>
        </div>
      </div>
      <div style="font-size:12px;color:var(--text-muted);background:var(--bg-elevated);
           border-radius:var(--radius-sm);padding:10px 12px;line-height:1.6">
        A cada <strong id="diasMultaPreview" style="color:var(--yellow)">2 dias</strong> de atraso
        (sem contar domingos), a dívida aumenta
        <strong id="valorMultaPreview" style="color:var(--red)">R$ —</strong> automaticamente.
      </div>
      <div class="resumo-venda-box" id="resumoVenda" style="display:none">
        <div class="resumo-titulo">Resumo</div>
        <div class="rv-linha"><span>Valor emprestado</span><span id="rv_emprestimo">—</span></div>
        <div class="rv-linha rv-juros"><span>+ Juros</span><span id="rv_juros">—</span></div>
        <div class="rv-linha rv-total"><span>= Total a pagar</span><span id="rv_total">—</span></div>
        <div class="rv-linha"><span>Valor por parcela</span><span id="rv_parcela" class="rv-destaque">—</span></div>
      </div>
    </div>
      <div class="form-separator">Fotos da Venda</div>
      <div class="fotos-manager">
        <div class="fotos-manager-header">
          <span class="fotos-manager-title">Fotos da Venda (mínimo 2)</span>
          <button class="btn-add-foto" id="btnAddFotoVenda" type="button">+ Foto</button>
        </div>
        <div class="fotos-grid-upload" id="fotosGridUploadVenda"></div>
        <p style="font-size:10px;color:var(--text-muted);margin:4px 0 0">
          Toque duas vezes em uma foto para editar o rótulo.
        </p>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarVenda">Cancelar</button>
      <button class="btn-primary" id="salvarVendaBtn">Registrar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: DETALHE CLIENTE ══ -->
<div class="modal-overlay modal-full" id="modalDetalheCliente">
  <div class="modal modal-large">
    <div class="modal-header">
      <h3 id="detalheClienteNome">Cliente</h3>
      <button class="btn-close" id="closeDetalheCliente"></button>
    </div>
    <div class="modal-body" id="detalheClienteBody"></div>
    <div class="modal-footer">
      <button class="btn-warning" id="btnNovaVendaCliente">Nova Venda</button>
      <button class="btn-secondary" id="btnEditarCliente">Editar</button>
<!-- <button class="btn-danger" id="btnExcluirCliente"></button> -->
    </div>
  </div>
</div>

<!-- ══ MODAL: REGISTRAR PAGAMENTO ══ -->
<div class="modal-overlay" id="modalPagamento">
  <div class="modal">
    <div class="modal-header">
      <h3>Registrar Pagamento</h3>
      <button class="btn-close" id="closeModalPagamento"></button>
    </div>
    <div class="modal-body" id="pagamentoInfo"></div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarPagamento">Cancelar</button>
      <button class="btn-primary" id="confirmarPagamento">Confirmar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: HISTÓRICO DE PARCELAS ══ -->
<div class="modal-overlay modal-full" id="modalHistoricoParcelas">
  <div class="modal modal-large">
    <div class="modal-header">
      <h3 id="historicoParcelasTitulo">Histórico de Parcelas</h3>
      <button class="btn-close" id="closeModalHistoricoParcelas"></button>
    </div>
    <div class="modal-body" id="historicoParcelasBody"></div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarHistoricoParcelas">Fechar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: MULTAS ══ -->
<div class="modal-overlay" id="modalMulta">
  <div class="modal">
    <div class="modal-header">
      <h3>Gestão de multas</h3>
      <button class="btn-close" id="closeModalMulta"></button>
    </div>
    <div class="modal-body" id="multaInfo"></div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarMulta">Fechar</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: PIN GALERIA ══ -->
<div class="modal-overlay" id="modalPin">
  <div class="modal">
    <div class="modal-header">
      <h3>Galeria Protegida</h3>
      <button class="btn-close" id="closeModalPin"></button>
    </div>
    <div class="modal-body">
      <div class="pin-dica">Digite o PIN para visualizar as fotos</div>
      <div class="form-group">
        <input type="password" id="pinInput" class="pin-input-modal"
               placeholder="••••" maxlength="6" inputmode="numeric"/>
      </div>
      <div class="pin-erro" id="pinErro">PIN incorreto. Tente novamente.</div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" id="cancelarPin">Cancelar</button>
      <button class="btn-primary" id="confirmarPin">Desbloquear</button>
    </div>
  </div>
</div>

<!-- ══ MODAL: CONFIGURAÇÕES ══ -->
<div class="modal-overlay modal-full" id="modalSettings">
  <div class="modal modal-large">
    <div class="modal-header">
      <h3>Configurações</h3>
      <button class="btn-close" id="closeModalSettings"></button>
    </div>
    <div class="modal-body">
      <div class="settings-section">
        <div class="settings-section-title">Proteção de Galeria</div>
        <div class="settings-row-left" style="margin-bottom:8px">
          <div class="sr-title">PIN de Acesso às Fotos</div>
          <div class="sr-sub">Exige PIN para visualizar galeria completa</div>
        </div>
        <div class="pin-config-row">
          <input type="password" id="settingsPinInput" placeholder="Novo PIN" maxlength="6"
                 inputmode="numeric" style="max-width:130px;letter-spacing:4px;font-size:16px"/>
          <button class="btn-pin btn-pin-set" id="btnSetPin">Definir PIN</button>
          <button class="btn-pin btn-pin-clear" id="btnClearPin">Remover</button>
        </div>
        <div class="pin-status" id="pinStatus">Sem PIN definido</div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Cor de Destaque</div>
        <div class="cor-paleta">
          <div class="cor-opcao ativa" data-cor="#4f8ef7" data-hover="#3a7ae6" style="background:#4f8ef7"></div>
          <div class="cor-opcao" data-cor="#2ecc8a" data-hover="#27b07a" style="background:#2ecc8a"></div>
          <div class="cor-opcao" data-cor="#f5b731" data-hover="#e0a010" style="background:#f5b731"></div>
          <div class="cor-opcao" data-cor="#e85656" data-hover="#cc3c3c" style="background:#e85656"></div>
          <div class="cor-opcao" data-cor="#a78bfa" data-hover="#9370f0" style="background:#a78bfa"></div>
          <div class="cor-opcao" data-cor="#f97316" data-hover="#e86010" style="background:#f97316"></div>
          <div class="cor-opcao" data-cor="#ec4899" data-hover="#d93080" style="background:#ec4899"></div>
          <div class="cor-opcao" data-cor="#06b6d4" data-hover="#0099b8" style="background:#06b6d4"></div>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Aparência</div>
        <div class="settings-row">
          <div class="settings-row-left">
            <div class="sr-title">Tema Claro</div>
            <div class="sr-sub">Fundo branco/cinza claro</div>
          </div>
          <label class="toggle-switch">
            <input type="checkbox" id="temaClaro"/>
            <div class="toggle-track"></div>
          </label>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Tamanho do Texto</div>
        <div class="font-size-row">
          <button class="font-opt" data-size="13" style="font-size:12px">Pequeno</button>
          <button class="font-opt ativa" data-size="15" style="font-size:14px">Normal</button>
          <button class="font-opt" data-size="17" style="font-size:16px">Grande</button>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Conta</div>
        <div style="font-size:13px;color:var(--text-secondary);line-height:1.8">
          <strong style="color:var(--text-primary)"><?= htmlspecialchars($usuario['nome']) ?></strong><br>
          <?= htmlspecialchars($usuario['email']) ?><br>
          <span style="color:var(--text-muted)">Tipo: <?= htmlspecialchars($usuario['tipo']) ?></span>
        </div>
        <a href="<?= BASE_URL ?>/app/auth/logout.php" style="display:inline-block;margin-top:8px;
           background:var(--red-dim);color:var(--red);font-weight:700;font-size:13px;
           padding:9px 16px;border-radius:var(--radius-sm);text-decoration:none;
           border:1px solid rgba(232,86,86,.25);">Sair do sistema</a>
      </div>

      <div class="settings-section" id="sectionRutaConfig">
        <div class="settings-section-title">Dados da RUTA</div>
        <div id="rutaConfigContent">
          <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">Carregando dados da RUTA...</p>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">ℹ️ Sobre</div>
        <div style="font-size:13px;color:var(--text-secondary);line-height:1.7">
          <strong style="color:var(--text-primary)">R. Créditos — Gestão de Finanças</strong><br>
          Sistema de controle de empréstimos · v1.0<br>
          <span style="color:var(--text-muted)">Dados salvos em banco MySQL via PHP.</span>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" id="fecharSettings">Fechar</button>
    </div>
  </div>
</div>

<!-- LIGHTBOX -->
<div class="lightbox-overlay" id="lightbox">
  <button class="lightbox-close" id="lightboxClose"></button>
  <img src="" alt="" class="lightbox-img" id="lightboxImg"/>
  <div class="lightbox-caption" id="lightboxCaption"></div>
</div>

<div class="toast" id="toast"></div>

<script>
'use strict';
/* BASE_URL injetado pelo PHP — funciona em qualquer subpasta */
const BASE_URL = '<?= BASE_URL ?>';

/* ═══════════════════════════════════════════════════════════
   GERENCIAMENTO DE TOKEN JWT
   CORRIGIDO: token salvo no sessionStorage pelo login.php
   e enviado em TODAS as requisições via Authorization header
═══════════════════════════════════════════════════════════ */
function getToken() {
  return sessionStorage.getItem('rc_token') || '';
}

function clearToken() {
  sessionStorage.removeItem('rc_token');
  sessionStorage.removeItem('rc_usuario');
}

/* ═══════════════════════════════════════════════════════════
   API BRIDGE — Chamadas ao backend PHP com JWT
═══════════════════════════════════════════════════════════ */
const API_URL = BASE_URL + '/app/api/index.php';

async function api(action, dados = {}) {
  const token = getToken();

  // ⚠ Se não tiver token, redireciona imediatamente para login
  if (!token) {
    window.location.href = BASE_URL + '/app/auth/login.php';
    return null;
  }

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token,   //  CORRIGIDO: envia JWT
      },
      body: JSON.stringify({ action, ...dados }),
    });

    if (res.status === 401) {
      clearToken();
      window.location.href = BASE_URL + '/app/auth/login.php';
      return null;
    }

    let json;
    try {
      json = await res.json();
    } catch (e) {
      const text = await res.text();
      console.error('Erro ao processar JSON da API:', e, 'Resposta bruta:', text);
      if (text.includes('Erro de conexão com o banco')) {
        showToast('Erro: Banco de dados não configurado no servidor', 'error');
      } else {
        showToast('Erro de resposta do servidor (formato inválido)', 'error');
      }
      return null;
    }

    if (!json.sucesso) {
      console.error('API Error:', json.mensagem, json);
      // MULTAS_PENDENTES: propaga o objeto de erro para que salvarVenda possa tratar
      // sem mostrar toast genérico (o toast será exibido pelo handler do pagamento)
      if (json.erro === 'MULTAS_PENDENTES') {
        return { _apiErro: true, erro: 'MULTAS_PENDENTES', mensagem: json.mensagem };
      }
      showToast(json.mensagem || 'Erro na API', 'error');
      return null;
    }
    // Retorna objeto sentinela se dados for null para não falhar check de (res !== null)
    return json.dados !== null ? json.dados : { _ok: true };
  } catch (err) {
    console.error('Erro de rede:', err);
    showToast('Erro de conexão com o servidor', 'error');
    return null;
  }
}

// Normaliza snake_case do MySQL → camelCase do JS
function normCliente(r) {
  if (!r) return null;
  return {
    id: r.id, nome: r.nome,
    idNumerico:    r.id_numerico    ?? r.idNumerico    ?? '',
    nomeComercial: r.nome_comercial ?? r.nomeComercial ?? '',
    cpf:           r.cpf    ?? '',
    rg:            r.rg     ?? '',
    celular:       r.celular ?? '',
    tipoEndereco:  r.tipo_endereco ?? r.tipoEndereco ?? 'residencial',
    enderecoRes:   r.endereco_res ?? r.enderecoRes ?? '',
    enderecoCom:   r.endereco_com ?? r.enderecoCom ?? '',
    obs:           r.obs ?? '',
    _fotoThumb:    r.foto_thumb ?? r._fotoThumb ?? null,
    criadoEm:      r.criado_em ?? r.criadoEm ?? '',
  };
}
function normVenda(r) {
  if (!r) return null;
  return {
    id:                parseInt(r.id),
    clienteId:         r.cliente_id         ?? r.clienteId,
    valorEmprestimo:   parseFloat(r.valor_emprestimo  ?? r.valorEmprestimo  ?? 0),
    jurosPct:          parseFloat(r.juros_pct         ?? r.jurosPct         ?? 0),
    jurosValor:        parseFloat(r.juros_valor        ?? r.jurosValor       ?? 0),
    totalComJuros:     parseFloat(r.total_com_juros    ?? r.totalComJuros    ?? 0),
    numParcelas:       parseInt(r.num_parcelas    ?? r.numParcelas    ?? 0),
    tipoVenc:          r.tipo_venc           ?? r.tipoVenc           ?? 'mensal',
    parcelasPagas:     parseInt(r.parcelas_pagas  ?? r.parcelasPagas  ?? 0),
    saldoParcialPago:  parseFloat(r.saldo_parcial_pago ?? r.saldoParcialPago ?? 0),
    valorParcela:      parseFloat(r.valor_parcela       ?? r.valorParcela      ?? 0),
    dataInicio:        r.data_inicio        ?? r.dataInicio        ?? '',
    diasMulta:         parseInt(r.dias_multa    ?? r.diasMulta    ?? 2),
    valorMulta:        parseFloat(r.valor_multa        ?? r.valorMulta        ?? 0),
    ultimoPagamentoData: r.ultimo_pagamento   ?? r.ultimoPagamentoData ?? null,
    ultimoFormaPag:    r.ultima_forma_pag    ?? r.ultimoFormaPag    ?? null,
    criadoEm:          r.criado_em           ?? r.criadoEm          ?? '',
  };
}
function normParcela(r) {
  if (!r) return null;
  return {
    id:             parseInt(r.id),
    vendaId:        parseInt(r.venda_id  ?? r.vendaId),
    clienteId:      r.cliente_id         ?? r.clienteId,
    numero:         parseInt(r.numero),
    dataVencimento: r.data_vencimento    ?? r.dataVencimento ?? '',
    valor:          parseFloat(r.valor   ?? 0),
    valorPago:      r.valor_pago != null  ? parseFloat(r.valor_pago) : null,
    status:         r.status             ?? 'futuro',
    tipo:           r.tipo               ?? 'normal',
    motivo:         r.motivo             ?? null,
    dataPagamento:  r.data_pagamento     ?? r.dataPagamento  ?? null,
    formaPagamento: r.forma_pagamento    ?? r.formaPagamento ?? null,
    atualizadoEm:   r.atualizado_em      ?? r.atualizadoEm   ?? '',
  };
}
function normMulta(r) {
  if (!r) return null;
  return {
    id:          parseInt(r.id),
    vendaId:     parseInt(r.venda_id    ?? r.vendaId),
    clienteId:   r.cliente_id           ?? r.clienteId,
    parcelaRef:  r.parcela_ref != null  ? parseInt(r.parcela_ref) : null,
    valor:       parseFloat(r.valor     ?? 0),
    motivo:      r.motivo               ?? '',
    origem:      r.origem               ?? 'auto',
    status:      r.status               ?? 'aberto',
    pagoEm:      r.pago_em              ?? r.pagoEm       ?? null,
    convertidoEm:r.convertido_em        ?? r.convertidoEm ?? null,
    criadoEm:    r.criado_em            ?? r.criadoEm     ?? '',
  };
}
function normPagamento(r) {
  if (!r) return null;
  return {
    id:                  parseInt(r.id),
    vendaId:             parseInt(r.venda_id             ?? r.vendaId),
    clienteId:           r.cliente_id                    ?? r.clienteId,
    tipo:                r.tipo                          ?? 'pagamento',
    valorPago:           parseFloat(r.valor_pago         ?? r.valorPago         ?? 0),
    formaPagamento:      r.forma_pagamento               ?? r.formaPagamento     ?? null,
    motivo:              r.motivo                        ?? null,
    pagasIntAntes:       parseInt(r.pagas_int_antes      ?? r.pagasIntAntes      ?? 0),
    pagasIntAgora:       parseInt(r.pagas_int_agora      ?? r.pagasIntAgora      ?? 0),
    saldoParcialAntes:   parseFloat(r.saldo_parcial_antes  ?? r.saldoParcialAntes  ?? 0),
    saldoParcialDepois:  parseFloat(r.saldo_parcial_depois ?? r.saldoParcialDepois ?? 0),
    quantidadeParcelas:  parseInt(r.quantidade_parcelas  ?? r.quantidadeParcelas ?? 0),
    data:                r.data                          ?? '',
    dataPagamento:       r.data_pagamento                ?? r.dataPagamento      ?? '',
  };
}
function normHistoricoCobranca(r) {
  if (!r) return null;
  return {
    id: parseInt(r.id), vendaId: parseInt(r.venda_id ?? r.vendaId), clienteId: r.cliente_id ?? r.clienteId,
    parcelaNumero: parseInt(r.parcela_numero ?? r.parcelaNumero ?? 0), dataCobranca: r.data_cobranca ?? r.dataCobranca ?? '',
    situacao: r.situacao ?? 'pendente', observacao: r.observacao ?? '', pagamentoId: r.pagamento_id ?? r.pagamentoId ?? null,
    dataPagamento: r.data_pagamento ?? r.dataPagamento ?? null, valorPago: parseFloat(r.valor_pago ?? r.valorPago ?? 0)
  };
}
function normFoto(r) {
  if (!r) return null;
  return {
    id:          parseInt(r.id),
    clienteId:   r.cliente_id  ?? r.clienteId,
    pagamentoId: r.pagamento_id != null ? parseInt(r.pagamento_id) : null,
    data:        r.imagem_base64 ?? r.data ?? (r.label && r.label.startsWith('data:image/') ? r.label : '') ?? '',
    label:       (r.label && !r.label.startsWith('data:image/')) ? r.label : '',
    dataFoto:    r.data_foto     ?? '',
    ordem:       parseInt(r.ordem ?? 0),
  };
}

/* ── Wrappers compatíveis com o código original ── */
const listarClientes  = async () => {
  try {
    const clientes = await api('clientes.listar') || [];
    if (!Array.isArray(clientes)) {
      console.error('Erro: clientes.listar retornou dados inválidos', clientes);
      return [];
    }
    return clientes.map(normCliente).filter(c => c !== null);
  } catch (e) {
    console.error('Erro ao listar clientes:', e);
    return [];
  }
};
const getCliente      = async id => normCliente(await api('clientes.buscar', { id }));
const salvarCliente   = async c  => api('clientes.salvar',  { dados: c });
const excluirCliente  = async id => api('clientes.excluir', { id });

const listarVendas       = async ()    => {
  try {
    const vendas = await api('vendas.listar') || [];
    if (!Array.isArray(vendas)) {
      console.error('Erro: vendas.listar retornou dados invalidos', vendas);
      return [];
    }
    return vendas.map(normVenda).filter(v => v !== null);
  } catch (e) {
    console.error('Erro ao listar vendas:', e);
    return [];
  }
};
const salvarVenda        = async v     => { 
  const r = await api("vendas.salvar", { dados: v }); 
  // Detecta bloqueio por multas pendentes (api() agora propaga o objeto em vez de null)
  if (r && r._apiErro && r.erro === "MULTAS_PENDENTES") {
    return { erro: "MULTAS_PENDENTES", mensagem: r.mensagem };
  }
  // Aborta se a API falhou ou não retornou id — evita parcelas órfãs
  if (!r || (!r.id && r.erro !== "MULTAS_PENDENTES")) return null;
  if (r.erro === "MULTAS_PENDENTES") return { erro: "MULTAS_PENDENTES", mensagem: r.mensagem };
  const vendaId = r?.id ?? v.id;
  // Processa multas automáticas após salvar venda
  try {
    const vendaAtualizada = await api('vendas.buscar', { id: vendaId });
    if (vendaAtualizada) {
      const vendaNorm = normVenda(vendaAtualizada);
      await processarMultasAutomaticas(vendaNorm);
    }
  } catch (e) {
    console.error('Erro ao processar multas após salvar venda:', e);
  }
  return vendaId;
};
const excluirVenda       = async id    => api('vendas.excluir', { id });
const getVendasDoCliente = async cid   => (await api('vendas.porCliente', { clienteId: cid }) || []).map(normVenda);

const listarParcelas            = async ()    => (await api('parcelas.listar')  || []).map(normParcela);
const getParcelas               = async vid   => (await api('parcelas.porVenda',{ vendaId: vid }) || []).map(normParcela);
const getHistoricoCobranca      = async vid   => (await api('historico_cobrancas.porVenda',{ vendaId: vid }) || []).map(normHistoricoCobranca).filter(Boolean);
const salvarParcela             = async p     => { const r = await api('parcelas.salvar', { dados: p }); return r?.id ?? p.id; };
const excluirParcelasPorVenda   = async vid   => api('parcelas.excluirPorVenda',   { vendaId:   vid });
const excluirParcelasPorCliente = async cid   => api('parcelas.excluirPorCliente', { clienteId: cid });

const listarMultas            = async ()    => (await api('multas.listar')  || []).map(normMulta);
const getMultasVenda          = async vid   => (await api('multas.porVenda',{ vendaId: vid }) || []).map(normMulta);
const salvarMulta             = async m     => { const r = await api('multas.salvar', { dados: m }); return r?.id ?? m.id; };
const excluirMulta            = async id    => api('multas.excluir',            { id });
const excluirMultasPorVenda   = async vid   => api('multas.excluirPorVenda',   { vendaId:   vid });
const excluirMultasPorCliente = async cid   => api('multas.excluirPorCliente', { clienteId: cid });
// getMultaById via buscar
async function getMultaById(id) {
  return normMulta(await api('multas.buscar', { id }));
}

const listarPagamentos            = async ()  => (await api('pagamentos.listar') || []).map(normPagamento);
const salvarPagamento             = async p   => { const r = await api('pagamentos.salvar', { dados: p }); return r?.id; };
const registrarPagamentoTransacional = async d => { 
  const r = await api('pagamentos.registrar_transacional', { dados: d }); 
  return r; 
};
const excluirPagamentosPorCliente = async cid => api('pagamentos.excluirPorCliente', { clienteId: cid });

const getFotos               = async cid => (await api('fotos.porCliente', { clienteId: cid }) || []).map(normFoto);
const salvarFoto      = async f => api('fotos.salvar', { dados: { ...f, data: f.data || f.base64 } });
const excluirFoto            = async id  => api('fotos.excluir',            { id });
const excluirFotosPorCliente = async cid => api('fotos.excluirPorCliente',  { clienteId: cid });

/* ═══════════════════════════════════════════════════════════
   UTILS
═══════════════════════════════════════════════════════════ */
const fmt     = v  => 'R$ ' + parseFloat(v||0).toFixed(2).replace('.', ',');
const pct     = v  => parseFloat(v||0).toFixed(2).replace('.', ',') + '%';
const hoje = () => {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
const fmtData = d  => d ? d.split('-').reverse().join('/') : '—';
const gerarId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

function diasDeAtraso(dataVenc) {
  if (!dataVenc) return 0;
  // UTC-based calculation to avoid DST timezone shifts
  const parts = dataVenc.split('-');
  const vencMs = Date.UTC(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
  const hj = hoje().split('-');
  const hojeMs = Date.UTC(parseInt(hj[0]), parseInt(hj[1]) - 1, parseInt(hj[2]));
  if (hojeMs <= vencMs) return 0;
  // Conta os dias corridos entre o vencimento e hoje, EXCLUINDO os domingos
  // (domingo não conta como dia de atraso).
  const umDiaMs = 24 * 60 * 60 * 1000;
  let dias = 0;
  for (let ms = vencMs + umDiaMs; ms <= hojeMs; ms += umDiaMs) {
    const diaSemana = new Date(ms).getUTCDay(); // 0 = domingo
    if (diaSemana !== 0) dias++;
  }
  return dias;
}

function calcularDataParcela(dataInicio, numero, tipoVenc = 'mensal') {
  if (!dataInicio) return null;

  // ── REGRA GLOBAL DE VENCIMENTOS: nenhuma parcela pode vencer em um domingo. ──
  // O domingo é completamente ignorado no cálculo do calendário: sempre que um
  // vencimento cair em um domingo, ele é automaticamente transferido para a
  // segunda-feira seguinte. Esta regra vale para toda venda nova, todo
  // recálculo e toda rotina que gere ou reprocesse parcelas, pois esta função
  // é o único ponto de cálculo de vencimento usado em todo o sistema.
  if (tipoVenc === 'diario') {
    // No modo diário o intervalo entre parcelas é de apenas 1 dia, então não
    // basta empurrar cada parcela isoladamente para a segunda-feira: isso
    // faria a parcela empurrada colidir com a data da parcela seguinte
    // (duas parcelas na mesma data). Por isso, para o diário, o domingo é
    // tratado como um dia que não existe no calendário: avançamos dia a dia
    // a partir de dataInicio, contando apenas os dias que não são domingo,
    // até completar (numero - 1) parcelas. Isso garante datas sempre únicas
    // e nunca um vencimento em domingo.
    const b = new Date(dataInicio + 'T00:00:00');
    if (b.getDay() === 0) b.setDate(b.getDate() + 1); // 1ª parcela: domingo -> segunda
    let restante = numero - 1;
    while (restante > 0) {
      b.setDate(b.getDate() + 1);
      if (b.getDay() !== 0) restante--; // domingo não conta como avanço de parcela
    }
    return b.toISOString().split('T')[0];
  }

  const b = new Date(dataInicio + 'T00:00:00');
  const n = numero - 1;
  switch (tipoVenc) {
    case 'semanal':   b.setDate(b.getDate() + n * 7);    break;
    case 'quinzenal': b.setDate(b.getDate() + n * 15);   break;
    case 'mensal':
    default:          b.setMonth(b.getMonth() + n);      break;
  }
  // Semanal/quinzenal/mensal: o intervalo entre parcelas é grande o
  // suficiente (>=7 dias) para que empurrar uma parcela isolada de domingo
  // para segunda nunca colida com a parcela seguinte da sequência.
  if (b.getDay() === 0) b.setDate(b.getDate() + 1);
  return b.toISOString().split('T')[0];
}

function calcularVenda(v) {
  const emp        = parseFloat(v.valorEmprestimo || 0);
  const jPct       = parseFloat(v.jurosPct        || 0);
  const pagasInt   = parseInt(v.parcelasPagas      || 0, 10);
  const jaPagoFrac = parseFloat(v.saldoParcialPago || 0);
  const juros      = +(v.jurosValor || (emp * jPct / 100)).toFixed(2);
  const total      = +(v.totalComJuros || (emp + juros)).toFixed(2);
  const parcela    = v.numParcelas > 0 ? +(v.valorParcela || (total / v.numParcelas)).toFixed(2) : 0;
  const restam     = Math.max(0, v.numParcelas - pagasInt);
  const saldoParcelas = Math.max(0, +(total - (pagasInt * parcela + jaPagoFrac)).toFixed(2));
  const proximaParcela = restam > 0 ? Math.max(0, +(parcela - jaPagoFrac).toFixed(2)) : 0;
  return { emp, jPct, juros, total, parcela, pagasInt, jaPagoFrac, restam, saldoParcelas, proximaParcela };
}

function calcularTotalMultasAbertas(multas) {
  return multas.filter(m => m.status === 'aberto').reduce((a, m) => a + (m.valor || 0), 0);
}

// CORREÇÃO CIRÚRGICA (regra de multa por atraso):
// A multa só pode contar dias de atraso CONSECUTIVOS. Qualquer pagamento
// (mesmo parcial) zera o contador — dias de atraso antes e depois de um
// pagamento NUNCA podem ser somados como uma sequência única.
// Por isso, a contagem nunca começa antes do dia seguinte ao último
// pagamento registrado na venda (quando ele for posterior ao vencimento).
function dataBaseAtraso(dataVenc, ultimoPagamentoData) {
  if (!ultimoPagamentoData) return dataVenc;
  return (ultimoPagamentoData > dataVenc) ? ultimoPagamentoData : dataVenc;
}

async function processarMultasAutomaticas(v) {
  const pagasInt = parseInt(v.parcelasPagas || 0, 10);
  if (pagasInt >= v.numParcelas) return;
  
  const diasParaMulta = Math.max(1, parseInt(v.diasMulta || 2, 10));
  const valorMulta    = parseFloat(v.valorMulta || 0);
  
  if (valorMulta <= 0) return;
  
  // Atraso baseado na PRÓXIMA parcela a vencer
  const parcelaNum = pagasInt + 1;
  const dataVenc  = calcularDataParcela(v.dataInicio, parcelaNum, v.tipoVenc || 'mensal');
  // Zera a contagem a partir do último pagamento, se houver (ver dataBaseAtraso acima).
  const dataBase  = dataBaseAtraso(dataVenc, v.ultimoPagamentoData);
  const atraso    = diasDeAtraso(dataBase);
  
  if (atraso <= 0) return;
  
  // Regra: 1 multa a cada N dias consecutivos de atraso (diasParaMulta, padrão 2).
  const qtdEsperada = Math.floor(atraso / diasParaMulta);
  if (qtdEsperada <= 0) return;
  
  const multasExistentes = await getMultasVenda(v.id);
  // Conta apenas multas automáticas da sequência de atraso ATUAL, ou seja,
  // criadas depois do último pagamento. Multas de uma sequência anterior
  // (já encerrada por um pagamento) não podem bloquear a geração de novas
  // multas da sequência atual.
  const multasAuto = multasExistentes.filter(m => {
    if (m.origem !== 'auto') return false;
    if (v.ultimoPagamentoData && m.criadoEm && m.criadoEm <= v.ultimoPagamentoData) return false;
    return true;
  });
  const qtdJaGeradas = multasAuto.length;
  
  // 1. Multas excedentes: Não remover mais automaticamente para garantir independência.
  if (qtdJaGeradas >= qtdEsperada) return;

  const qtdNova = qtdEsperada - qtdJaGeradas;
  if (qtdNova <= 0) return;
  
  console.log(`[Multas] Venda ${v.id}: atraso=${atraso}d, intervalo=${diasParaMulta}d, esperadas=${qtdEsperada}, já geradas=${qtdJaGeradas}, novas=${qtdNova}`);
  
  for (let i = 0; i < qtdNova; i++) {
    const multaSeq = qtdJaGeradas + i + 1;
    const novaMulta = {
      vendaId: v.id, 
      clienteId: v.clienteId, 
      parcelaRef: parcelaNum, // Referencia a parcela que originou o atraso
      valor: valorMulta,
      motivo: `Multa automática — ${diasParaMulta * multaSeq}º dia de atraso`,
      origem: 'auto', 
      status: 'aberto', 
      criadoEm: hoje(),
    };
    try {
      await salvarMulta(novaMulta);
    } catch (e) {
      console.error(`[Multas] Erro ao salvar multa:`, e);
    }
  }
}

/**
 * Calcula quantos dias faltam para a ÚLTIMA parcela (fim do empréstimo) de uma venda.
 * Retorna null se a venda já está quitada (não faz sentido "faltar dias" para ela).
 * Retorna um número negativo se a data final já passou (empréstimo vencido mas não quitado).
 */
function diasParaTerminarVenda(v) {
  const pagasInt = parseInt(v.parcelasPagas || 0, 10);
  if (pagasInt >= v.numParcelas) return null; // já quitado, não entra no filtro de vencimento
  const dataFinal = calcularDataParcela(v.dataInicio, v.numParcelas, v.tipoVenc || 'mensal');
  if (!dataFinal) return null;
  const parts = dataFinal.split('-');
  const finalMs = Date.UTC(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
  const hj = hoje().split('-');
  const hojeMs = Date.UTC(parseInt(hj[0]), parseInt(hj[1]) - 1, parseInt(hj[2]));
  return Math.round((finalMs - hojeMs) / (24 * 60 * 60 * 1000));
}

/**
 * Retorna o menor número de dias-para-terminar entre as vendas ATIVAS de um cliente
 * (ou seja, a venda cujo empréstimo está mais perto de terminar). Retorna null se
 * o cliente não tiver nenhuma venda ativa (tudo quitado).
 */
function diasParaTerminarCliente(vendas) {
  let menor = null;
  for (const v of (vendas || [])) {
    const d = diasParaTerminarVenda(v);
    if (d === null) continue;
    if (menor === null || d < menor) menor = d;
  }
  return menor;
}

/**
 * Calcula os dias de atraso da PRÓXIMA parcela a vencer de uma venda
 * (mesma base de cálculo usada em statusVenda/processarMultasAutomaticas).
 * Retorna null se a venda já está quitada.
 */
function diasAtrasoVenda(v) {
  const pagasInt = parseInt(v.parcelasPagas || 0, 10);
  if (pagasInt >= v.numParcelas) return null; // já quitada
  const proxNum  = pagasInt + 1;
  const prox     = calcularDataParcela(v.dataInicio, proxNum, v.tipoVenc || 'mensal');
  const dataBase = dataBaseAtraso(prox, v.ultimoPagamentoData);
  return diasDeAtraso(dataBase);
}

/**
 * Retorna o MAIOR número de dias de atraso entre as vendas ATIVAS de um cliente
 * (ou seja, a venda mais atrasada). Retorna null se o cliente não tiver
 * nenhuma venda ativa (tudo quitado).
 */
function diasAtrasoCliente(vendas) {
  let maior = null;
  for (const v of (vendas || [])) {
    const d = diasAtrasoVenda(v);
    if (d === null) continue;
    if (maior === null || d > maior) maior = d;
  }
  return maior;
}

function statusVenda(v) {
  const pagasInt = parseInt(v.parcelasPagas || 0, 10);
  // NOTA: statusVenda é síncrona e NÃO pode verificar multas via API.
  // Para decisões de quitação/renovação use vendaEstaQuitada() (assíncrona).
  if (pagasInt >= v.numParcelas) return 'quitado';
  const proxNum = pagasInt + 1;
  const prox    = calcularDataParcela(v.dataInicio, proxNum, v.tipoVenc || 'mensal');
  
  // Zera a contagem a partir do último pagamento, se houver (ver dataBaseAtraso).
  const dataBase = dataBaseAtraso(prox, v.ultimoPagamentoData);
  const atraso   = diasDeAtraso(dataBase);
  
  if (atraso >= 4) return 'atrasado';   // A partir de 4 dias consecutivos → atrasado
  if (atraso >= 2) return 'pendente';   // A partir de 2 dias consecutivos → pendente
  return 'em-dia';                      // Até 1 dia de atraso → em-dia
}

/**
 * Verificação assíncrona completa de quitação.
 * Uma venda só está QUITADA quando:
 *   parcelas_pendentes == 0 AND multas_pendentes == 0
 * Regra de negócio: NUNCA encerrar venda com multas em aberto.
 */
const STATUS_MULTAS_BLOQUEANTES = ['aberto', 'pendente', 'atrasado'];
async function vendaEstaQuitada(v) {
  const pagasInt = parseInt(v.parcelasPagas || 0, 10);
  if (pagasInt < v.numParcelas) return false;          // parcelas pendentes
  const multas = await getMultasVenda(v.id);
  const multasPendentes = multas.filter(m => STATUS_MULTAS_BLOQUEANTES.includes(m.status));
  return multasPendentes.length === 0;                 // só quitada se sem multas
}

function statusGlobalCliente(vendas) {
  const ativas = (vendas||[]).filter(v => parseInt(v.parcelasPagas||0,10) < v.numParcelas);
  if (!ativas.length) return 'quitado';
  const st = ativas.map(statusVenda);
  if (st.includes('atrasado')) return 'atrasado';
  if (st.includes('pendente')) return 'pendente';
  return 'em-dia';
}

async function totalDevidoCliente(vendas) {
  let total = 0;
  for (const v of vendas) {
    const c      = calcularVenda(v);
    total += c.saldoParcelas;
  }
  return total;
}

/* ═══════════════════════════════════════════════════════════
   GERAR PARCELAS
═══════════════════════════════════════════════════════════ */
async function gerarParcelasVenda(venda) {
  await excluirParcelasPorVenda(venda.id);
  // O total e a parcela já vêm normalizados no cadastro da venda. Não
  // recalcular com casas decimais aqui, pois isso reintroduziria divergências.
  const total    = Number(venda.totalComJuros ?? (venda.valorEmprestimo * (1 + (venda.jurosPct || 0) / 100)));
  const valParc  = Number(venda.valorParcela ?? (venda.numParcelas > 0 ? Math.ceil(total / venda.numParcelas - 1e-8) : 0));
  const pagasInt = parseInt(venda.parcelasPagas || 0, 10);
  const saldoParc = parseFloat(venda.saldoParcialPago || 0);

  // CORREÇÃO P3: verifica pagamentos já existentes para esta venda
  // Parcelas históricas marcadas como 'pago' NÃO devem gerar novo registro em pagamentos.
  // O salvarParcela aqui é apenas estrutura de dívida — o evento financeiro real
  // já existe (ou existiu) em pagamentos. Não chamar salvarPagamento() nesta função.
  let pagamentosExistentes = [];
  try {
    const resPag = await api('pagamentos.listarPorVenda', { vendaId: venda.id });
    pagamentosExistentes = Array.isArray(resPag) ? resPag : [];
  } catch (_) { pagamentosExistentes = []; }

  for (let i = 1; i <= venda.numParcelas; i++) {
    const dataVenc = calcularDataParcela(venda.dataInicio, i, venda.tipoVenc || 'mensal');
    let status = 'futuro', valorPago = null;
    if (i <= pagasInt) { status = 'pago'; valorPago = valParc; }
    else if (i === pagasInt + 1 && saldoParc > 0) { status = 'parcial'; valorPago = saldoParc; }
    else { 
      const dataBase = dataBaseAtraso(dataVenc, venda.ultimoPagamentoData);
      const a = diasDeAtraso(dataBase); 
      status = a >= 4 ? 'atrasado' : a >= 2 ? 'pendente' : 'futuro'; 
    }
    await salvarParcela({
      vendaId: venda.id, clienteId: venda.clienteId, numero: i,
      dataVencimento: dataVenc, valor: valParc, valorPago,
      status, dataPagamento: (status==='pago') ? hoje() : null,
      formaPagamento: null, atualizadoEm: hoje(),
    });
    // NUNCA chamar salvarPagamento() aqui — parcelas históricas já têm
    // registros reais em pagamentos. Criar novos inflaria totalRecebido e baixasQtd.
  }
}

/* ═══════════════════════════════════════════════════════════
   AUTOMAÇÃO DE STATUS
═══════════════════════════════════════════════════════════ */
let autoTimer = null;

async function atualizarStatusAutomatico() {
  try {
    const vendas   = await listarVendas();
    const parcelas = await listarParcelas();
    const hojeStr  = hoje();
    let alteradas  = 0;
    for (const p of parcelas) {
      if (p.status === 'pago') continue;
      const venda = vendas.find(v => v.id === p.vendaId);
      if (!venda) continue;
      const pagasInt = parseInt(venda.parcelasPagas || 0, 10);
      let novoStatus;
      if (p.numero <= pagasInt) {
        // Se a venda diz que está paga mas a parcela não, algo está inconsistente.
        // Mas não podemos forçar 'pago' via salvarParcela mais.
        // Vamos apenas ignorar ou logar.
        continue; 
      }
      else if (p.numero === pagasInt + 1 && parseFloat(venda.saldoParcialPago || 0) > 0) {
        // Idem para parcial
        continue;
      }
      else { 
        const dataBase = dataBaseAtraso(p.dataVencimento, venda.ultimoPagamentoData);
        const a = diasDeAtraso(dataBase); 
        novoStatus = a >= 4 ? 'atrasado' : a >= 2 ? 'pendente' : 'futuro'; 
      }
      if (novoStatus !== p.status) {
        p.status = novoStatus; p.atualizadoEm = hojeStr;
        await salvarParcela(p); alteradas++;
      }
    }
    let multasGeradas = 0;
    for (const v of vendas) {
      const antes = (await getMultasVenda(v.id)).length;
      await processarMultasAutomaticas(v);
      const depois = (await getMultasVenda(v.id)).length;
      if (depois > antes) multasGeradas++;
    }
    if (alteradas > 0 || multasGeradas > 0) { renderPainel(); renderVendas(); }
  } catch(err) { console.error('Erro automação:', err); }
}

function iniciarAutoTimer() {
  if (autoTimer) clearInterval(autoTimer);
  autoTimer = setInterval(atualizarStatusAutomatico, 5 * 60 * 1000);
}

/* ═══════════════════════════════════════════════════════════
   TOAST
═══════════════════════════════════════════════════════════ */
function showToast(msg, tipo = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className   = 'toast ' + tipo + ' show';
  setTimeout(() => t.classList.remove('show'), 2800);
}

/* ═══════════════════════════════════════════════════════════
   SETTINGS (localStorage — preferências visuais)
═══════════════════════════════════════════════════════════ */
const SETTINGS_KEY = 'rcreditos_settings_v1';
let galeriaUnlocked = false;
let pinCallback     = null;

function carregarSettings() {
  try { return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {}; } catch { return {}; }
}
function salvarSettingsLocal(s) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }
function getPin() { return carregarSettings().pinGaleria || null; }

function aplicarSettings(s) {
  const root = document.documentElement;
  if (s.accentColor) {
    root.style.setProperty('--accent', s.accentColor);
    root.style.setProperty('--accent-hover', s.accentHover || s.accentColor);
    root.style.setProperty('--accent-dim', hexToRgba(s.accentColor, 0.13));
  }
  if (s.temaClaro) {
    root.style.setProperty('--bg-base',       '#f3f4f7');
    root.style.setProperty('--bg-surface',    '#ffffff');
    root.style.setProperty('--bg-elevated',   '#eceef2');
    root.style.setProperty('--bg-input',      '#e4e7ed');
    root.style.setProperty('--bg-hover',      '#d8dbe3');
    root.style.setProperty('--border',        '#d8dbe3');
    root.style.setProperty('--border-strong', '#bfc3cc');
    root.style.setProperty('--text-primary',  '#111214');
    root.style.setProperty('--text-secondary','#454b5a');
    root.style.setProperty('--text-muted',    '#9099a8');
  } else {
    root.style.setProperty('--bg-base',       '#0f1117');
    root.style.setProperty('--bg-surface',    '#161920');
    root.style.setProperty('--bg-elevated',   '#1e2128');
    root.style.setProperty('--bg-input',      '#252830');
    root.style.setProperty('--bg-hover',      '#2a2d36');
    root.style.setProperty('--border',        '#272b34');
    root.style.setProperty('--border-strong', '#363b47');
    root.style.setProperty('--text-primary',  '#eef0f3');
    root.style.setProperty('--text-secondary','#8b929e');
    root.style.setProperty('--text-muted',    '#50565f');
  }
  if (s.fontSize) document.documentElement.style.fontSize = s.fontSize + 'px';
}
function hexToRgba(hex, alpha) {
  const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${alpha})`;
}
function sincronizarSettingsUI(s) {
  document.getElementById('temaClaro').checked = !!s.temaClaro;
  if (s.fontSize) document.querySelectorAll('.font-opt').forEach(b => b.classList.toggle('ativa', parseInt(b.dataset.size)===s.fontSize));
  if (s.accentColor) document.querySelectorAll('.cor-opcao').forEach(c => c.classList.toggle('ativa', c.dataset.cor===s.accentColor));
  const pinEl = document.getElementById('pinStatus');
  pinEl.textContent = s.pinGaleria ? ' PIN ativo — galeria protegida' : ' Sem PIN definido';
  pinEl.className   = 'pin-status ' + (s.pinGaleria ? 'on' : 'off');
}

/* ═══════════════════════════════════════════════════════════
   TABS
═══════════════════════════════════════════════════════════ */
let clienteDetalheId = null;

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'clientes')  renderClientes();
    if (btn.dataset.tab === 'vendas')    renderVendas();
    if (btn.dataset.tab === 'historico') renderHistorico();
  });
});

// Helper para mudar de aba programaticamente
function switchTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
  if (btn) btn.classList.add('active');
  const content = document.getElementById('tab-' + tabName);
  if (content) content.classList.add('active');
  if (tabName === 'clientes')  renderClientes();
  if (tabName === 'vendas')    renderVendas();
  if (tabName === 'historico') renderHistorico();
  if (tabName === 'painel')    renderPainel();
}

/* ═══════════════════════════════════════════════════════════
   MODAL HELPERS
═══════════════════════════════════════════════════════════ */
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

/* ═══════════════════════════════════════════════════════════
   LIGHTBOX
═══════════════════════════════════════════════════════════ */
function abrirLightbox(src, caption) {
  document.getElementById('lightboxImg').src = src;
  document.getElementById('lightboxCaption').textContent = caption || '';
  document.getElementById('lightbox').classList.add('open');
}
document.getElementById('lightboxClose').addEventListener('click', () => document.getElementById('lightbox').classList.remove('open'));
document.getElementById('lightbox').addEventListener('click', e => { if (e.target===document.getElementById('lightbox')) document.getElementById('lightbox').classList.remove('open'); });

/* ═══════════════════════════════════════════════════════════
   FOTOS MANAGER
═══════════════════════════════════════════════════════════ */
let fotosEditando = [];
let fotosVenda = [];

function renderFotosGrid() {
  const grid = document.getElementById('fotosGridUpload');
  grid.innerHTML = '';
  fotosEditando.forEach((f, idx) => {
    const cell = document.createElement('div');
    cell.className = 'foto-upload-cell';
    cell.innerHTML = `<img src="${f.data}" alt="foto ${idx+1}"/>
      <div class="foto-cell-overlay">
        <span class="foto-cell-label">${f.label||'Sem rótulo'}</span>
        <button class="foto-cell-del" onclick="removerFotoIdx(${idx})"></button>
      </div>`;
    cell.addEventListener('dblclick', () => {
      const novo = prompt('Rótulo da foto:', f.label||'');
      if (novo !== null) { fotosEditando[idx].label = novo; renderFotosGrid(); }
    });
    grid.appendChild(cell);
  });
  const addCell = document.createElement('div');
  addCell.className = 'foto-upload-cell';
  addCell.style.border = '2px dashed var(--border-strong)';
  addCell.innerHTML = `<div class="foto-upload-placeholder"><br>+ Foto
    <input type="file" id="novaFotoInput" accept="image/*"/></div>`;
  addCell.querySelector('input').addEventListener('change', e => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { fotosEditando.push({ data: ev.target.result, label: '' }); renderFotosGrid(); };
    reader.readAsDataURL(file);
  });
  grid.appendChild(addCell);
}

window.removerFotoIdx = idx => { fotosEditando.splice(idx, 1); renderFotosGrid(); };
document.getElementById('btnAddFoto').addEventListener('click', () => { const i=document.querySelector('#novaFotoInput'); if(i)i.click(); });

/* ── Grid de fotos da VENDA ── */
function renderFotosGridVenda() {
  const grid = document.getElementById('fotosGridUploadVenda');
  if (!grid) return;
  grid.innerHTML = '';
  fotosVenda.forEach((f, idx) => {
    const cell = document.createElement('div');
    cell.className = 'foto-upload-cell';
    cell.innerHTML = `<img src="${f.data}" alt="foto ${idx+1}"/>
      <div class="foto-cell-overlay">
        <span class="foto-cell-label">${f.label||'Sem rótulo'}</span>
        <button class="foto-cell-del" onclick="removerFotoVendaIdx(${idx})"></button>
      </div>`;
    cell.addEventListener('dblclick', () => {
      const novo = prompt('Rótulo da foto:', f.label||'');
      if (novo !== null) { fotosVenda[idx].label = novo; renderFotosGridVenda(); }
    });
    grid.appendChild(cell);
  });
  const addCell = document.createElement('div');
  addCell.className = 'foto-upload-cell';
  addCell.style.border = '2px dashed var(--border-strong)';
  addCell.innerHTML = `<div class="foto-upload-placeholder"><br>+ Foto
    <input type="file" id="novaFotoVendaInput" accept="image/*"/></div>`;
  addCell.querySelector('input').addEventListener('change', e => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { fotosVenda.push({ data: ev.target.result, label: '' }); renderFotosGridVenda(); };
    reader.readAsDataURL(file);
  });
  grid.appendChild(addCell);
}
window.removerFotoVendaIdx = idx => { fotosVenda.splice(idx, 1); renderFotosGridVenda(); };
document.getElementById('btnAddFotoVenda').addEventListener('click', () => { const i=document.querySelector('#novaFotoVendaInput'); if(i)i.click(); });

/* ═══════════════════════════════════════════════════════════
   PIN DE GALERIA
═══════════════════════════════════════════════════════════ */
function verificarAcessoGaleria(cb) {
  const pin = getPin();
  if (!pin || galeriaUnlocked) { cb(); return; }
  pinCallback = cb;
  document.getElementById('pinInput').value = '';
  document.getElementById('pinErro').classList.remove('show');
  openModal('modalPin');
}
document.getElementById('closeModalPin').addEventListener('click', () => closeModal('modalPin'));
document.getElementById('cancelarPin').addEventListener('click',   () => closeModal('modalPin'));
document.getElementById('confirmarPin').addEventListener('click', () => {
  const pin = getPin();
  const val = document.getElementById('pinInput').value;
  if (val === String(pin)) {
    galeriaUnlocked = true; closeModal('modalPin');
    if (pinCallback) { pinCallback(); pinCallback = null; }
  } else { document.getElementById('pinErro').classList.add('show'); }
});

/* ═══════════════════════════════════════════════════════════
   TIPO DE ENDEREÇO
═══════════════════════════════════════════════════════════ */
function atualizarCamposEndereco() {
  const tipo = document.getElementById('clienteTipoEndereco').value;
  document.getElementById('grpEnderecoRes').style.display = (tipo==='residencial'||tipo==='ambos') ? '' : 'none';
  document.getElementById('grpEnderecoCom').style.display = (tipo==='comercial'  ||tipo==='ambos') ? '' : 'none';
}
document.getElementById('clienteTipoEndereco').addEventListener('change', atualizarCamposEndereco);

/* ═══════════════════════════════════════════════════════════
   TIPO DE FILTRO DO PAINEL (Atraso/Multa, Valor, Vencimento)
═══════════════════════════════════════════════════════════ */
function onFiltroTipoPainelChange() {
  const tipo = document.getElementById('filtroTipoPainel')?.value || '';
  document.getElementById('wrapAtrasoPainel').style.display      = (tipo === 'atraso')     ? '' : 'none';
  document.getElementById('wrapValorPainel').style.display       = (tipo === 'valor')      ? '' : 'none';
  document.getElementById('wrapVencimentoPainel').style.display  = (tipo === 'vencimento') ? '' : 'none';
  renderPainelComFiltro();
}

/* ═══════════════════════════════════════════════════════════
   RENDER PAINEL COM FILTRO
═══════════════════════════════════════════════════════════ */
let filtroRenderSeq = 0;

async function renderPainelComFiltro() {
  const renderSeq = ++filtroRenderSeq;
  const filtro = document.getElementById('filtroPainel')?.value || 'todos';
  const tipoFiltro = document.getElementById('filtroTipoPainel')?.value || '';
  const lista = document.getElementById('listaPainelUnificada');
  
  // ── Busca única de todos os dados necessários ──
  const [clientes, allVendas, allMultas, allPagamentos] = await Promise.all([
    listarClientes(),
    listarVendas(),
    listarMultas(),
    listarPagamentos(),
  ]);

  // Agrupamentos em memória
  const vendasPorCliente = new Map();
  for (const v of allVendas) {
    if (!vendasPorCliente.has(v.clienteId)) vendasPorCliente.set(v.clienteId, []);
    vendasPorCliente.get(v.clienteId).push(v);
  }

  // Regra operacional das baixas:
  // - tipo "pagamento" = baixa efetiva e entra em "Pagaram Hoje";
  // - tipo "nao-pagou" = registro de cobrança sem pagamento, mas também
  //   conta como baixa para que o cliente não apareça em "Sem Baixa";
  // - multas e outros eventos não são baixas de parcela e não entram em
  //   nenhum dos dois filtros.
  const clientesPagaramHoje = new Set();
  const clientesComBaixaHoje = new Set();
  const dataHoje = hoje();
  for (const p of allPagamentos) {
    const dataPag = (p.dataPagamento || p.data || '').slice(0, 10);
    if (dataPag !== dataHoje) continue;

    const ehPagamento = p.tipo === 'pagamento';
    const ehNaoPagou = p.tipo === 'nao-pagou';
    if (ehPagamento || ehNaoPagou) clientesComBaixaHoje.add(p.clienteId);
    if (ehPagamento) clientesPagaramHoje.add(p.clienteId);
  }

  // Cálculo de divida
  const calcularDividaCliente = (vendas) => {
    let total = 0;
    for (const v of vendas) {
      const c = calcularVenda(v);
      total += c.saldoParcelas;
    }
    return total;
  };

  // Monta lista completa com dados de cada cliente
  let listaCompleta = [];
  for (const c of clientes) {
    const vendas = vendasPorCliente.get(c.id) || [];
    const status = statusGlobalCliente(vendas);
    const divida = calcularDividaCliente(vendas);
    const pagaramHoje = clientesPagaramHoje.has(c.id);
    const semBaixa = !clientesComBaixaHoje.has(c.id);
    const diasParaTerminar = diasParaTerminarCliente(vendas);
    const diasAtraso = diasAtrasoCliente(vendas);
    listaCompleta.push({ cliente: c, vendas, divida, status, pagaramHoje, semBaixa, diasParaTerminar, diasAtraso });
  }

  // A Dashboard exibe somente clientes com contratos ativos (em-dia, pendente ou atrasado).
  // Clientes "quitado" não aparecem aqui — só na tela de Clientes.
  listaCompleta = listaCompleta.filter(x => x.status !== 'quitado');

  // Aplica filtro (independente do status de dívida)
  let listaFiltrada = listaCompleta;
  if (filtro === 'pagaram-hoje') {
    // Mostra TODOS os clientes que tiveram pagamento registrado hoje
    listaFiltrada = listaCompleta.filter(x => x.pagaramHoje);
  } else if (filtro === 'nao-pagaram-hoje') {
    // Mostra clientes SEM NENHUMA baixa registrada hoje (nem pagamento, nem "não pagou")
    listaFiltrada = listaCompleta.filter(x => x.semBaixa);
  } else if (filtro === 'pendentes') {
    listaFiltrada = listaCompleta.filter(x => x.status === 'pendente');
  } else if (filtro === 'atrasados') {
    listaFiltrada = listaCompleta.filter(x => x.status === 'atrasado');
  }
  // 'todos' mantém listaFiltrada = listaCompleta

  // Filtro extra: vencendo em até X dias (usa a menor data final entre as vendas ativas do cliente)
  const diasLimiteStr = document.getElementById('diasVencimentoPainel')?.value;
  if (tipoFiltro === 'vencimento' && diasLimiteStr !== '' && diasLimiteStr !== undefined && diasLimiteStr !== null) {
    const diasLimite = parseInt(diasLimiteStr, 10);
    if (!isNaN(diasLimite)) {
      listaFiltrada = listaFiltrada.filter(x => x.diasParaTerminar !== null && x.diasParaTerminar <= diasLimite);
      listaFiltrada.sort((a, b) => a.diasParaTerminar - b.diasParaTerminar);
    }
  }

  // Filtro extra: dias de atraso (mínimo)
  const diasAtrasoMinStr = document.getElementById('diasAtrasoPainel')?.value;
  if (tipoFiltro === 'atraso' && diasAtrasoMinStr !== '' && diasAtrasoMinStr !== undefined && diasAtrasoMinStr !== null) {
    const diasAtrasoMin = parseInt(diasAtrasoMinStr, 10);
    if (!isNaN(diasAtrasoMin)) {
      listaFiltrada = listaFiltrada.filter(x => x.diasAtraso !== null && x.diasAtraso >= diasAtrasoMin);
      listaFiltrada.sort((a, b) => (b.diasAtraso||0) - (a.diasAtraso||0));
    }
  }

  // Filtro extra: valor do empréstimo (mostra clientes que tenham alguma venda com esse valor exato)
  const valorFiltroStr = document.getElementById('filtroValorPainel')?.value;
  if (tipoFiltro === 'valor' && valorFiltroStr !== '' && valorFiltroStr !== undefined && valorFiltroStr !== null) {
    const valorFiltro = parseFloat(valorFiltroStr);
    if (!isNaN(valorFiltro)) {
      listaFiltrada = listaFiltrada.filter(x => x.vendas.some(v => Math.abs(parseFloat(v.valorEmprestimo || 0) - valorFiltro) < 0.01));
    }
  }

  if (renderSeq !== filtroRenderSeq) return;

  // Renderiza lista
  lista.innerHTML = '';
  if (!listaFiltrada.length) {
    lista.innerHTML = '<p class="empty-msg">Nenhum cliente encontrado.</p>';
    return;
  }

  const labelMap = {'em-dia':'Em Dia','pendente':'Pendente','atrasado':'Atrasado'};
  const badgeMap = {'em-dia':'badge-em-dia','pendente':'badge-pendente','atrasado':'badge-atrasado'};

  const diasFiltroAtivo = tipoFiltro === 'vencimento' && (diasLimiteStr !== '' && diasLimiteStr !== undefined && diasLimiteStr !== null && !isNaN(parseInt(diasLimiteStr, 10)));
  const atrasoFiltroAtivo = tipoFiltro === 'atraso' && (diasAtrasoMinStr !== '' && diasAtrasoMinStr !== undefined && diasAtrasoMinStr !== null && !isNaN(parseInt(diasAtrasoMinStr, 10)));

  listaFiltrada.forEach(({ cliente: c, divida, status, diasParaTerminar, diasAtraso }) => {
    const card = document.createElement('div');
    card.className = `cliente-card status-${status}`;
    let vencBadge = '';
    if (diasFiltroAtivo && diasParaTerminar !== null) {
      vencBadge = diasParaTerminar < 0
        ? `<span style="font-size:10px;font-weight:700;color:var(--red)">Venceu há ${Math.abs(diasParaTerminar)}d</span>`
        : diasParaTerminar === 0
          ? `<span style="font-size:10px;font-weight:700;color:var(--red)">Termina hoje</span>`
          : `<span style="font-size:10px;font-weight:700;color:var(--orange)">Termina em ${diasParaTerminar}d</span>`;
    }
    let atrasoBadge = '';
    if (atrasoFiltroAtivo && diasAtraso !== null && diasAtraso > 0) {
      atrasoBadge = `<span style="font-size:10px;font-weight:700;color:var(--red)">${diasAtraso}d de atraso</span>`;
    }
    card.innerHTML = `
      <div class="cliente-avatar">${(c.nomeComercial||c.nome||'?').charAt(0).toUpperCase()}</div>
      <div class="cliente-info">
        <div class="cliente-nome">${c.nomeComercial||c.nome}</div>
        <div class="cliente-sub">${c.nomeComercial?c.nome+' · ':''}${c.celular?`<a href="#" onclick="event.stopPropagation();abrirWhatsApp('${c.celular}','${(c.nomeComercial||c.nome||'').replace(/'/g,"\\'")}');return false;" style="color:#25d366;text-decoration:none;" title="Cobrar via WhatsApp"> ${c.celular}</a>`:'—'}</div>
      </div>
      <div class="cliente-meta">
        <div class="cliente-divida" style="color:var(--red)">${fmt(divida)}</div>
        <span class="cliente-badge ${badgeMap[status]}">${labelMap[status]}</span>
        ${vencBadge}
        ${atrasoBadge}
      </div>`;
    card.addEventListener('click', () => abrirDetalheCliente(c.id));
    lista.appendChild(card);
  });

  // Atualiza contadores de status
  const emDia = listaCompleta.filter(x => x.status === 'em-dia').length;
  const pendente = listaCompleta.filter(x => x.status === 'pendente').length;
  const atrasado = listaCompleta.filter(x => x.status === 'atrasado').length;

  document.getElementById('totalEmDia').textContent = emDia;
  document.getElementById('totalPendente').textContent = pendente;
  document.getElementById('totalAtrasado').textContent = atrasado;
}

/* ═══════════════════════════════════════════════════════════
   RENDER PAINEL (compatibilidade)
═══════════════════════════════════════════════════════════ */
async function renderPainel() {
  await atualizarStatusFechamento();
  await renderPainelComFiltro();
}

/* ═══════════════════════════════════════════════════════════
   FECHAMENTO E CÓPIA DE PARCELAS
═══════════════════════════════════════════════════════════ */
async function atualizarStatusFechamento() {
  const res = await api('fechamento.status');
  const el = document.getElementById('statusFechamentoHeader');
  if (!el) return;
  const isClosed = res && res.fechado;  // api() já retorna json.dados diretamente
  if (isClosed) {
    el.innerHTML = '<span class="status-fechado-tag">Rota fechada</span>';
    const btnNovo = document.getElementById('btnNovoCliente');
    if (btnNovo) btnNovo.disabled = true;
  } else {
    el.innerHTML = '<button class="btn-fechar-rota" onclick="abrirFechamentoRuta()">Fechar rota</button>';
    const btnNovo = document.getElementById('btnNovoCliente');
    if (btnNovo) btnNovo.disabled = false;
  }
  return isClosed;
}

// Menu Opções
document.getElementById('btnMenuOpcoes').addEventListener('click', (e) => {
  e.stopPropagation();
  document.getElementById('menuOpcoes').classList.toggle('show');
});
window.addEventListener('click', () => {
  document.getElementById('menuOpcoes').classList.remove('show');
});

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

async function carregarResumoDiario(dataRef) {
  const params = dataRef ? { data: dataRef } : {};
  const d = await api('route.resumo', params);
  if (!d) return;

  setText('res_clientesInicio',    d.clientesInicio    ?? 0);
  setText('res_clientesNovos',     d.clientesNovos     ?? 0);
  setText('res_clientesRenovacao', d.clientesRenovacao ?? 0);
  setText('res_clientesCobrados',  d.clientesCobrados  ?? 0);
  setText('res_baixasQtd',         d.baixasQtd         ?? 0);
  setText('res_clientesPendentes', d.clientesPendentes ?? 0);
  setText('res_valorInvestidoDia',  fmt(d.valorInvestidoDia  ?? 0));
  // Indicadores independentes: o esperado nunca é reduzido por pagamentos.
  setText('res_valorEsperado',      fmt(d.valorEsperado      ?? d.totalEsperadoFixo ?? 0));
  setText('res_valorRecebido',      fmt(d.valorRecebido      ?? d.totalRecebidoParcelas ?? 0));
  setText('res_valorEmAberto',      fmt(d.valorEmAberto      ?? d.totalEmAberto ?? 0));
  setText('res_jurosRecebidosHoje', fmt(d.jurosRecebidosHoje ?? 0));
  setText('res_vendasQtd',        d.vendasQtd        ?? 0);
  setText('res_vendasValor',      fmt(d.vendasValor      ?? 0));
  setText('res_vendasNovasQtd',   d.vendasNovasQtd   ?? 0);
  setText('res_vendasNovasValor', fmt(d.vendasNovasValor ?? 0));
  setText('res_vendasRenovQtd',   d.vendasRenovQtd   ?? 0);
  setText('res_vendasRenovValor', fmt(d.vendasRenovValor ?? 0));
  setText('res_entradasHoje',  fmt(d.entradasHoje  ?? 0));
  setText('res_retiradasHoje', fmt(d.retiradasHoje ?? 0));
  setText('res_despesasHoje',  fmt(d.despesasHoje  ?? 0));
  setText('res_ajustesHoje',   fmt(d.ajustesHoje   ?? 0));
  setText('res_saldoFinal', fmt(d.saldoFinal ?? 0));
}

async function carregarResumoGeral() {
  const d = await api('route.resumo', {});
  if (!d) return;

  setText('res_saldoGeral',             fmt(d.saldoGeral             ?? 0));
  setText('res_saldoFinalRuta',         fmt(d.caixa                  ?? 0));
  setText('res_totalEmprestado',        fmt(d.totalEmprestado        ?? 0));
  setText('res_emprestadoAtualmente',   fmt(d.emprestadoAtualmente   ?? 0));
  setText('res_totalAReceber',          fmt(d.totalAReceber          ?? 0));
  setText('res_totalJuros',             fmt(d.totalJuros             ?? 0));
  setText('res_totalAportes',           fmt(d.totalAportes           ?? 0));
  setText('res_totalRetiradas',         fmt(d.totalRetiradas         ?? 0));
  setText('res_totalParcelasRecebidas', fmt(d.totalParcelasRecebidas ?? 0));
}

async function abrirResumoDiario() {
  const inputData = document.getElementById('resumo_data');
  if (inputData && !inputData.value) inputData.value = hoje();
  await carregarResumoDiario(inputData ? inputData.value : null);
  openModal('modalResumoDiario');
}

async function abrirResumoGeral() {
  await carregarResumoGeral();
  openModal('modalResumoGeral');
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btnRecarregarResumo');
  if (btn) {
    btn.addEventListener('click', async () => {
      const dt = document.getElementById('resumo_data').value || hoje();
      await carregarResumoDiario(dt);
      showToast('Resumo recarregado para ' + dt.split('-').reverse().join('/'));
    });
  }
});

function abrirEventosRuta() {
  document.getElementById('ev_valor').value = '';
  document.getElementById('ev_descricao').value = '';
  openModal('modalEventosRuta');
}

document.getElementById('btnSalvarEvento').addEventListener('click', async () => {
  const dados = {
    tipo: document.getElementById('ev_tipo').value,
    valor: parseFloat(document.getElementById('ev_valor').value),
    descricao: document.getElementById('ev_descricao').value,
    data_evento: hoje()
  };
  if (!dados.valor || dados.valor <= 0) { showToast('Informe um valor válido', 'error'); return; }
  await api('route.eventos.salvar', { dados });
  showToast('Evento registrado!');
  closeModal('modalEventosRuta');
});

function abrirFechamentoRuta() {
  document.getElementById('fechamentoPin').value = '';
  document.getElementById('fechamentoErro').classList.remove('show');
  openModal('modalFechamentoRuta');
}

document.getElementById('btnConfirmarFechamento').addEventListener('click', async () => {
  const pin = document.getElementById('fechamentoPin').value;
  const res = await api('fechamento.executar', { pin });
  if (res) {
    showToast('Ruta fechada com sucesso!');
    closeModal('modalFechamentoRuta');
    renderPainel();
  } else {
    document.getElementById('fechamentoErro').classList.add('show');
  }
});

function copyToClipboard(text) {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text);
  } else {
    let textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.left = "-999999px";
    textArea.style.top = "-999999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    return new Promise((res, rej) => {
      document.execCommand('copy') ? res() : rej();
      textArea.remove();
    });
  }
}
async function copiarParcelasVenda(vendaId) {
  const v = (await listarVendas()).find(x => x.id === vendaId);
  if (!v) return;
  const parcelas = await getParcelas(vendaId);
  const hojeStr = hoje();
  
  // Filtra parcelas: vencidas (atrasadas) ou pendentes até hoje
  const pendentes = parcelas.filter(p => {
    return p.status !== 'pago' && p.dataVencimento <= hojeStr;
  });

  if (pendentes.length === 0) {
    showToast('Nenhuma parcela pendente até hoje.', 'info');
    return;
  }

  let texto = `📒 *Parcelas Pendentes - Venda #${v.id}*\n`;
  pendentes.forEach(p => {
    const atraso = diasDeAtraso(p.dataVencimento);
    texto += `- Parcela ${p.numero}: ${fmt(p.valor)} (Venc: ${fmtData(p.dataVencimento)}${atraso > 0 ? ` · ${atraso}d atraso` : ''})\n`;
  });
  texto += `\n*Total Pendente:* ${fmt(pendentes.reduce((a, b) => a + b.valor, 0))}`;

  copyToClipboard(texto).then(() => {
    showToast('Parcelas copiadas para a área de transferência!');
  });
}

function abrirWhatsApp(celular, nome) {
  if (!celular) return;
  const num = celular.replace(/\D/g, '');
  const tel = num.length === 10 ? '55' + num : num.length === 11 ? '55' + num : num;
  const msg = encodeURIComponent('Boa, estou a caminho. Manda a parcela, preciso do valor');
  window.open('https://wa.me/' + tel + '?text=' + msg, '_blank');
}

async function copiarParcelasCliente(clienteId) {
  // Carrega tudo de uma vez: uma venda-lista e uma parcela-lista, reutilizadas em memória
  const [vendas, todasParcelas] = await Promise.all([
    getVendasDoCliente(clienteId),
    listarParcelas(),
  ]);
  const hojeStr = hoje();
  const vendaIds = new Set(vendas.map(v => v.id));

  const todasPendentes = todasParcelas.filter(p =>
    vendaIds.has(p.vendaId) && p.status !== 'pago' && p.dataVencimento <= hojeStr
  );

  if (todasPendentes.length === 0) {
    showToast('Nenhuma parcela pendente até hoje.', 'info');
    return;
  }

  const cliente = await getCliente(clienteId);
  let texto = `📒 *Resumo de Parcelas - ${cliente.nome}*\n`;
  todasPendentes.forEach(p => {
    const atraso = diasDeAtraso(p.dataVencimento);
    texto += `- Venda #${p.vendaId} | Parc ${p.numero}: ${fmt(p.valor)} (${fmtData(p.dataVencimento)}${atraso > 0 ? ` · ${atraso}d atraso` : ''})\n`;
  });
  texto += `\n*Total Geral Pendente:* ${fmt(todasPendentes.reduce((a, b) => a + b.valor, 0))}`;

  copyToClipboard(texto).then(() => {
    showToast('Resumo do cliente copiado!');
  });
}

/* ═══════════════════════════════════════════════════════════
   RENDER CLIENTES
═══════════════════════════════════════════════════════════ */
let clientesRenderSeq = 0;

async function renderClientesComOrdenacao(filtro='') {
  const renderSeq = ++clientesRenderSeq;
  const lista  = document.getElementById('listaClientes');
  const ordenacao = document.getElementById('ordenacaoClientes')?.value || 'padrao';
  
  let clientes = await listarClientes();
  if (filtro.trim()) {
    const f = filtro.trim().toLocaleLowerCase('pt-BR');
    clientes = clientes.filter(c => {
      const campos = [c.nomeComercial, c.nome, c.celular, c.idNumerico];
      return campos.some(valor => String(valor || '').toLocaleLowerCase('pt-BR').includes(f));
    });
  }
  
  if (renderSeq !== clientesRenderSeq) return;
  lista.innerHTML = '';
  if (!clientes.length) { lista.innerHTML = '<p class="empty-msg">Nenhum cliente.</p>'; return; }
  
  const allVendas = await listarVendas();
  
  let listaCompleta = [];
  for (const c of clientes) {
    const vendas = allVendas.filter(v => v.clienteId === c.id);
    const status = statusGlobalCliente(vendas);
    const divida = await totalDevidoCliente(vendas);
    const diasParaTerminar = diasParaTerminarCliente(vendas);
    const diasAtraso = diasAtrasoCliente(vendas);
    listaCompleta.push({ cliente: c, vendas, divida, status, diasParaTerminar, diasAtraso });
  }
  
  const filtroVencimento = document.getElementById('filtroVencimentoClientes')?.value || 'todos';
  if (filtroVencimento === 'vencendo') {
    const diasLimite = parseInt(document.getElementById('diasVencimentoInput')?.value, 10);
    const limite = isNaN(diasLimite) ? 10 : diasLimite;
    listaCompleta = listaCompleta.filter(item => item.diasParaTerminar !== null && item.diasParaTerminar <= limite);

    const diasAtrasoMinStr = document.getElementById('diasAtrasoInputClientes')?.value;
    if (diasAtrasoMinStr !== '' && diasAtrasoMinStr !== undefined && diasAtrasoMinStr !== null) {
      const diasAtrasoMin = parseInt(diasAtrasoMinStr, 10);
      if (!isNaN(diasAtrasoMin)) {
        listaCompleta = listaCompleta.filter(item => item.diasAtraso !== null && item.diasAtraso >= diasAtrasoMin);
      }
    }

    listaCompleta.sort((a, b) => a.diasParaTerminar - b.diasParaTerminar);
  }
  
  if (ordenacao === 'alfabetica') {
    listaCompleta.sort((a, b) => (a.cliente.nomeComercial||a.cliente.nome).localeCompare(b.cliente.nomeComercial||b.cliente.nome));
  } else if (ordenacao === 'venda') {
    const getUltimaVendaTimestamp = (vendas) => {
      if (!vendas || vendas.length === 0) return 0;
      return Math.max(...vendas.map(v => {
        const data = v.criadoEm ?? v.criado_em ?? v.dataInicio ?? '';
        const timestamp = Date.parse(data);
        return Number.isFinite(timestamp) ? timestamp : 0;
      }));
    };
    listaCompleta.sort((a, b) => getUltimaVendaTimestamp(b.vendas) - getUltimaVendaTimestamp(a.vendas));
  }
  
  const badgeMap = {'em-dia':'badge-em-dia','pendente':'badge-pendente','atrasado':'badge-atrasado'};
  const labelMap = {'em-dia':'Em Dia','pendente':'Pendente','atrasado':'Atrasado'};
  
  if (renderSeq !== clientesRenderSeq) return;
  for (const { cliente: c, status, divida, diasParaTerminar, diasAtraso } of listaCompleta) {
    const card = document.createElement('div');
    card.className = `cliente-card status-${status}`;
    let vencBadge = '';
    if (filtroVencimento === 'vencendo' && diasParaTerminar !== null) {
      vencBadge = diasParaTerminar < 0
        ? `<span style="font-size:10px;font-weight:700;color:var(--red)">Venceu há ${Math.abs(diasParaTerminar)}d</span>`
        : diasParaTerminar === 0
          ? `<span style="font-size:10px;font-weight:700;color:var(--red)">Termina hoje</span>`
          : `<span style="font-size:10px;font-weight:700;color:var(--orange)">Termina em ${diasParaTerminar}d</span>`;
    }
    let atrasoBadge = '';
    if (filtroVencimento === 'vencendo' && diasAtraso !== null && diasAtraso > 0) {
      atrasoBadge = `<span style="font-size:10px;font-weight:700;color:var(--red)">${diasAtraso}d de atraso</span>`;
    }
    card.innerHTML = `
      <div class="cliente-avatar">${(c.nomeComercial||c.nome||'?').charAt(0).toUpperCase()}</div>
      <div class="cliente-info">
        <div class="cliente-nome">${c.idNumerico?`[${c.idNumerico}] `:''}${c.nomeComercial || c.nome}</div>
        <div class="cliente-sub">${c.nomeComercial ? c.nome + ' · ' : ''}${c.celular ? `<a href="#" onclick="event.stopPropagation();abrirWhatsApp('${c.celular}','${(c.nomeComercial||c.nome||'').replace(/'/g,"\\'")}');return false;" style="color:#25d366;text-decoration:none;" title="Cobrar via WhatsApp"> ${c.celular}</a>` : '—'}</div>
      </div>
      <div class="cliente-meta">
        <div class="cliente-divida" style="color:var(--red)">${fmt(divida)}</div>
        <span class="cliente-badge ${badgeMap[status]}">${labelMap[status]}</span>
        ${vencBadge}
        ${atrasoBadge}
      </div>`;
    card.addEventListener('click', () => abrirDetalheCliente(c.id));
    lista.appendChild(card);
  }
}

async function renderClientes(filtro='') {
  await renderClientesComOrdenacao(filtro);
}
document.getElementById('searchCliente').addEventListener('input', e => renderClientes(e.target.value));

function onFiltroVencimentoChange() {
  const valor = document.getElementById('filtroVencimentoClientes')?.value;
  const wrap  = document.getElementById('wrapDiasVencimento');
  if (wrap) wrap.style.display = (valor === 'vencendo') ? 'block' : 'none';
  renderClientesComOrdenacao(document.getElementById('searchCliente')?.value || '');
}

/* ═══════════════════════════════════════════════════════════
   RENDER VENDAS
═══════════════════════════════════════════════════════════ */
let vendasRenderSeq = 0;

async function renderVendas(filtro='') {
  const renderSeq = ++vendasRenderSeq;
  const lista  = document.getElementById('listaVendas');
  // Busca vendas e clientes uma única vez; o mapa de clientes é reutilizado
  // por todos os cards, eliminando um getCliente() por venda dentro do loop.
  const [allVendas, clientes] = await Promise.all([listarVendas(), listarClientes()]);
  const clientesMap = new Map(clientes.map(c => [c.id, c]));
  let vendas = allVendas;
  if (filtro.trim()) {
    const f = filtro.trim().toLocaleLowerCase('pt-BR');
    const cIds = clientes.filter(c => [c.nomeComercial, c.nome, c.celular, c.idNumerico]
      .some(valor => String(valor || '').toLocaleLowerCase('pt-BR').includes(f)))
      .map(c => c.id);
    vendas = vendas.filter(v => cIds.includes(v.clienteId));
  }
  const valorFiltroStr = document.getElementById('filtroValorVenda')?.value;
  if (valorFiltroStr !== '' && valorFiltroStr !== undefined && valorFiltroStr !== null) {
    const valorFiltro = parseFloat(valorFiltroStr);
    if (!isNaN(valorFiltro)) {
      vendas = vendas.filter(v => Math.abs(parseFloat(v.valorEmprestimo || 0) - valorFiltro) < 0.01);
    }
  }
  if (renderSeq !== vendasRenderSeq) return;
  lista.innerHTML = '';
  if (!vendas.length) { lista.innerHTML = '<p class="empty-msg">Nenhuma venda.</p>'; return; }
  for (const v of vendas) {
    if (renderSeq !== vendasRenderSeq) return;
    const card = await criarCardVenda(v, false, clientesMap);
    if (renderSeq !== vendasRenderSeq) return;
    lista.appendChild(card);
  }
}
document.getElementById('searchVenda').addEventListener('input', e => renderVendas(e.target.value));
document.getElementById('filtroValorVenda').addEventListener('input', () => renderVendas(document.getElementById('searchVenda')?.value || ''));

/* ═══════════════════════════════════════════════════════════
   RENDER HISTÓRICO
═══════════════════════════════════════════════════════════ */
let historicoRenderSeq = 0;

async function renderHistorico(filtro='') {
  const renderSeq = ++historicoRenderSeq;
  const lista      = document.getElementById('listaHistorico');
  const pagamentos = await listarPagamentos();
  const multas     = await listarMultas();
  const clientes   = await listarClientes();
  const getClienteNome = cid => { const c=clientes.find(c=>c.id===cid); return c?(c.nomeComercial||c.nome):'Cliente'; };

  // Histórico completo: nenhum registro é descartado ou apagado aqui,
  // apenas filtrado na exibição por texto e/ou por dia da movimentação.
  let eventos = [
    ...pagamentos.map(p => ({ ...p, _tipo: p.tipo||'pagamento', _data: p.dataPagamento||p.data||'', _clienteNome: getClienteNome(p.clienteId) })),
    ...multas.filter(m => m.status!=='aberto').map(m => ({ ...m, _tipo: m.status==='convertido'?'multa-convertida':'multa-pago', _data: m.pagoEm||m.criadoEm||'', _clienteNome: getClienteNome(m.clienteId) })),
  ];

  if (filtro.trim()) {
    const f = filtro.trim().toLocaleLowerCase('pt-BR');
    eventos = eventos.filter(e => e._clienteNome.toLocaleLowerCase('pt-BR').includes(f));
  }

  const dataFiltro = document.getElementById('searchHistoricoData')?.value || '';
  if (dataFiltro) {
    eventos = eventos.filter(e => (e._data || '').slice(0, 10) === dataFiltro);
  }

  eventos.sort((a,b) => (b._data || '').localeCompare(a._data || ''));

  if (renderSeq !== historicoRenderSeq) return;
  lista.innerHTML = '';
  if (!eventos.length) { lista.innerHTML = '<p class="empty-msg">Nenhum histórico.</p>'; return; }
  eventos.forEach(e => {
    const item = document.createElement('div');
    item.className = 'hist-item';
    let tipoLabel, tipoClass, valorStr, valorClass;
    switch(e._tipo) {
      case 'pagamento':        tipoLabel=' Pagamento';      tipoClass='tipo-pagamento';    valorStr='+'+fmt(e.valorPago);                       valorClass='var(--green)';  break;
      case 'nao-pagou':        tipoLabel='Não pagou';      tipoClass='tipo-nao-pagou';    valorStr='—';                                          valorClass='var(--red)';  break;
      case 'multa':            tipoLabel='Multa lançada';   tipoClass='tipo-multa';        valorStr=fmt(e.valorPago?Math.abs(e.valorPago):e.valor||0); valorClass='var(--red)'; break;
      case 'multa-pago':       tipoLabel=' Multa paga';     tipoClass='tipo-multa-pag';    valorStr=fmt(e.valor||0);                            valorClass='var(--orange)'; break;
      case 'multa-convertida': tipoLabel=' Multa → Parcela';tipoClass='tipo-parcela-multa';valorStr=fmt(e.valor||0);                            valorClass='var(--purple)'; break;
      default:                 tipoLabel=' Evento';         tipoClass='';                  valorStr=fmt(e.valorPago||0);                        valorClass='var(--text-primary)';
    }
    item.innerHTML = `
      <div class="hist-info">
        <div class="hist-tipo ${tipoClass}">${tipoLabel}</div>
        <div class="hist-cliente">${e._clienteNome}</div>
        <div class="hist-sub">${e.motivo||(e.quantidadeParcelas?`${e.quantidadeParcelas} parcela(s)`:'')}${e.formaPagamento?' · '+e.formaPagamento:''}</div>
      </div>
      <div class="hist-valor">
        <div class="hist-valor-num" style="color:${valorClass}">${valorStr}</div>
        <div class="hist-data">${fmtData(e._data)}</div>
      </div>`;
    lista.appendChild(item);
  });
}
document.getElementById('searchHistorico').addEventListener('input', e => renderHistorico(e.target.value));
document.getElementById('searchHistoricoData').addEventListener('change', () => {
  renderHistorico(document.getElementById('searchHistorico').value);
});
document.getElementById('btnLimparDataHistorico').addEventListener('click', () => {
  document.getElementById('searchHistoricoData').value = '';
  renderHistorico(document.getElementById('searchHistorico').value);
});

/* ═══════════════════════════════════════════════════════════
   CARD VENDA
═══════════════════════════════════════════════════════════ */
async function criarCardVenda(v, noDetalhe=false, clientesMap=null) {
  const c        = calcularVenda(v);
  const multas   = await getMultasVenda(v.id);
  const multAb   = calcularTotalMultasAbertas(multas);
  const st       = statusVenda(v);
  const quitado  = st === 'quitado';
  const proxData = !quitado ? calcularDataParcela(v.dataInicio, c.pagasInt+1, v.tipoVenc||'mensal') : null;
  const atraso   = proxData ? diasDeAtraso(proxData) : 0;
  const pctPago  = Math.min(100, Math.round(((c.pagasInt*c.parcela+c.jaPagoFrac)/Math.max(c.total,0.01))*100));
  const labelParcelas = c.jaPagoFrac > 0
    ? `${c.pagasInt}/${v.numParcelas} pagas + ${fmt(c.jaPagoFrac)} na próxima`
    : `${c.pagasInt}/${v.numParcelas} parcelas pagas`;
  const tipoLabel = {mensal:'Mensal',quinzenal:'Quinzenal',semanal:'Semanal',diario:'Diário'}[v.tipoVenc||'mensal'];
  const tipoVendaBadge = v.tipo === 'renovacao'
    ? `<span style="font-size:9px;font-weight:700;background:var(--accent);color:#fff;padding:2px 6px;border-radius:10px;margin-left:4px">Renovação</span>`
    : `<span style="font-size:9px;font-weight:700;background:var(--green-dim);color:var(--green);padding:2px 6px;border-radius:10px;margin-left:4px">Nova</span>`;

  const qtdMultasAbertas = multas.filter(m=>m.status==='aberto').length;
  const situacaoParcela = quitado
    ? '<span style="color:var(--green);font-weight:600">Quitado</span>'
    : proxData
      ? `Próx. venc.: ${fmtData(proxData)}` + (atraso>=4?` <span style="color:var(--red);font-weight:700">· ${atraso}d de atraso</span>`:atraso>=2?` <span style="color:var(--yellow);font-weight:700">· ${atraso}d de atraso</span>`:'')
      : '';

  const div = document.createElement('div');
  div.className = 'venda-card';
  div.innerHTML = `
    <div class="venda-header">
      <div style="flex:1;min-width:0">
        <div class="venda-titulo" style="display:flex;align-items:center;gap:8px">
          Empréstimo${tipoVendaBadge}
        </div>
        ${!noDetalhe?`<div class="venda-cliente-nome" id="vcn_${v.id}"></div>`:''}
        <div style="font-size:11px;color:var(--text-secondary);margin-top:2px">${tipoLabel} · ${v.numParcelas}x ${fmt(c.parcela)}</div>
        <div style="font-size:11px;margin-top:2px">${situacaoParcela}</div>
      </div>
      <div style="display:flex;align-items:flex-start;gap:8px">
        <div class="cliente-meta">
          <div class="venda-valor" style="color:var(--red)">${fmt(c.saldoParcelas)}</div>
          <div class="venda-subvalor">a receber</div>
        </div>
        ${!quitado?`<button class="btn-copy-mini-icon" onclick="event.stopPropagation();copiarParcelasVenda(${v.id})" title="Copiar parcelas desta venda"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>`:''}
      </div>
    </div>

    <div class="venda-section">
      <div class="venda-section-title">Resumo</div>
      <div class="venda-breakdown">
        <div class="bd-row"><span>Valor emprestado</span><span>${fmt(c.emp)}</span></div>
        <div class="bd-row"><span>Juros (${pct(v.jurosPct||0)})</span><span class="bd-juros">${fmt(c.juros)}</span></div>
        <div class="bd-row bd-border"><span>Total em aberto</span><span><strong>${fmt(c.saldoParcelas)}</strong></span></div>
        ${c.jaPagoFrac>0?`<div class="bd-row bd-saldo-parcial"><span>Saldo parcial já pago</span><span>${fmt(c.jaPagoFrac)}</span></div>`:''}
      </div>
    </div>

    <div class="venda-section">
      <div class="venda-section-title">Parcelas<span style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--text-secondary)">${pctPago}%</span></div>
      <div class="parcelas-bar"><div class="parcelas-fill" style="width:${pctPago}%"></div></div>
      <div class="parcelas-info"><span>${labelParcelas}</span></div>
    </div>

    ${qtdMultasAbertas>0?`
    <div class="venda-section">
      <div class="venda-section-title is-alert">Multas</div>
      <div class="venda-multas-alerta">
        <strong>${qtdMultasAbertas} multa${qtdMultasAbertas>1?'s':''} em aberto</strong>
        <span>${fmt(multAb)}</span>
      </div>
    </div>`:''}

    <div class="venda-section">
      <div class="venda-section-title">Ações</div>
      ${!quitado?`
      <div class="acoes-primaria">
        <button class="btn-pagar">Pagar parcela</button>
      </div>
      <div class="acoes-secundarias">
        <button class="btn-nao-pagou">Não pagou</button>
        <button class="btn-ver-multas${multAb>0?' tem-pendencia':''}">Multas${multAb>0?' ('+qtdMultasAbertas+')':''}</button>
        <button class="btn-parcelas-toggle">Parcelas</button>
        <button class="btn-editar-venda-completo">Editar venda</button>
      </div>
      <div class="acoes-terciarias">
        <button class="btn-historico-parcelas">Histórico de parcelas</button>
      </div>
      `:`
      <div class="acoes-terciarias">
        <button class="btn-historico-parcelas">Histórico de parcelas</button>
      </div>
      `}
    </div>
    <div class="parcelas-grid" id="parcelasGrid_${v.id}">
      <div class="parcelas-grid-header"><span>#</span><span>Vencimento</span><span>Valor</span><span>Status</span></div>
      <div id="parcelasRows_${v.id}"></div>
    </div>`;

  if (!noDetalhe) {
    const cl = clientesMap ? clientesMap.get(v.clienteId) : null;
    const el = div.querySelector(`#vcn_${v.id}`);
    if (el && cl) el.textContent = cl.nomeComercial || cl.nome;
  }
  const bp=div.querySelector('.btn-pagar'); if(bp)bp.addEventListener('click',()=>{
    const cl = clientesMap ? clientesMap.get(v.clienteId) : null;
    abrirConfirmacaoBaixa({
      vendaId: v.id,
      cliente: cl ? (cl.nomeComercial || cl.nome) : (v.clienteNome || '—'),
      parcela: `${c.pagasInt + 1}/${v.numParcelas}`,
      valor: c.proximaParcela,
      vencimento: fmtData(proxData),
      formaPagamento: 'dinheiro'
    });
  });
  const bn=div.querySelector('.btn-nao-pagou'); if(bn)bn.addEventListener('click',async()=>{
    const cl = clientesMap ? clientesMap.get(v.clienteId) : null;
    const nomeCliente = cl ? (cl.nomeComercial||cl.nome) : (v.clienteNome||'—');
    if(!confirm(`Registrar que ${nomeCliente} não pagou a parcela de hoje?`)) return;
    bn.disabled = true;
    try {
      await salvarPagamento({
        vendaId: v.id, clienteId: v.clienteId, tipo: 'nao-pagou',
        valorPago: 0, formaPagamento: null, motivo: 'Cliente não pagou',
        data: hoje(), dataPagamento: hoje(),
        pagasIntAntes: c.pagasInt, pagasIntAgora: c.pagasInt,
        saldoParcialAntes: c.jaPagoFrac, saldoParcialDepois: c.jaPagoFrac,
        parcelaNumero: c.pagasInt + 1,
      });
      showToast('Registrado: cliente não pagou hoje', 'info');
      renderPainel(); renderVendas();
      if (clienteDetalheId) abrirDetalheCliente(clienteDetalheId);
    } finally {
      bn.disabled = false;
    }
  });
  const bm=div.querySelector('.btn-ver-multas'); if(bm)bm.addEventListener('click',()=>abrirGestaoMultas(v.id));
  const bt=div.querySelector('.btn-parcelas-toggle'); if(bt)bt.addEventListener('click',async()=>{ const g=div.querySelector(`#parcelasGrid_${v.id}`); g.classList.toggle('open'); if(g.classList.contains('open'))await renderParcelasGrid(v.id,div); });
  const bh=div.querySelector('.btn-historico-parcelas'); if(bh)bh.addEventListener('click',()=>abrirHistoricoParcelas(v));
  const bev=div.querySelector('.btn-editar-venda-completo');
  if(bev){
    const criadoEm = new Date(v.criado_em + 'T00:00:00');
    const agora = new Date();
    const diff = (agora - criadoEm) / (1000 * 60 * 60);
    if(diff > 24) {
      bev.style.opacity = '0.5';
      bev.style.cursor = 'not-allowed';
      bev.title = 'Edição disponível apenas nas primeiras 24h';
      bev.addEventListener('click', (e) => { e.stopPropagation(); showToast('Esta venda não pode mais ser editada (limite de 24h)', 'error'); });
    } else {
      bev.addEventListener('click', (e) => { e.stopPropagation(); abrirEditarVendaCompleto(v); });
    }
  }
  return div;
}

async function abrirEditarVendaCompleto(v) {
  vendaEditandoId = v.id;
  document.getElementById('modalVendaTitulo').textContent = 'Editar Empréstimo';
  
  const clientes = await listarClientes();
  const sel = document.getElementById('vendaCliente');
  sel.innerHTML = '<option value="">Selecione o cliente</option>';
  clientes.forEach(c => { const o=document.createElement('option'); o.value=c.id; o.textContent=(c.idNumerico?`[${c.idNumerico}] `:'')+( c.nomeComercial||c.nome); sel.appendChild(o); });
  sel.value = v.clienteId;

  document.getElementById('vendaValorEmprestimo').value = v.valorEmprestimo;
  document.getElementById('vendaJurosPct').value = v.jurosPct;
  document.getElementById('vendaNumParcelas').value = v.numParcelas;
  document.getElementById('vendaDataInicio').value = v.dataInicio;
  document.getElementById('vendaTipoVenc').value = v.tipoVenc || 'mensal';
  document.getElementById('vendaDiasMulta').value = v.diasMulta || '2';
  document.getElementById('vendaValorMulta').value = v.valorMulta || '0';
  
  // Recalcular juros e total
  const valor = parseFloat(v.valorEmprestimo);
  const jurosPct = parseFloat(v.jurosPct);
  const jurosValor = +(valor * jurosPct / 100).toFixed(2);
  const total = +(valor + jurosValor).toFixed(2);
  const parcela = v.numParcelas > 0 ? +(total / v.numParcelas).toFixed(2) : 0;
  
  document.getElementById('vendaJurosValor').value = jurosValor;
  document.getElementById('vendaTotal').value = total;
  document.getElementById('vendaParcelaValor').value = parcela;
  
  openModal('modalVenda');
}

async function abrirHistoricoParcelas(venda) {
  const body = document.getElementById('historicoParcelasBody');
  document.getElementById('historicoParcelasTitulo').textContent = ` Histórico de Parcelas — Venda #${venda.id}`;
  body.innerHTML = '<p style="text-align:center;color:var(--text-muted)">Carregando histórico...</p>';
  openModal('modalHistoricoParcelas');
  try {
    const historico = await getHistoricoCobranca(venda.id);
    const pagamentosHistorico = historico.filter(h => h.situacao === 'pagamento');
    const naoPagouCount = historico.filter(h => h.situacao === 'nao-pagou' && String(h.observacao || '') !== 'evento-pagamento').length;
    const classificacao = naoPagouCount >= 6 ? 'Vermelha' : (naoPagouCount >= 4 ? 'Amarela' : 'Verde');
    const classificacaoCor = naoPagouCount >= 6 ? 'var(--red)' : (naoPagouCount >= 4 ? 'var(--yellow)' : 'var(--green)');
    const recebido = pagamentosHistorico.reduce((s, h) => s + (Number(h.valorPago) || 0), 0);
    const total = Number(venda.totalComJuros || 0);
    const percentual = total > 0 ? Math.min(100, (recebido / total) * 100) : 0;
    const linhas = [...historico].sort((a,b)=>a.dataCobranca.localeCompare(b.dataCobranca) || a.id-b.id).map(h => {
      const classe = {pago:'ps-pago','nao-pagou':'ps-atrasado',pagamento:'ps-pago',parcial:'ps-parcial',pendente:'ps-pendente'}[h.situacao] || 'ps-futuro';
      const label = h.situacao === 'pagamento' ? `Pago — ${fmt(h.valorPago)}` : ({pago:'Pago', 'nao-pagou':'Não pagou', parcial:'Parcial', pendente:'Pendente'}[h.situacao] || h.situacao);
      const data = h.situacao === 'pagamento' ? h.dataPagamento : h.dataCobranca;
      const obs = h.observacao ? ` <small>${h.observacao}</small>` : '';
      return `<tr><td>${fmtData(data)}</td><td>${h.parcelaNumero}</td><td><span class="${classe}">${label}</span>${obs}</td><td>${h.situacao === 'pagamento' ? fmt(h.valorPago) : '—'}</td><td>${h.situacao === 'pagamento' ? `Baixa referente à parcela ${h.parcelaNumero} · cobrança de ${fmtData(h.dataCobranca)}` : '—'}</td></tr>`;
    }).join('');
    body.innerHTML = `<div class="resumo-venda-box" style="display:block;margin-bottom:14px">
      <div class="rv-linha"><span>Total oficial do contrato</span><strong>${fmt(total)}</strong></div>
      <div class="rv-linha"><span>Total recebido</span><strong style="color:var(--green)">${fmt(recebido)}</strong></div>
      <div class="rv-linha"><span>Total em aberto</span><strong style="color:var(--red)">${fmt(Math.max(0,total-recebido))}</strong></div>
      <div class="rv-linha"><span>Percentual pago</span><strong>${percentual.toFixed(2)}%</strong></div>
      <div class="rv-linha"><span>Dias “Não pagou”</span><strong style="color:var(--red)">${naoPagouCount}</strong></div>
      <div class="rv-linha"><span>Classificação</span><strong style="color:${classificacaoCor}">${classificacao}</strong></div>
    </div><div style="overflow:auto"><table class="historico-parcelas-table"><thead><tr><th>Data</th><th>Parcela do dia</th><th>Situação</th><th>Valor da baixa</th><th>Observação</th></tr></thead><tbody>${linhas || '<tr><td colspan="5">Nenhum registro de cobrança encontrado.</td></tr>'}</tbody></table></div>`;
  } catch (e) {
    body.innerHTML = '<p style="color:var(--red);text-align:center">Não foi possível carregar o histórico desta venda.</p>';
  }
}

document.getElementById('closeModalHistoricoParcelas').addEventListener('click', () => closeModal('modalHistoricoParcelas'));
document.getElementById('cancelarHistoricoParcelas').addEventListener('click', () => closeModal('modalHistoricoParcelas'));

async function renderParcelasGrid(vendaId, cardEl) {
  const rows    = cardEl.querySelector(`#parcelasRows_${vendaId}`);
  const parcelas = await getParcelas(vendaId);
  if (!parcelas.length) { rows.innerHTML='<div style="padding:10px;text-align:center;font-size:12px;color:var(--text-muted)">Sem registros.</div>'; return; }
  parcelas.sort((a,b)=>a.numero-b.numero);
  rows.innerHTML = parcelas.map(p => {
    const sc={pago:'ps-pago',atrasado:'ps-atrasado',pendente:'ps-pendente',futuro:'ps-futuro',parcial:'ps-parcial'}[p.status]||'ps-futuro';
    const sl={pago:'Pago',atrasado:'Atrasado',pendente:'Pendente',futuro:'Futuro',parcial:'Parcial'}[p.status]||'Futuro';
    return `<div class="parcela-row">
      <span class="parcela-num">${p.numero}</span>
      <span class="parcela-data">${fmtData(p.dataVencimento)}${p.dataPagamento?`<br><span style="font-size:9px;color:var(--green)">Pago ${fmtData(p.dataPagamento)}</span>`:''}</span>
      <span class="parcela-valor">${fmt(p.valorPago??p.valor)}</span>
      <span class="parcela-status"><span class="${sc}">${sl}</span></span>
    </div>`;
  }).join('');
}

/* ═══════════════════════════════════════════════════════════
   MODAL CLIENTE
═══════════════════════════════════════════════════════════ */
let clienteEditandoId = null;

document.getElementById('btnNovoCliente').addEventListener('click', () => {
  clienteEditandoId = null; fotosEditando = [];
  document.getElementById('modalClienteTitulo').textContent = 'Novo Cliente';
  ['clienteId','clienteNome','clienteNomeComercial','clienteCpf','clienteRg','clienteCelular','clienteEnderecoRes','clienteEnderecoCom','clienteObs'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('clienteTipoEndereco').value = 'residencial';
  atualizarCamposEndereco(); renderFotosGrid(); openModal('modalCliente');
});
document.getElementById('closeModalCliente').addEventListener('click', () => closeModal('modalCliente'));
document.getElementById('cancelarCliente').addEventListener('click',   () => closeModal('modalCliente'));

  document.getElementById('salvarCliente').addEventListener('click', async () => {
    const btnSalvar = document.getElementById('salvarCliente');
    const nome          = document.getElementById('clienteNome').value.trim();
    const nomeComercial = document.getElementById('clienteNomeComercial').value.trim();
    const cpf           = document.getElementById('clienteCpf').value.trim();
    const rg            = document.getElementById('clienteRg').value.trim();
    const enderecoRes   = document.getElementById('clienteEnderecoRes').value.trim();
    const enderecoCom   = document.getElementById('clienteEnderecoCom').value.trim();
    const tipoEndereco  = document.getElementById('clienteTipoEndereco').value;

    // Validação de campos obrigatórios
    if (!nome) { showToast('Nome completo é obrigatório', 'error'); return; }
    if (!nomeComercial) { showToast('Nome comercial é obrigatório', 'error'); return; }
    if (!cpf) { showToast('CPF é obrigatório', 'error'); return; }
    if (!rg) { showToast('RG é obrigatório', 'error'); return; }
    
    // Validação de endereço baseada no tipo
    if ((tipoEndereco === 'residencial' || tipoEndereco === 'ambos') && !enderecoRes) {
      showToast('Endereço residencial é obrigatório', 'error'); return;
    }
    if ((tipoEndereco === 'comercial' || tipoEndereco === 'ambos') && !enderecoCom) {
      showToast('Endereço comercial é obrigatório', 'error'); return;
    }

    // Validação de fotos (Mínimo 1)
    if (fotosEditando.length < 1) {
      showToast('É obrigatório o envio de no mínimo 1 foto do cliente', 'error'); return;
    }

    // Desabilitar botão para evitar duplo POST
    btnSalvar.disabled = true;

    try {
      const id = clienteEditandoId || gerarId();
      const cliente = {
        id, nome, nomeComercial, cpf, rg, tipoEndereco, enderecoRes, enderecoCom,
        idNumerico:    document.getElementById('clienteId').value.trim(),
        celular:       document.getElementById('clienteCelular').value.trim(),
        obs:           document.getElementById('clienteObs').value.trim(),
        criadoEm:      clienteEditandoId ? undefined : hoje(),
      };
      
      // Foto de perfil removida conforme solicitação.
      cliente._fotoThumb = null;
      
      const res = await api('clientes.salvar', { dados: cliente });
      // CORRIGIDO: api() retorna json.dados (objeto) em sucesso, não um Response com .ok
      // api() já exibe o toast de erro automaticamente em caso de falha
      if (res !== null) {
        const fotosAntigas = await getFotos(id);
        for (const f of fotosAntigas) await excluirFoto(f.id);
        for (let i=0; i<fotosEditando.length; i++) {
          await salvarFoto({ clienteId: id, data: fotosEditando[i].data, label: fotosEditando[i].label, ordem: i });
        }
        
        closeModal('modalCliente');
        showToast(clienteEditandoId ? 'Cliente atualizado!' : 'Cliente criado.');
        switchTab('clientes');
        if (clienteDetalheId === id) abrirDetalheCliente(id);
      }
    } catch (err) {
      showToast('Erro na operação', 'error');
    } finally {
      btnSalvar.disabled = false;
    }
  });

/* ═══════════════════════════════════════════════════════════
   MODAL VENDA
═══════════════════════════════════════════════════════════ */
let vendaEditandoId = null;
async function abrirModalVenda(clienteIdPre) {
  vendaEditandoId = null;
  document.getElementById('modalVendaTitulo').textContent = 'Novo Empréstimo';
  const clientes = await listarClientes();
  const sel = document.getElementById('vendaCliente');
  sel.innerHTML = '<option value="">Selecione o cliente</option>';
  clientes.forEach(c => { const o=document.createElement('option'); o.value=c.id; o.textContent=(c.idNumerico?`[${c.idNumerico}] `:'')+( c.nomeComercial||c.nome); sel.appendChild(o); });
  if (clienteIdPre) sel.value = clienteIdPre;
  ['vendaValorEmprestimo','vendaNumParcelas'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('vendaJurosPct').value  ='0';
  document.getElementById('vendaTipoVenc').value  ='mensal';
  document.getElementById('vendaDataInicio').value= hoje();
  document.getElementById('vendaDiasMulta').value ='2';
  document.getElementById('vendaValorMulta').value='';
  document.getElementById('resumoVenda').style.display='none';
  fotosVenda = []; renderFotosGridVenda();
  atualizarPreviewMulta(); openModal('modalVenda');
}

function calcularFinanceiroNovaVendaJS(valorEmprestimo, jurosPct, numParcelas) {
  const emp = Math.round((Number(valorEmprestimo) || 0) * 100) / 100;
  const pct = Math.round((Number(jurosPct) || 0) * 100) / 100;
  const n = parseInt(numParcelas, 10) || 0;
  const juros = Math.round((emp * pct / 100) * 100) / 100;
  const totalCalculado = Math.round((emp + juros) * 100) / 100;
  const parcela = n > 0 ? Math.ceil((totalCalculado / n) - 1e-8) : 0;
  const totalOficial = parcela * n;
  if (n > 0 && Math.round(parcela * 100) * n !== Math.round(totalOficial * 100)) {
    throw new Error('Parcela x quantidade diferente do total oficial.');
  }
  return { juros, total: totalOficial, parcela };
}

function atualizarResumoVenda() {
  const emp=parseFloat(document.getElementById('vendaValorEmprestimo').value)||0;
  const jPct=parseFloat(document.getElementById('vendaJurosPct').value)||0;
  const num=parseInt(document.getElementById('vendaNumParcelas').value)||0;
  const financeiro = num > 0
    ? (vendaEditandoId ? (() => { const juros=+(emp*jPct/100).toFixed(2); const total=+(emp+juros).toFixed(2); return {juros,total,parcela:+(total/num).toFixed(2)}; })() : calcularFinanceiroNovaVendaJS(emp,jPct,num))
    : {juros:emp*jPct/100,total:emp+emp*jPct/100,parcela:0};
  const juros=financeiro.juros,total=financeiro.total,parcela=financeiro.parcela;
  const box=document.getElementById('resumoVenda');
  if(emp>0&&num>0){box.style.display='block';document.getElementById('rv_emprestimo').textContent=fmt(emp);document.getElementById('rv_juros').textContent=`${fmt(juros)} (${pct(jPct)})`;document.getElementById('rv_total').textContent=fmt(total);document.getElementById('rv_parcela').textContent=fmt(parcela);}else{box.style.display='none';}
}
function atualizarPreviewMulta() {
  const dias=document.getElementById('vendaDiasMulta').value||'2';
  const valor=parseFloat(document.getElementById('vendaValorMulta').value)||0;
  document.getElementById('diasMultaPreview').textContent=dias+' dias';
  document.getElementById('valorMultaPreview').textContent=valor>0?fmt(valor):'R$ —';
}
['vendaValorEmprestimo','vendaJurosPct','vendaNumParcelas'].forEach(id=>document.getElementById(id).addEventListener('input',atualizarResumoVenda));
['vendaDiasMulta','vendaValorMulta'].forEach(id=>document.getElementById(id).addEventListener('input',atualizarPreviewMulta));

document.getElementById('closeModalVenda').addEventListener('click', ()=>closeModal('modalVenda'));
document.getElementById('cancelarVenda').addEventListener('click',   ()=>closeModal('modalVenda'));

  document.getElementById('salvarVendaBtn').addEventListener('click', async () => {
    if (await atualizarStatusFechamento()) {
      showToast('Operação bloqueada: Ruta fechada ou antes das 08:00', 'error');
      return;
    }
    const clienteId      =document.getElementById('vendaCliente').value;
    
    // Se for nova venda, validar se já existe uma ativa
    if (!vendaEditandoId && clienteId) {
      const vendasExistentes = await getVendasDoCliente(clienteId);
      // Verificação completa: venda ativa = parcelas OU multas pendentes
      // Usa vendaEstaQuitada() (assíncrona) para garantir que multas pendentes
      // impeçam a renovação, mesmo que todas as parcelas estejam pagas.
      const quitadasFlags = await Promise.all(vendasExistentes.map(v => vendaEstaQuitada(v)));
      const vendaAtiva = vendasExistentes.find((v, i) => !quitadasFlags[i]);
      if (vendaAtiva) {
        showToast('Não permitido: O cliente já possui uma venda ativa não quitada.', 'error');
        return;
      }
    }
    
    const valorEmprestimo=parseFloat(document.getElementById('vendaValorEmprestimo').value);
    const jurosPct       =parseFloat(document.getElementById('vendaJurosPct').value)||0;
    const numParcelas    =parseInt(document.getElementById('vendaNumParcelas').value);
    const tipoVenc       =document.getElementById('vendaTipoVenc').value;
    const dataInicio     =document.getElementById('vendaDataInicio').value;
    const diasMulta      =parseInt(document.getElementById('vendaDiasMulta').value)||2;
    const valorMulta     =parseFloat(document.getElementById('vendaValorMulta').value)||0;
    
    if(!clienteId){showToast('Selecione o cliente','error');return;}
    if(!valorEmprestimo||valorEmprestimo<=0){showToast('Informe o valor','error');return;}
    if(!numParcelas||numParcelas<=0){showToast('Informe as parcelas','error');return;}
    if(!dataInicio){showToast('Informe a data da 1ª parcela','error');return;}
    // Validar fotos apenas em NOVA venda, não em edição
    if(!vendaEditandoId && fotosVenda.length < 2){showToast('É obrigatório o envio de no mínimo 2 fotos na venda','error');return;}
    
    // Vendas novas usam a regra oficial; vendas existentes preservam o
    // cálculo histórico para não alterar contratos já registrados.
    let jurosValor, totalComJuros, valorParcela;
    if (vendaEditandoId) {
      jurosValor = +(valorEmprestimo*jurosPct/100).toFixed(2);
      totalComJuros = +(valorEmprestimo+jurosValor).toFixed(2);
      valorParcela = +(totalComJuros/numParcelas).toFixed(2);
    } else {
      const financeiro = calcularFinanceiroNovaVendaJS(valorEmprestimo, jurosPct, numParcelas);
      jurosValor = financeiro.juros;
      totalComJuros = financeiro.total;
      valorParcela = financeiro.parcela;
      if (Math.round(valorParcela * 100) * numParcelas !== Math.round(totalComJuros * 100)) {
        showToast('Venda não salva: parcela × quantidade deve ser igual ao total oficial.', 'error');
        return;
      }
    }
    
    const btn = document.getElementById('salvarVendaBtn');
    btn.disabled = true;
    
    try {
      if (vendaEditandoId) {
        const dados = {
          id: vendaEditandoId,
          valorEmprestimo, jurosPct, jurosValor, totalComJuros,
          numParcelas, valorParcela, dataInicio
        };
        const res = await api('venda.editar', { dados });
        // CORRIGIDO: api() retorna json.dados em sucesso, não um Response com .ok
        // api() já exibe o toast de erro automaticamente em caso de falha
        if (res !== null) {
          // Recriar parcelas se mudou algo crítico
          await api('parcelas.excluirPorVenda', { vendaId: vendaEditandoId });
          await gerarParcelasVenda({ id: vendaEditandoId, clienteId, dataInicio, numParcelas, valorParcela, tipoVenc });
          showToast('Venda atualizada! ');
        } else {
          return;
        }
      } else {
        // CORRIGIDO: captura o nome do cliente para incluir em novaVenda e em movimentacoes
        const selVenda = document.getElementById('vendaCliente');
        const clienteNome = selVenda.options[selVenda.selectedIndex]?.text || '';
        const novaVenda={ 
          clienteId, clienteNome, valorEmprestimo,jurosPct,jurosValor,totalComJuros,numParcelas,
          tipoVenc,parcelasPagas:0,saldoParcialPago:0,valorParcela,dataInicio,
          diasMulta,valorMulta,criado_em:hoje(), edicoes_restantes: 3
        };
        const novoId = await salvarVenda(novaVenda);
        // CORRIGIDO: aborta se salvarVenda retornou null (falha na API)
        if (!novoId) return;
        novaVenda.id = novoId;
        await gerarParcelasVenda(novaVenda);
        // Salvar fotos vinculadas à venda e ao cliente
        for (let i=0; i<fotosVenda.length; i++) {
          await salvarFoto({ clienteId, vendaId: novoId, data: fotosVenda[i].data, label: fotosVenda[i].label, ordem: i });
        }
        fotosVenda = [];
        showToast('Venda registrada! ');
      }
      
      closeModal('modalVenda');
      switchTab('vendas');
      if(clienteDetalheId)abrirDetalheCliente(clienteDetalheId);
    } catch (err) {
      showToast('Erro na operação', 'error');
    } finally {
      btn.disabled = false;
    }
  });

/* ═══════════════════════════════════════════════════════════
   DETALHE CLIENTE
═══════════════════════════════════════════════════════════ */
async function abrirDetalheCliente(id) {
  clienteDetalheId = id;
  const cliente = await getCliente(id); if(!cliente)return;
  const vendas  = await getVendasDoCliente(id);
  const fotos   = await getFotos(id);
  fotos.sort((a,b)=>(a.ordem||0)-(b.ordem||0));
  const status   = statusGlobalCliente(vendas);
  const divida   = await totalDevidoCliente(vendas);
  const ativas   = vendas.filter(v=>parseInt(v.parcelasPagas||0,10)<v.numParcelas);
  const quitadas = vendas.filter(v=>parseInt(v.parcelasPagas||0,10)>=v.numParcelas);
  const totalEmp = vendas.reduce((a,v)=>a+(v.valorEmprestimo||0),0);
  const totalJur = vendas.reduce((a,v)=>a+(v.jurosValor||0),0);
  let totalMultasAb=0;
  for(const v of vendas){const m=await getMultasVenda(v.id);totalMultasAb+=calcularTotalMultasAbertas(m);}
  document.getElementById('detalheClienteNome').textContent = cliente.nomeComercial || cliente.nome;
  const badgeMap={'em-dia':'badge-em-dia','pendente':'badge-pendente','atrasado':'badge-atrasado'};
  const labelMap={'em-dia':'Em Dia','pendente':'Pendente','atrasado':'Atrasado'};
  const f0 = fotos[0];
  const fotoPerfil = f0 ? (f0.data && f0.data.length > 100 ? f0.data : (f0.label && f0.label.length > 100 ? f0.label : null)) : null;
  const body=document.getElementById('detalheClienteBody');
  body.innerHTML=`
    <div class="detalhe-header">
      <div class="detalhe-avatar">${(cliente.nomeComercial||cliente.nome||'?').charAt(0).toUpperCase()}</div>
      <div class="detalhe-info">
        ${cliente.idNumerico?`<span class="id-tag">Cliente #${cliente.idNumerico}</span>`:''}
        <h4>${cliente.nomeComercial || cliente.nome}</h4>
        ${cliente.nomeComercial ? `<p>${cliente.nome}</p>` : ''}
        ${cliente.celular?`<p> ${cliente.celular}</p>`:''}
        ${cliente.cpf?`<p>CPF: ${cliente.cpf}</p>`:''}
        ${cliente.enderecoRes?`<p> ${cliente.enderecoRes}</p>`:''}
        ${cliente.enderecoCom?`<p> ${cliente.enderecoCom}</p>`:''}
        ${cliente.obs?`<p style="color:var(--text-muted);font-size:11px"> ${cliente.obs}</p>`:''}
        <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
          <span class="cliente-badge ${badgeMap[status]}">${labelMap[status]}</span>
          <button class="btn-copy-parcelas" onclick="copiarParcelasCliente('${cliente.id}')" title="Copiar parcelas atrasadas/pendentes">Copiar parcelas</button>
          ${cliente.celular ? `<a class="btn-whatsapp" href="#" onclick="abrirWhatsApp('${cliente.celular}','${(cliente.nomeComercial||cliente.nome||'').replace(/'/g,"\\'")}');return false;" title="Cobrar via WhatsApp">Cobrar</a>` : ''}
        </div>
      </div>
    </div>
    <div class="galeria-section" id="galeriaSection">
      <div class="galeria-header">
        <span class="galeria-title">Galeria (${fotos.length})</span>
        <div style="display:flex;gap:8px">
          <button class="btn-add-foto-galeria" id="btnAddFotoGaleria">Foto</button>
          ${fotos.length>1?`<button class="btn-galeria-completa" id="btnVerGaleria">Ver Todas</button>`:''}
        </div>
      </div>
      ${fotos.length===0?'<p class="empty-msg" style="padding:8px 0">Sem fotos.</p>':`<div class="galeria-grid" id="galeriaGrid">${renderGaleriaThumbsHTML(fotos,1)}</div>`}
    </div>
    <div class="conta-cliente">
      <div class="conta-titulo">Resumo Financeiro</div>
      <div class="conta-linha"><span>Total Emprestado</span><span class="cv">${fmt(totalEmp)}</span></div>
      <div class="conta-linha"><span>Juros Totais</span><span class="cv amarelo">${fmt(totalJur)}</span></div>
      <div class="conta-linha conta-total"><span>Total em Aberto</span><span class="cv vermelho">${fmt(divida)}</span></div>
      <div class="conta-linha ${totalMultasAb>0?'conta-linha-destaque':''}" style="margin-top:8px;border-top:1px dashed var(--border-strong);padding-top:8px"><span>Multas em aberto</span><span class="cv vermelho">${totalMultasAb>0 ? fmt(totalMultasAb) : 'R$ 0,00'}</span></div>
    </div>
    <div class="detalhe-resumo">
      <div class="resumo-item"><div class="r-val">${vendas.length}</div><div class="r-label">Vendas</div></div>
      <div class="resumo-item"><div class="r-val">${ativas.length}</div><div class="r-label">Ativas</div></div>
      <div class="resumo-item"><div class="r-val" style="color:var(--green)">${quitadas.length}</div><div class="r-label">Quitadas</div></div>
      <div class="resumo-item"><div class="r-val" style="color:var(--red);font-size:14px">${fmt(divida)}</div><div class="r-label">Dívida (Parc.)</div></div>
    </div>
    <h3 class="detalhe-vendas-title" style="margin-top:16px">Empréstimos</h3>
    <div id="detalheVendasLista"></div>`;

  const btnVer=body.querySelector('#btnVerGaleria');
  if(btnVer){btnVer.addEventListener('click',()=>{verificarAcessoGaleria(()=>{document.getElementById('galeriaGrid').innerHTML=renderGaleriaThumbsHTML(fotos,fotos.length);btnVer.style.display='none';bindGaleriaThumbs(fotos);});});}
  
  const btnAdd=body.querySelector('#btnAddFotoGaleria');
  if(btnAdd){
    btnAdd.addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = async (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = async (event) => {
          const base64 = event.target.result;
          showToast('Salvando foto...', 'info');
          const res = await api('fotos.salvar', {
            dados: {
              clienteId: id,
              data: base64,
              label: 'Foto Galeria',
              dataFoto: new Date().toISOString().split('T')[0]
            }
          });
          if(res !== null) {
            showToast('Foto adicionada!', 'success');
            abrirDetalheCliente(id);
          } else {
            showToast('Erro ao salvar foto.', 'danger');
          }
        };
        reader.readAsDataURL(file);
      };
      input.click();
    });
  }
  bindGaleriaThumbs(fotos,1);
  const lista=body.querySelector('#detalheVendasLista');
  if(!vendas.length){lista.innerHTML='<p class="empty-msg">Nenhuma venda.</p>';}
  else{for(const v of vendas){const card=await criarCardVenda(v,true);lista.appendChild(card);}}
  openModal('modalDetalheCliente');
}

function renderGaleriaThumbsHTML(fotos,mostrar){
  if(!fotos.length)return'';
  const restantes=fotos.length-mostrar;
  return fotos.slice(0,mostrar).map((f,i)=>{
    const src = f.data && f.data.length > 100 ? f.data : (f.label && f.label.length > 100 ? f.label : '');
    return `<div class="galeria-thumb" data-idx="${i}"><img src="${src}" alt="${f.label||'foto'}"/><div class="galeria-thumb-label">${f.label && f.label.length < 50 ? f.label : `Foto ${i+1}`}</div></div>`;
  }).join('')+
    (restantes>0?`<div class="galeria-thumb" data-idx="${mostrar}" style="background:var(--bg-elevated)"><div class="galeria-thumb-count">+${restantes}</div></div>`:'');
}
function bindGaleriaThumbs(fotos,limite){
  document.querySelectorAll('.galeria-thumb').forEach(thumb=>{
    thumb.addEventListener('click',()=>{
      const idx=parseInt(thumb.dataset.idx);const foto=fotos[idx];if(!foto)return;
      const pin=getPin();
      const src = foto.data && foto.data.length > 100 ? foto.data : (foto.label && foto.label.length > 100 ? foto.label : '');
      const lbl = foto.label && foto.label.length < 50 ? foto.label : `Foto ${idx+1}`;
      if(pin&&!galeriaUnlocked&&idx>0){verificarAcessoGaleria(()=>abrirLightbox(src,lbl));}
      else{abrirLightbox(src,lbl);}
    });
  });
}

document.getElementById('closeDetalheCliente').addEventListener('click',()=>closeModal('modalDetalheCliente'));
document.getElementById('btnNovaVendaCliente').addEventListener('click',()=>{closeModal('modalDetalheCliente');abrirModalVenda(clienteDetalheId);});
document.getElementById('btnEditarCliente').addEventListener('click',async()=>{
  const c=await getCliente(clienteDetalheId);if(!c)return;
  clienteEditandoId=c.id;
  const fotos=await getFotos(c.id);fotos.sort((a,b)=>(a.ordem||0)-(b.ordem||0));
  fotosEditando=fotos.map(f=>({data:f.data,label:f.label,id:f.id}));
  document.getElementById('modalClienteTitulo').textContent='Editar Cliente';
  document.getElementById('clienteId').value=c.idNumerico||'';
  document.getElementById('clienteNomeComercial').value=c.nomeComercial||'';
  document.getElementById('clienteNome').value=c.nome;
  document.getElementById('clienteCpf').value=c.cpf||'';
  document.getElementById('clienteRg').value=c.rg||'';
  document.getElementById('clienteCelular').value=c.celular||'';
  document.getElementById('clienteTipoEndereco').value=c.tipoEndereco||'residencial';
  document.getElementById('clienteEnderecoRes').value=c.enderecoRes||'';
  document.getElementById('clienteEnderecoCom').value=c.enderecoCom||'';
  document.getElementById('clienteObs').value=c.obs||'';
  atualizarCamposEndereco();renderFotosGrid();closeModal('modalDetalheCliente');openModal('modalCliente');
});
/*
document.getElementById('btnExcluirCliente').addEventListener('click',async()=>{
  if(!confirm('Excluir este cliente e todos os seus dados?'))return;
  const vendas=await getVendasDoCliente(clienteDetalheId);
  for(const v of vendas){await excluirParcelasPorVenda(v.id);await excluirMultasPorVenda(v.id);await excluirVenda(v.id);}
  await excluirPagamentosPorCliente(clienteDetalheId);
  await excluirFotosPorCliente(clienteDetalheId);
  await excluirParcelasPorCliente(clienteDetalheId);
  await excluirMultasPorCliente(clienteDetalheId);
  await excluirCliente(clienteDetalheId);
  closeModal('modalDetalheCliente');showToast('Cliente excluído.','info');
  renderPainel();renderClientes();
});
*/

/* ═══════════════════════════════════════════════════════════
   MODAL PAGAMENTO
═══════════════════════════════════════════════════════════ */
let vendaPagandoId=null,formaPagSelecionada='dinheiro',comprovanteBase64=null;

async function abrirPagamento(vendaId) {
  vendaPagandoId=vendaId;formaPagSelecionada='dinheiro';comprovanteBase64=null;
  const vendas=await listarVendas();const v=vendas.find(x=>x.id===vendaId);if(!v)return;
  const cliente=await getCliente(v.clienteId);
  const c=calcularVenda(v);
  const multas=await getMultasVenda(vendaId);
  const multAb=calcularTotalMultasAbertas(multas);
  const proxData=calcularDataParcela(v.dataInicio,c.pagasInt+1,v.tipoVenc||'mensal');

  function calcPreview(val){
    let credito=+(c.jaPagoFrac+val).toFixed(2);let qtd=0;let fracao=0;
    for(let i=0;i<c.restam;i++){if(credito>=c.parcela-0.005){credito=+(credito-c.parcela).toFixed(2);qtd++;}else if(credito>0.005){fracao=credito;credito=0;break;}else break;}
    return{qtdInteiras:qtd,fracao};
  }

  document.getElementById('pagamentoInfo').innerHTML=`
    <div class="pag-info">
      <div class="pag-row"><strong>Cliente</strong><span>${cliente?cliente.nome:'—'}</span></div>
      <div class="pag-row"><strong>Parcela</strong><span>${c.pagasInt+1}ª de ${v.numParcelas}</span></div>
      <div class="pag-row"><strong>Vencimento</strong><span>${fmtData(proxData)}</span></div>
      <div class="pag-row"><strong>Valor da parcela</strong><span>${fmt(c.parcela)}</span></div>
      ${c.jaPagoFrac>0?`<div class="pag-row" style="background:var(--purple-dim);border-radius:var(--radius-sm);padding:5px 8px"><strong style="color:var(--purple)">Saldo parcial</strong><span style="color:var(--purple);font-weight:700">${fmt(c.jaPagoFrac)}</span></div><div class="pag-row"><strong>Falta</strong><span>${fmt(c.proximaParcela)}</span></div>`:''}
      <div class="pag-row"><strong>Total parcelas</strong><span>${fmt(c.saldoParcelas)}</span></div>
      ${multAb>0?`<div class="pag-row pag-multa"><strong>Multas</strong><span style="color:var(--red)">${fmt(multAb)} (separado)</span></div>`:''}
    </div>
    <div style="margin-top:2px">
      <div class="valor-custom-label" style="margin-bottom:7px">Forma de Pagamento</div>
      <div class="forma-pag-row">
        <button class="forma-btn selected" id="formaBtnDinheiro" onclick="selecionarForma('dinheiro')">Dinheiro</button>
        <button class="forma-btn" id="formaBtnPix" onclick="selecionarForma('pix')">Pix</button>
      </div>
    </div>
    <div id="comprovantePixBox" style="display:none">
      <div class="valor-custom-label" style="margin-bottom:5px">Comprovante Pix</div>
      <div class="comprovante-upload"><div style="font-size:13px;color:var(--text-muted)">Toque para anexar comprovante</div>
        <input type="file" id="comprovanteInput" accept="image/*"/></div>
      <div class="comprovante-preview" id="comprovantePreview" style="display:none"></div>
    </div>
    <div class="valor-custom-box">
      <div class="valor-custom-label">Valor recebido</div>
      <input type="number" id="pagValorInput" value="${c.proximaParcela.toFixed(2)}" step="0.01" min="0.01" class="pag-valor-input" placeholder="0,00"/>
      <div id="pagPreviewBox" style="display:flex;flex-direction:column;gap:4px;margin-top:4px"></div>
    </div>`;

  function atualizarPreview(){
    const val=parseFloat(document.getElementById('pagValorInput').value)||0;
    const prev=calcPreview(val);const saldo=Math.max(0,+(c.saldoParcelas-val).toFixed(2));
    const box=document.getElementById('pagPreviewBox');let html='';
    if(prev.qtdInteiras>0)html+=`<div class="pag-preview-linha pag-preview-parcial"><span class="pag-preview-label">Parcelas quitadas</span><span class="pag-preview-val" style="color:var(--accent)">${prev.qtdInteiras}x ${fmt(c.parcela)}</span></div>`;
    if(prev.fracao>0.005)html+=`<div class="pag-preview-linha" style="background:var(--purple-dim);border:1px solid rgba(167,139,250,.25)"><span class="pag-preview-label" style="color:var(--purple)">Saldo na próxima</span><span class="pag-preview-val" style="color:var(--purple)">${fmt(prev.fracao)}</span></div>`;
    if(val>=c.saldoParcelas-0.005&&prev.qtdInteiras>0)html+=`<div class="pag-preview-linha pag-preview-zerado"><span class="pag-preview-label" style="color:var(--green)">Parcelas quitadas!</span><span class="pag-preview-val" style="color:var(--green)">R$ 0,00</span></div>`;
    else if(saldo>0)html+=`<div class="pag-preview-linha pag-preview-saldo"><span class="pag-preview-label">Saldo restante</span><span class="pag-preview-val">${fmt(saldo)}</span></div>`;
    if(!html)html=`<div class="pag-preview-linha pag-preview-saldo" style="opacity:.5"><span>Informe um valor</span><span></span></div>`;
    box.innerHTML=html;
  }
  document.getElementById('pagValorInput').addEventListener('input',atualizarPreview);
  atualizarPreview();
  document.getElementById('comprovanteInput').addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=ev=>{comprovanteBase64=ev.target.result;const prev=document.getElementById('comprovantePreview');prev.style.display='flex';prev.innerHTML=`<img src="${comprovanteBase64}" alt="comprovante"/>`;};reader.readAsDataURL(file);});
  openModal('modalPagamento');
}

window.selecionarForma=function(forma){
  formaPagSelecionada=forma;
  document.getElementById('formaBtnDinheiro').className='forma-btn'+(forma==='dinheiro'?' selected':'');
  document.getElementById('formaBtnPix').className='forma-btn'+(forma==='pix'?' selected-pix':'');
  document.getElementById('comprovantePixBox').style.display=forma==='pix'?'':'none';
};

document.getElementById('closeModalPagamento').addEventListener('click',()=>closeModal('modalPagamento'));
document.getElementById('cancelarPagamento').addEventListener('click',  ()=>closeModal('modalPagamento'));

document.getElementById('confirmarPagamento').addEventListener('click',async()=>{
  const vendas=await listarVendas();const v=vendas.find(x=>x.id===vendaPagandoId);if(!v)return;
  const valorPago=parseFloat(document.getElementById('pagValorInput').value);
  if(!valorPago||valorPago<=0){showToast('Informe o valor pago','error');return;}

  // CORREÇÃO CIRÚRGICA: Multas são independentes no registro, mas bloqueiam a quitação da venda.
  const multasVerif=await getMultasVenda(v.id);
  const multasAbertasVerif=multasVerif.filter(m=>STATUS_MULTAS_BLOQUEANTES.includes(m.status));

  // Cálculo simplificado para saber se seria quitação (apenas para o aviso de multas no front)
  const c=calcularVenda(v);
  const seriaQuitacao = (c.jaPagoFrac + valorPago) >= (c.saldoParcelas - 0.005);
  
  if(seriaQuitacao && multasAbertasVerif.length > 0){
    showToast('Esta venda possui multas pendentes. Quite todas as multas na Gestão de Multas antes de finalizar a venda.','error');
    return;
  }

  // CHAMADA ÚNICA TRANSACIONAL
  const res = await registrarPagamentoTransacional({
    vendaId: v.id,
    valorPago: valorPago,
    formaPagamento: formaPagSelecionada,
    data: hoje(),
    clienteNome: v.clienteNome
  });

  if (!res || res.erro === "MULTAS_PENDENTES") {
    // res === null: erro já foi tratado/exibido pelo helper api()
    // res.erro === MULTAS_PENDENTES: erro específico, precisa de toast próprio
    if (res && res.erro === "MULTAS_PENDENTES") {
       showToast(res.mensagem, 'error');
    }
    closeModal('modalPagamento');
    return;
  }

  // Se houver comprovante Pix, salva separadamente (opcional, pois não é crítico para a baixa)
  if(formaPagSelecionada==='pix' && comprovanteBase64 && res.id) {
    await salvarFoto({
      clienteId: v.clienteId,
      pagamentoId: res.id,
      data: comprovanteBase64,
      label: 'Comprovante Pix ' + fmtData(hoje()),
      ordem: Date.now()
    });
  }

  closeModal('modalPagamento');
  
  const emojiForma = formaPagSelecionada==='pix' ? '' : '';
  let msg;
  if(res.quitadoTotal) msg = ' Dívida quitada!';
  else if(res.pagasIntAgora > c.pagasInt) msg = 'Parcela(s) baixada(s) com sucesso';
  else msg = 'Valor abatido no saldo parcial';
  
  showToast(`${emojiForma} ${fmt(valorPago)} · ${msg}`);
  renderPainel();
  renderVendas();
  if(clienteDetalheId) abrirDetalheCliente(clienteDetalheId);
});

/* ═══════════════════════════════════════════════════════════
   GESTÃO DE MULTAS
═══════════════════════════════════════════════════════════ */
let multaVendaIdAtual=null;

async function abrirGestaoMultas(vendaId){
  multaVendaIdAtual=vendaId;
  const vendas=await listarVendas();const v=vendas.find(x=>x.id===vendaId);if(!v)return;
  const cliente=await getCliente(v.clienteId);
  const multas=await getMultasVenda(vendaId);
  const multasAbertas=multas.filter(m=>m.status==='aberto');
  const totalAb=calcularTotalMultasAbertas(multas);
  const histHTML=multas.length?multas.map(m=>{
    const sc=m.status==='pago'?'msb-pago':m.status==='convertido'?'msb-parcela':'msb-aberto';
    const sl=m.status==='pago'?'Pago':m.status==='convertido'?'Convertida':'Aberto';
    const orig=m.origem==='auto'?' Automática':' Manual';
    return`<div style="background:var(--bg-elevated);border-radius:var(--radius-sm);padding:10px 12px;display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
      <div style="flex:1"><div style="font-size:12px;font-weight:600">${m.motivo||'Multa'}</div>
      <div style="font-size:11px;color:var(--text-muted);margin-top:2px">${orig} · ${fmtData(m.criadoEm)}</div>
      <span class="multa-status-badge ${sc}">${sl}</span>
      <div style="display:flex;gap:6px;margin-top:8px">
        ${m.status==='aberto'?`<button class="btn-sm btn-pagar" onclick="pagarMulta(${m.id})">Pagar</button><button class="btn-sm btn-parcelas-toggle" onclick="converterMultaParcela(${m.id})">Converter</button>`:''}
        <button class="btn-sm btn-secondary" style="padding:4px 8px;font-size:10px" onclick="prepararEditarMulta(${m.id})">Editar</button>
        <button class="btn-sm btn-danger" style="padding:4px 8px;font-size:10px" onclick="confirmarExcluirMulta(${m.id})">Excluir</button>
      </div>
      </div>
      <div style="font-size:15px;font-weight:700;color:var(--red)">${fmt(m.valor)}</div>
    </div>`;
  }).join('<div style="height:6px"></div>'):'<p class="empty-msg" style="padding:10px 0">Nenhuma multa registrada.</p>';

  document.getElementById('multaInfo').innerHTML=`
    <div class="pag-info"><div class="pag-row"><strong>Cliente</strong><span>${cliente?cliente.nome:'—'}</span></div>
    <div class="pag-row"><strong>Multas em aberto</strong><span style="color:var(--red);font-weight:700">${fmt(totalAb)} (${multasAbertas.length})</span></div></div>
    <div class="form-separator">Lançar Nova Multa Manualmente</div>
    <div class="form-row"><div class="form-group"><label>Valor (R$) *</label><input type="number" id="multaValorInput" placeholder="10,00" step="0.01" min="0.01"/></div>
    <div class="form-group"><label>Motivo</label><input type="text" id="multaMotivoInput" placeholder="Motivo da multa"/></div></div>
    <button class="btn-danger" style="width:100%" onclick="confirmarLancarMulta()">Lançar multa</button>
    <div class="form-separator">Histórico de Multas</div>
    <div style="display:flex;flex-direction:column;gap:6px">${histHTML}</div>`;
  openModal('modalMulta');
}

window.confirmarLancarMulta=async function(){
  const valor=parseFloat(document.getElementById('multaValorInput').value);
  const motivo=document.getElementById('multaMotivoInput').value.trim()||'Multa manual';
  if(!valor||valor<=0){showToast('Informe o valor da multa','error');return;}
  const vendas=await listarVendas();const v=vendas.find(x=>x.id===multaVendaIdAtual);if(!v)return;
  await salvarMulta({vendaId:v.id,clienteId:v.clienteId,valor,motivo,origem:'manual',status:'aberto',criadoEm:hoje()});
  await salvarPagamento({vendaId:v.id,clienteId:v.clienteId,tipo:'multa',valorPago:-valor,motivo,data:hoje(),dataPagamento:hoje()});
  showToast(`Multa ${fmt(valor)} lançada!`,'warning');
  abrirGestaoMultas(multaVendaIdAtual);renderPainel();renderVendas();
};

window.pagarMulta=async function(multaId){
  const multa=await getMultaById(multaId);if(!multa)return;
  multa.status='pago';multa.pagoEm=hoje();
  await salvarMulta(multa);
  await salvarPagamento({vendaId:multa.vendaId,clienteId:multa.clienteId,tipo:'multa-pago',valorPago:multa.valor,motivo:multa.motivo||'Pagamento de multa',data:hoje(),dataPagamento:hoje()});
  showToast(`Multa ${fmt(multa.valor)} paga!`,'success');
  abrirGestaoMultas(multaVendaIdAtual);renderPainel();renderVendas();
};

window.converterMultaParcela=async function(multaId){
  const multa=await getMultaById(multaId);if(!multa)return;
  const vendas=await listarVendas();const v=vendas.find(x=>x.id===multa.vendaId);if(!v)return;
  const ultimaData=calcularDataParcela(v.dataInicio,v.numParcelas,v.tipoVenc||'mensal');
  const proxData=calcularDataParcela(ultimaData,2,v.tipoVenc||'mensal');
  await salvarParcela({vendaId:v.id,clienteId:v.clienteId,numero:v.numParcelas+1,dataVencimento:proxData,valor:multa.valor,valorPago:null,status:'pendente',tipo:'multa',motivo:multa.motivo||'Parcela de Multa',dataPagamento:null,formaPagamento:null,atualizadoEm:hoje()});
  v.numParcelas=v.numParcelas+1;await salvarVenda(v);
  multa.status='convertido';multa.convertidoEm=hoje();await salvarMulta(multa);
  await salvarPagamento({vendaId:v.id,clienteId:v.clienteId,tipo:'multa-convertida',valorPago:multa.valor,motivo:'Parcela de Multa criada',data:hoje(),dataPagamento:hoje()});
  showToast('Multa convertida em parcela!','info');
  abrirGestaoMultas(multaVendaIdAtual);renderPainel();renderVendas();
};

let multaEditandoId = null;
window.prepararEditarMulta = async function(multaId) {
  const multa = await getMultaById(multaId);
  if (!multa) return;
  multaEditandoId = multaId;
  document.getElementById('multaValorInput').value = multa.valor;
  document.getElementById('multaMotivoInput').value = multa.motivo;
  const btn = document.querySelector('button[onclick="confirmarLancarMulta()"]');
  btn.textContent = ' Salvar Alterações';
  btn.onclick = confirmarSalvarEdicaoMulta;
  showToast('Modo de edição ativado', 'info');
};

window.confirmarSalvarEdicaoMulta = async function() {
  const valor = parseFloat(document.getElementById('multaValorInput').value);
  const motivo = document.getElementById('multaMotivoInput').value.trim() || 'Multa';
  if (!valor || valor <= 0) { showToast('Informe um valor válido', 'error'); return; }
  
  await salvarMulta({ id: multaEditandoId, valor, motivo });
  showToast('Multa atualizada!', 'success');
  
  // Resetar formulário
  multaEditandoId = null;
  document.getElementById('multaValorInput').value = '';
  document.getElementById('multaMotivoInput').value = '';
  const btn = document.querySelector('button[onclick="confirmarSalvarEdicaoMulta()"]');
  btn.textContent = 'Lançar multa';
  btn.onclick = confirmarLancarMulta;
  
  abrirGestaoMultas(multaVendaIdAtual);
  renderPainel();
};

window.confirmarExcluirMulta = async function(multaId) {
  if (!confirm('Tem certeza que deseja excluir esta multa permanentemente? Isso também removerá os registros financeiros vinculados a ela.')) return;
  await excluirMulta(multaId);
  showToast('Multa excluída com sucesso!', 'success');
  abrirGestaoMultas(multaVendaIdAtual);
  renderPainel();
  renderVendas();
};

document.getElementById('closeModalMulta').addEventListener('click',()=>closeModal('modalMulta'));
document.getElementById('cancelarMulta').addEventListener('click',  ()=>closeModal('modalMulta'));

/* ═══════════════════════════════════════════════════════════
   SETTINGS
═══════════════════════════════════════════════════════════ */
document.getElementById('btnSettings').addEventListener('click', async () => {
  sincronizarSettingsUI(carregarSettings());
  await carregarConfigRuta();
  openModal('modalSettings');
});
document.getElementById('closeModalSettings').addEventListener('click',()=>closeModal('modalSettings'));
document.getElementById('fecharSettings').addEventListener('click',()=>closeModal('modalSettings'));

async function carregarConfigRuta() {
  const res = await api('ruta.get');
  const content = document.getElementById('rutaConfigContent');
  if (res) {
    const r = res;  // api() já retorna json.dados diretamente
    content.innerHTML = `
      <div class="form-group">
        <label>RUTA</label>
        <p style="font-size:13px;color:var(--text-primary);margin:0 0 4px 0;font-weight:600">${r.nome || '—'}</p>
      </div>
      <div class="form-group">
        <label>E-mail de Login da RUTA</label>
        <input type="email" id="ruta_email" value="${r.email || ''}" placeholder="ruta@exemplo.com"/>
      </div>
      <div class="form-group">
        <label>Nova Senha (deixe em branco para manter)</label>
        <input type="password" id="ruta_senha" placeholder="••••••"/>
      </div>
      <div class="form-group">
        <label>PIN da RUTA (4 dígitos)</label>
        <input type="text" id="ruta_pin" value="${r.pin || '1234'}" maxlength="4"/>
      </div>
      <div class="form-group">
        <label>Capital Base (R$)</label>
        <input type="number" id="ruta_capital" value="${r.capital_base || 0}" step="0.01"/>
      </div>
      <button class="btn-primary" onclick="salvarConfigRuta()" style="width:100%;margin-top:10px">Salvar</button>
    `;
  } else {
    content.innerHTML = `<p style="font-size:12px;color:var(--red)">Nenhuma RUTA vinculada a este usuário.</p>`;
  }
}

async function salvarConfigRuta() {
  const dados = {
    email: document.getElementById('ruta_email').value,
    senha: document.getElementById('ruta_senha').value,
    pin: document.getElementById('ruta_pin').value,
    capital_base: parseFloat(document.getElementById('ruta_capital').value) || 0
  };
  await api('ruta.salvar', { dados });
  showToast('Configurações salvas!');
  carregarConfigRuta();
}

document.getElementById('btnSetPin').addEventListener('click',()=>{
  const pin=document.getElementById('settingsPinInput').value.trim();
  if(!pin||pin.length<4){showToast('PIN deve ter pelo menos 4 dígitos','error');return;}
  const s=carregarSettings();s.pinGaleria=pin;salvarSettingsLocal(s);document.getElementById('settingsPinInput').value='';
  sincronizarSettingsUI(s);galeriaUnlocked=false;showToast('PIN definido! ');
});
document.getElementById('btnClearPin').addEventListener('click',()=>{
  const s=carregarSettings();delete s.pinGaleria;salvarSettingsLocal(s);sincronizarSettingsUI(s);galeriaUnlocked=false;showToast('PIN removido.','info');
});
document.getElementById('temaClaro').addEventListener('change',e=>{const s=carregarSettings();s.temaClaro=e.target.checked;salvarSettingsLocal(s);aplicarSettings(s);});
document.querySelectorAll('.cor-opcao').forEach(btn=>{btn.addEventListener('click',()=>{document.querySelectorAll('.cor-opcao').forEach(b=>b.classList.remove('ativa'));btn.classList.add('ativa');const s=carregarSettings();s.accentColor=btn.dataset.cor;s.accentHover=btn.dataset.hover;salvarSettingsLocal(s);aplicarSettings(s);showToast('Cor alterada!','info');});});
document.querySelectorAll('.font-opt').forEach(btn=>{btn.addEventListener('click',()=>{document.querySelectorAll('.font-opt').forEach(b=>b.classList.remove('ativa'));btn.classList.add('ativa');const s=carregarSettings();s.fontSize=parseInt(btn.dataset.size);salvarSettingsLocal(s);aplicarSettings(s);});});

/* ═══════════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════════ */
(async () => {
  aplicarSettings(carregarSettings());
  await atualizarStatusAutomatico();
  iniciarAutoTimer();
  await renderPainel();
})();

/* ═══════════════════════════════════════════════════════════
   MODAL DE CONFIRMAÇÃO DE BAIXA (INTEGRADO)
   ═══════════════════════════════════════════════════════════ */
let dadosConfirmacaoBaixa = { vendaId: null, cliente: null, parcela: null, valor: 0, vencimento: null, formaPagamento: 'dinheiro' };

window.abrirConfirmacaoBaixa = function(dados) {
  dadosConfirmacaoBaixa = { ...dados };
  document.getElementById('confirmacaoBaixaCliente').textContent = dadosConfirmacaoBaixa.cliente;
  document.getElementById('confirmacaoBaixaParcela').textContent = dadosConfirmacaoBaixa.parcela;
  document.getElementById('confirmacaoBaixaValorInput').value = (dadosConfirmacaoBaixa.valor||0).toFixed(2);
  document.getElementById('confirmacaoBaixaVencimento').textContent = dadosConfirmacaoBaixa.vencimento;
  document.getElementById('confirmacaoBaixaForma').textContent = {'dinheiro':' Dinheiro','pix':' Pix','cheque':' Cheque','cartao':' Cartão'}[dadosConfirmacaoBaixa.formaPagamento] || dadosConfirmacaoBaixa.formaPagamento;
  openModal('modalConfirmacaoBaixa');
};

window.executarConfirmacaoBaixa = async function() {
  const btn = document.getElementById('btnConfirmarBaixa');
  const valorPago = parseFloat(document.getElementById('confirmacaoBaixaValorInput').value);
  if (!valorPago || valorPago <= 0) { showToast('Informe o valor pago', 'error'); return; }
  btn.disabled = true;
  try {
    showToast('Processando baixa...', 'info');
    const res = await registrarPagamentoTransacional({
      vendaId: dadosConfirmacaoBaixa.vendaId,
      valorPago: valorPago,
      formaPagamento: dadosConfirmacaoBaixa.formaPagamento,
      data: hoje(),
      clienteNome: dadosConfirmacaoBaixa.cliente
    });
    // CORREÇÃO: api() já retorna json.dados diretamente (não o wrapper
    // {sucesso, dados}). "res.sucesso" nunca existia, então o toast de
    // erro disparava mesmo quando a baixa era gravada com sucesso no banco.
    // - res === null                     -> erro real; api() já mostrou o toast com a mensagem do backend
    // - res.erro === 'MULTAS_PENDENTES'  -> erro específico, precisa de toast próprio
    // - res truthy (qualquer outro caso)  -> sucesso
    if (res && res.erro === 'MULTAS_PENDENTES') {
      showToast(res.mensagem, 'error');
    } else if (res) {
      showToast(` Parcela baixada! ${fmt(valorPago)}`, 'success');
      closeModal('modalConfirmacaoBaixa');
      renderPainel(); renderVendas();
      if (clienteDetalheId) abrirDetalheCliente(clienteDetalheId);
    }
    // res === null: erro já foi tratado e exibido pelo helper api(), não duplica toast
  } catch (err) {
    showToast('Erro na operação', 'error');
  } finally {
    btn.disabled = false;
  }
};
</script>

<div class="modal-overlay" id="modalConfirmacaoBaixa">
  <div class="modal modal-large">
    <div class="modal-header">
      <h3>Confirmar Baixa</h3>
      <button class="btn-close" onclick="closeModal('modalConfirmacaoBaixa')"></button>
    </div>
    <div class="modal-body">
      <div style="text-align:center;font-size:48px;margin-bottom:10px"></div>
      <div style="font-size:18px;font-weight:700;text-align:center;margin-bottom:8px">Deseja confirmar a baixa?</div>
      <div style="font-size:13px;color:var(--text-secondary);text-align:center;line-height:1.5">Esta ação registrará o recebimento e atualizará o status da parcela.</div>
      <div style="background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:var(--radius);padding:14px 16px;display:flex;flex-direction:column;gap:8px;margin-top:12px">
        <div style="display:flex;justify-content:space-between;font-size:13px"><strong style="color:var(--text-secondary)">Cliente</strong><span id="confirmacaoBaixaCliente"></span></div>
        <div style="display:flex;justify-content:space-between;font-size:13px"><strong style="color:var(--text-secondary)">Parcela</strong><span id="confirmacaoBaixaParcela"></span></div>
        <div style="display:flex;justify-content:space-between;align-items:center;font-size:13px"><strong style="color:var(--text-secondary)">Valor recebido</strong><input type="number" id="confirmacaoBaixaValorInput" step="0.01" min="0.01" style="width:130px;text-align:right;background:var(--bg-input);border:1px solid var(--border-strong);border-radius:var(--radius-sm);padding:7px 9px;color:var(--accent);font-weight:700;font-size:14px"/></div>
        <div style="display:flex;justify-content:space-between;font-size:13px"><strong style="color:var(--text-secondary)">Vencimento</strong><span id="confirmacaoBaixaVencimento"></span></div>
        <div style="display:flex;justify-content:space-between;font-size:13px"><strong style="color:var(--text-secondary)">Forma</strong><span id="confirmacaoBaixaForma"></span></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-secondary" onclick="closeModal('modalConfirmacaoBaixa')">Cancelar</button>
      <button class="btn-primary" id="btnConfirmarBaixa" onclick="executarConfirmacaoBaixa()">Confirmar Baixa</button>
    </div>
  </div>
</div>
</body>
</html>
