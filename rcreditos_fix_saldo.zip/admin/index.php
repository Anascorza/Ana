<?php
require_once __DIR__ . '/includes/config.php';
requireAdmin();

$adminId = $_SESSION['adm_id'] ?? 0;

// ── Totais gerais ─────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
// SALDO GERAL ACUMULADO — fórmula fixa, não alterar sem atualizar este comentário:
//   Saldo Geral Acumulado = Valor Investido + Total de Aportes - Total Retirado da Rua - Total Emprestado
// ════════════════════════════════════════════════════════════════════════════
// $totais — exclui movimentações de pagamentos retroativos (defesa
// em profundidade — pagamentos.salvar já não registra essas movs).
$totais = qOne("
    SELECT
        COUNT(DISTINCT r.id)                                                           AS total_rutas,
        COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor END)), 0)          AS total_emprestado,
        COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0)                    AS total_multas,
        COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0)                AS total_pagamentos,
        (SUM(r.capital_base) 
            + COALESCE(SUM(CASE WHEN m.tipo='aporte' THEN m.valor ELSE 0 END), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor ELSE 0 END)), 0)
        ) AS lucro_total
    FROM rutas r
    LEFT JOIN usuarios u ON u.id = r.usuario_id
    LEFT JOIN movimentacoes m ON m.ruta_id = r.id
        AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
    WHERE u.admin_id = ? OR u.id = ?
", [$adminId, $adminId]);

// ── Lucro hoje global ─────────────────────────────────────────────
// Nota: Lucro hoje reflete apenas movimentações do dia (pagamentos + multas),
// não altera o Saldo Geral Acumulado que é calculado acumulativamente.
$hoje = qOne("
    SELECT         (SUM(CASE WHEN DATE(m.data_mov) = CURDATE() THEN r.capital_base ELSE 0 END) 
            + COALESCE(SUM(CASE WHEN m.tipo='aporte' AND DATE(m.data_mov) = CURDATE() THEN m.valor ELSE 0 END), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' AND DATE(m.data_mov) = CURDATE() THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' AND DATE(m.data_mov) = CURDATE() THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' AND DATE(m.data_mov) = CURDATE() THEN m.valor ELSE 0 END)), 0)
        ) AS lucro_hoje
    FROM movimentacoes m
    JOIN rutas r ON r.id = m.ruta_id
    JOIN usuarios u ON u.id = r.usuario_id
    WHERE (u.admin_id = ? OR u.id = ?)
", [$adminId, $adminId]);

// ── Lucro do mês global ───────────────────────────────────────────
// Nota: Lucro do mês reflete apenas movimentações do mês (pagamentos + multas),
// não altera o Saldo Geral Acumulado que é calculado acumulativamente.
$mes = qOne("
    SELECT         (SUM(CASE WHEN YEAR(m.data_mov) = YEAR(CURDATE()) AND MONTH(m.data_mov) = MONTH(CURDATE()) THEN r.capital_base ELSE 0 END) 
            + COALESCE(SUM(CASE WHEN m.tipo='aporte' AND YEAR(m.data_mov) = YEAR(CURDATE()) AND MONTH(m.data_mov) = MONTH(CURDATE()) THEN m.valor ELSE 0 END), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' AND YEAR(m.data_mov) = YEAR(CURDATE()) AND MONTH(m.data_mov) = MONTH(CURDATE()) THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' AND YEAR(m.data_mov) = YEAR(CURDATE()) AND MONTH(m.data_mov) = MONTH(CURDATE()) THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' AND YEAR(m.data_mov) = YEAR(CURDATE()) AND MONTH(m.data_mov) = MONTH(CURDATE()) THEN m.valor ELSE 0 END)), 0)
        ) AS lucro_mes
    FROM movimentacoes m
    JOIN rutas r ON r.id = m.ruta_id
    JOIN usuarios u ON u.id = r.usuario_id
    WHERE (u.admin_id = ? OR u.id = ?)
", [$adminId, $adminId]);

// ── Ranking rutas ─────────────────────────────────────────────────
$ranking   = getLucrosRutas();
$hojeMap   = array_column(getLucroHoje(),   null, 'ruta_id');
$semanaMap = array_column(getLucroSemana(), null, 'ruta_id');
$mesMap    = array_column(getLucroMes(),    null, 'ruta_id');

$maxLucro = 0;
foreach ($ranking as $r) {
    if ((float)$r['lucro_liquido'] > $maxLucro) $maxLucro = (float)$r['lucro_liquido'];
}

// ── Últimas 10 movimentações ──────────────────────────────────────
// Exclui movimentações derivadas de pagamentos retroativos (defesa
// em profundidade — pagamentos.salvar já não registra essas movs).
$ultimas = qAll("
    SELECT m.*, r.nome AS ruta_nome
    FROM movimentacoes m
    JOIN rutas r ON r.id = m.ruta_id
    JOIN usuarios u ON u.id = r.usuario_id
    WHERE (u.admin_id = ? OR u.id = ?)
      AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
    ORDER BY m.criado_em DESC
    LIMIT 10
", [$adminId, $adminId]);

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require_once __DIR__ . '/includes/layout.php';
?>

<!-- STAT CARDS -->
<div class="stat-grid">
  <div class="stat-card sc-green fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
    </div>
    <div class="stat-label">Saldo Geral</div>
    <div class="stat-value"
         data-count="<?= abs((float)$totais['lucro_total']) ?>"
         data-prefix="R$ " data-decimals="2">
      <?= brl((float)$totais['lucro_total']) ?>
    </div>
    <div class="stat-sub">Capital atual da ruta</div>
  </div>

  <div class="stat-card sc-cyan fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
    </div>
    <div class="stat-label">Total Emprestado</div>
    <div class="stat-value"
         data-count="<?= (float)$totais['total_emprestado'] ?>"
         data-prefix="R$ " data-decimals="2">
      <?= brl((float)$totais['total_emprestado']) ?>
    </div>
    <div class="stat-sub">Capital em operação</div>
  </div>

  <div class="stat-card sc-yellow fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
    </div>
    <div class="stat-label">Multas Arrecadadas</div>
    <div class="stat-value"
         data-count="<?= (float)$totais['total_multas'] ?>"
         data-prefix="R$ " data-decimals="2">
      <?= brl((float)$totais['total_multas']) ?>
    </div>
    <div class="stat-sub">Total de multas</div>
  </div>

  <div class="stat-card sc-purple fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
    </div>
    <div class="stat-label">Total de Rutas</div>
    <div class="stat-value"
         data-count="<?= (int)$totais['total_rutas'] ?>"
         data-decimals="0">
      <?= (int)$totais['total_rutas'] ?>
    </div>
    <div class="stat-sub">Carteiras cadastradas</div>
  </div>

  <div class="stat-card sc-green fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
    </div>
    <div class="stat-label">Saldo Hoje</div>
    <div class="stat-value"
         data-count="<?= abs((float)$hoje['lucro_hoje']) ?>"
         data-prefix="R$ " data-decimals="2">
      <?= brl((float)$hoje['lucro_hoje']) ?>
    </div>
    <div class="stat-sub"><?= date('d/m/Y') ?></div>
  </div>

  <div class="stat-card sc-cyan fu">
    <div class="stat-icon">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
    </div>
    <div class="stat-label">Saldo do Mês</div>
    <div class="stat-value"
         data-count="<?= abs((float)$mes['lucro_mes']) ?>"
         data-prefix="R$ " data-decimals="2">
      <?= brl((float)$mes['lucro_mes']) ?>
    </div>
    <div class="stat-sub"><?= date('m/Y') ?></div>
  </div>
</div>

<!-- RANKING RUTAS -->
<div class="card fu">
  <div class="card-header">
    <div class="card-title">Ranking de Rutas</div>
    <a href="<?= ADMIN_URL ?>/pages/rutas.php" class="card-action">Ver todas →</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Ruta</th><th>Responsável</th>
          <th>Emprestado</th><th>Hoje</th><th>Semana</th><th>Mês</th>
          <th>Saldo Geral</th><th>Status</th><th>Performance</th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($ranking)): ?>
        <tr><td colspan="10">
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            <p>Nenhuma ruta cadastrada ainda.</p>
          </div>
        </td></tr>
      <?php else: ?>
        <?php foreach ($ranking as $i => $r):
          $st  = statusLucro((float)$r['lucro_liquido']);
          $pct = $maxLucro > 0 ? (float)$r['lucro_liquido'] / $maxLucro * 100 : 0;
          $lh  = (float)($hojeMap[$r['ruta_id']]['lucro_hoje']    ?? 0);
          $ls  = (float)($semanaMap[$r['ruta_id']]['lucro_semana'] ?? 0);
          $lm  = (float)($mesMap[$r['ruta_id']]['lucro_mes']       ?? 0);
          $rc  = $i===0?'rank-1':($i===1?'rank-2':($i===2?'rank-3':''));
        ?>
        <tr>
          <td><span class="rank <?= $rc ?>"><?= $i+1 ?></span></td>
          <td>
            <a href="<?= ADMIN_URL ?>/pages/ruta_detalhe.php?id=<?= $r['ruta_id'] ?>"
               style="color:var(--text);text-decoration:none;font-weight:600">
              <?= htmlspecialchars($r['ruta_nome']) ?>
            </a>
          </td>
          <td>
            <?php if ($r['operador_nome']): ?>
              <div class="resp-chip">
                <div class="resp-chip-avatar"><?= strtoupper(substr($r['operador_nome'],0,1)) ?></div>
                <?= htmlspecialchars($r['operador_nome']) ?>
              </div>
            <?php else: ?>
              <span style="color:var(--muted)">—</span>
            <?php endif; ?>
          </td>
          <td class="val-neg"><?= brl((float)$r['total_emprestado']) ?></td>
          <td class="val-pos"><?= brl($lh) ?></td>
          <td class="val-pos"><?= brl($ls) ?></td>
          <td class="val-pos"><?= brl($lm) ?></td>
          <td class="<?= (float)$r['lucro_liquido']>=0?'val-pos':'val-neg' ?>" style="font-size:.9rem">
            <?= brl((float)$r['lucro_liquido']) ?>
          </td>
          <td><span class="badge <?= $st['cls'] ?>"><?= $st['label'] ?></span></td>
          <td style="min-width:90px">
            <div class="prog-wrap">
              <div class="prog-fill" data-pct="<?= max(0,$pct) ?>"></div>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ÚLTIMAS MOVIMENTAÇÕES -->
<div class="card fu">
  <div class="card-header">
    <div class="card-title">Últimas Movimentações</div>
    <a href="<?= ADMIN_URL ?>/pages/movimentacoes.php" class="card-action">Ver todas →</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Data/Hora</th><th>Ruta</th><th>Tipo</th><th>Cliente</th><th>Valor</th></tr>
      </thead>
      <tbody>
      <?php if (empty($ultimas)): ?>
        <tr><td colspan="5"><div class="empty-state"><p>Sem movimentações ainda.</p></div></td></tr>
      <?php else: ?>
        <?php foreach ($ultimas as $m): ?>
        <tr>
          <td class="dh-cell">
            <div class="dh-data"><?= date('d/m/Y', strtotime($m['data_mov'])) ?></div>
            <div class="dh-hora"><?= date('H:i', strtotime($m['criado_em'] ?? $m['data_mov'])) ?></div>
          </td>
          <td><?= htmlspecialchars($m['ruta_nome']) ?></td>
          <td><span class="tipo-badge t-<?= $m['tipo'] ?>"><?= $m['tipo'] ?></span></td>
          <td style="font-size:.82rem"><?= htmlspecialchars($m['cliente_nome'] ?? '—') ?></td>
          <td class="<?= $m['valor']>=0?'val-pos':'val-neg' ?>"><?= brl(abs($m['valor'])) ?></td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>
