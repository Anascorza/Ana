<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$msg   = '';
$tipo  = '';

// ── Troca de responsável ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rutaId    = (int)($_POST['ruta_id']    ?? 0);
    $usuarioId = (int)($_POST['usuario_id'] ?? 0);

    if ($rutaId > 0 && $usuarioId > 0) {
        // Verifica se o usuário existe e é admin/operador
        $u = qOne("SELECT id, nome FROM usuarios WHERE id = ? AND ativo = 1 LIMIT 1", [$usuarioId], 'i');
        $r = qOne("SELECT id, nome FROM rutas WHERE id = ? LIMIT 1", [$rutaId], 'i');

        if ($u && $r) {
            qExec("UPDATE rutas SET usuario_id = ? WHERE id = ?", [$usuarioId, $rutaId], 'ii');
            $msg  = "Responsável da ruta <strong>" . htmlspecialchars($r['nome']) . "</strong> atualizado para <strong>" . htmlspecialchars($u['nome']) . "</strong>.";
            $tipo = 'ok';
        } else {
            $msg  = 'Ruta ou usuário inválido.';
            $tipo = 'err';
        }
    }
}

// ── Dados ─────────────────────────────────────────────────────────
$adminId = $_SESSION['adm_id'] ?? 0;

$rutas    = qAll("\n    SELECT r.id, r.nome, r.ativa, u.id AS resp_id, u.nome AS resp_nome, u.email AS resp_email\n    FROM rutas r\n    LEFT JOIN usuarios u ON u.id = r.usuario_id\n    WHERE u.admin_id = ? OR u.id = ?\n    ORDER BY r.nome\n", [$adminId, $adminId], 'ii');

$usuarios = qAll("SELECT id, nome, email, tipo FROM usuarios WHERE ativo = 1 AND (admin_id = ? OR id = ?) ORDER BY nome", [$adminId, $adminId], 'ii');

$pageTitle  = 'Responsáveis';
$activePage = 'responsaveis';
require_once __DIR__ . '/../includes/layout.php';
?>

<?php if ($msg): ?>
<div style="background:<?= $tipo==='ok'?'var(--accent-dim)':'var(--red-dim)' ?>;
     border:1px solid <?= $tipo==='ok'?'rgba(74,222,128,.25)':'rgba(248,113,113,.25)' ?>;
     border-radius:10px;padding:12px 16px;font-size:.85rem;
     color:<?= $tipo==='ok'?'var(--accent)':'var(--red)' ?>">
  <?= $msg ?>
</div>
<?php endif; ?>

<div class="card fu">
  <div class="card-header">
    <div class="card-title">Vinculação de Responsáveis por Ruta</div>
    <span style="font-size:.78rem;color:var(--muted)"><?= count($rutas) ?> rutas</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Ruta</th><th>Status</th><th>Responsável Atual</th><th>Alterar Responsável</th></tr>
      </thead>
      <tbody>
      <?php if (empty($rutas)): ?>
        <tr><td colspan="4"><div class="empty-state"><p>Nenhuma ruta cadastrada.</p></div></td></tr>
      <?php else: ?>
        <?php foreach ($rutas as $r): ?>
        <tr>
          <td>
            <a href="<?= ADMIN_URL ?>/pages/ruta_detalhe.php?id=<?= $r['id'] ?>"
               style="color:var(--text);text-decoration:none;font-weight:600">
              <?= htmlspecialchars($r['nome']) ?>
            </a>
          </td>
          <td>
            <span class="badge <?= $r['ativa']?'badge-green':'badge-red' ?>">
              <?= $r['ativa']?'Ativa':'Inativa' ?>
            </span>
          </td>
          <td>
            <?php if ($r['resp_nome']): ?>
              <div class="resp-chip">
                <div class="resp-chip-avatar"><?= strtoupper(substr($r['resp_nome'],0,1)) ?></div>
                <div>
                  <div><?= htmlspecialchars($r['resp_nome']) ?></div>
                  <div style="font-size:.68rem;opacity:.6"><?= htmlspecialchars($r['resp_email']??'') ?></div>
                </div>
              </div>
            <?php else: ?>
              <span style="color:var(--muted);font-size:.82rem">— Sem responsável</span>
            <?php endif; ?>
          </td>
          <td>
            <form method="POST" style="display:flex;gap:8px;align-items:center">
              <input type="hidden" name="ruta_id" value="<?= $r['id'] ?>">
              <select name="usuario_id"
                style="background:var(--surface);border:1px solid var(--border);
                       color:var(--text);font-size:.8rem;padding:6px 10px;
                       border-radius:7px;outline:none;min-width:160px">
                <option value="">— Selecione —</option>
                <?php foreach ($usuarios as $u): ?>
                  <option value="<?= $u['id'] ?>" <?= $u['id']==$r['resp_id']?'selected':'' ?>>
                    <?= htmlspecialchars($u['nome']) ?> (<?= $u['tipo'] ?>)
                  </option>
                <?php endforeach; ?>
              </select>
              <button type="submit" class="btn-filter">Salvar</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Usuários disponíveis -->
<div class="card fu">
  <div class="card-header">
    <div class="card-title">Usuários Disponíveis</div>
    <span style="font-size:.78rem;color:var(--muted)"><?= count($usuarios) ?> usuários</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Nome</th><th>E-mail</th><th>Tipo</th><th>Rutas sob gestão</th></tr>
      </thead>
      <tbody>
      <?php foreach ($usuarios as $u):
        $qtdRutas = count(array_filter($rutas, fn($r) => $r['resp_id'] == $u['id']));
      ?>
      <tr>
        <td>
          <div class="user-chip" style="gap:8px">
            <div class="user-avatar" style="width:28px;height:28px;font-size:.72rem">
              <?= strtoupper(substr($u['nome'],0,1)) ?>
            </div>
            <span style="font-weight:500"><?= htmlspecialchars($u['nome']) ?></span>
          </div>
        </td>
        <td style="color:var(--muted2);font-size:.82rem"><?= htmlspecialchars($u['email']) ?></td>
        <td>
          <span class="badge <?= $u['tipo']==='admin'?'badge-green':'badge-cyan' ?>">
            <?= $u['tipo'] ?>
          </span>
        </td>
        <td>
          <?php if ($qtdRutas > 0): ?>
            <span class="val-pos" style="font-weight:700"><?= $qtdRutas ?></span>
            <span style="font-size:.78rem;color:var(--muted)"> ruta(s)</span>
          <?php else: ?>
            <span style="color:var(--muted);font-size:.82rem">Nenhuma</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/layout_end.php'; ?>
