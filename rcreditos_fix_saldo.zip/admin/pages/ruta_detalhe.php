<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header('Location: ' . BASE_URL . '/pages/rutas.php'); exit; }

// ── Dados da ruta ─────────────────────────────────────────────────
$ruta = qOne("
    SELECT r.*, u.nome AS operador_nome, u.email AS operador_email
    FROM rutas r
    LEFT JOIN usuarios u ON u.id = r.usuario_id
    WHERE r.id = ?
", [$id], 'i');

if (!$ruta) { header('Location: ' . BASE_URL . '/pages/rutas.php'); exit; }

// ════════════════════════════════════════════════════════════════
// SALDO GERAL ACUMULADO — fórmula fixa, não alterar sem atualizar este comentário:
//   Saldo Geral Acumulado = Valor Investido + Total de Aportes - Total Retirado da Rua - Total de Despesas - Total Emprestado
// ════════════════════════════════════════════════════════════════
// ── Métricas consolidadas ─────────────────────────────────────────
$metricas = qOne("
    SELECT
        COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor END)), 0)     AS total_emprestado,
        COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0)            AS total_pagamentos,
        COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0)                AS total_multas,
        COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' THEN m.valor END)), 0)         AS total_despesas,
        (r.capital_base 
            + COALESCE(SUM(CASE WHEN m.tipo='aporte' THEN m.valor ELSE 0 END), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' THEN m.valor ELSE 0 END)), 0)
            - COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor ELSE 0 END)), 0)
        ) AS lucro_liquido,
        COUNT(DISTINCT CASE WHEN m.tipo='emprestimo' THEN m.referencia_id END)     AS qtd_emprestimos
    FROM movimentacoes m 
    JOIN rutas r ON r.id = m.ruta_id
    WHERE m.ruta_id = ?
      AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
", [$id], 'i');

// ── Total recebido hoje nesta ruta ───────────────────────────────
// Segurança: confirma que a ruta pertence a um operador do admin
// antes de somar. A verificação já ocorre no SELECT acima ($ruta),
// que só carrega se r.id = $id — nenhuma ruta de outro admin passa.
// Recebido hoje — exclui pagamentos de ajuste retroativo
$recebidoHoje = (float)(qOne("
    SELECT COALESCE(SUM(p.valor_pago), 0) AS total
    FROM pagamentos p
    WHERE p.ruta_id = ?
      AND DATE(p.data) = CURDATE()
      AND COALESCE(p.motivo, '') NOT LIKE '%Ajuste retroativo%'
      AND COALESCE(p.motivo, '') NOT LIKE '%Reconciliação%'
      AND COALESCE(p.motivo, '') NOT LIKE '%Correção histórica%'
      AND COALESCE(p.motivo, '') NOT LIKE '%ajuste retroativo%'
      AND COALESCE(p.motivo, '') NOT LIKE '%reconciliação%'
      AND COALESCE(p.motivo, '') NOT LIKE '%correção histórica%'
", [$id], 'i')['total'] ?? 0);

// ── Movimentações do dia por tipo (ruta_id, hoje) ─────────────────
// Query: soma movimentacoes por tipo filtrando pela ruta e data atual.
// Tipos capturados: aporte (entradas), retirada, despesa, ajuste.
// Não altera pagamentos, vendas ou multas.
$movDia = qAll("
    SELECT tipo, COALESCE(SUM(valor), 0) AS total
    FROM movimentacoes
    WHERE ruta_id = ?
      AND DATE(data_mov) = CURDATE()
    GROUP BY tipo
", [$id], 'i');
$movDiaMap = [];
foreach ($movDia as $row) {
    $movDiaMap[$row['tipo']] = (float)$row['total'];
}
$entradasHoje  = (float)($movDiaMap['aporte']   ?? 0);
$retiradasHoje = abs((float)($movDiaMap['retirada'] ?? 0));
$despesasHoje  = abs((float)($movDiaMap['despesa']  ?? 0));
$ajustesHoje   = (float)($movDiaMap['ajuste']   ?? 0);

// ── Lucro por períodos ────────────────────────────────────────────
$lhojeArr   = getLucroHoje($id);
$lsemArr    = getLucroSemana($id);
$lmesArr    = getLucroMes($id);
$lhoje  = (float)($lhojeArr[0]['lucro_hoje']    ?? 0);
$lsem   = (float)($lsemArr[0]['lucro_semana']   ?? 0);
$lmes   = (float)($lmesArr[0]['lucro_mes']       ?? 0);

// ── Filtros das movimentações ─────────────────────────────────────
$fInicio = $_GET['data_inicio'] ?? '';
$fFim    = $_GET['data_fim']    ?? '';
$fTipo   = $_GET['tipo']        ?? '';

$where  = ['m.ruta_id = ?'];
$params = [$id];
$types  = 'i';

if ($fInicio) { $where[] = 'm.data_mov >= ?'; $params[] = $fInicio; $types .= 's'; }
if ($fFim)    { $where[] = 'm.data_mov <= ?'; $params[] = $fFim;    $types .= 's'; }
if ($fTipo)   { $where[] = 'm.tipo = ?';      $params[] = $fTipo;   $types .= 's'; }
// Exclui movimentações derivadas de pagamentos retroativos (defesa
// em profundidade — pagamentos.salvar já não registra essas movs).
$where[] = "(m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')";

$whereStr = implode(' AND ', $where);

$movs = qAll("
    SELECT m.* FROM movimentacoes m
    WHERE $whereStr
    ORDER BY m.data_mov DESC, m.criado_em DESC
    LIMIT 500
", $params, $types);

// ── Totais do filtro ──────────────────────────────────────────────
$tots = qOne("
    SELECT
        COALESCE(SUM(CASE WHEN valor > 0 THEN valor END), 0)      AS entradas,
        COALESCE(ABS(SUM(CASE WHEN valor < 0 THEN valor END)), 0) AS saidas,
        COALESCE(SUM(CASE WHEN tipo='multa' THEN valor END), 0)    AS multas,
        COALESCE(SUM(valor), 0)                                    AS saldo,
        COUNT(*)                                                   AS total_regs
    FROM movimentacoes m WHERE $whereStr
", $params, $types);

$st = statusLucro((float)$metricas['lucro_liquido']);

$pageTitle  = 'Detalhe — ' . htmlspecialchars($ruta['nome']);
$activePage = 'rutas';
require_once __DIR__ . '/../includes/layout.php';
?>

<a class="back-link" href="<?= ADMIN_URL ?>/pages/rutas.php">
  <svg viewBox="0 0 24 24"><polyline points="15,18 9,12 15,6"/></svg>
  Voltar para Rutas
</a>

<!-- Cabeçalho da ruta -->
<div class="detail-head fu">
  <div>
    <div class="detail-title"><?= htmlspecialchars($ruta['nome']) ?></div>
    <div class="detail-meta">
      <span class="badge <?= $st['cls'] ?>"><?= $st['label'] ?></span>
      <?php if ($ruta['operador_nome']): ?>
        <div class="resp-chip">
          <div class="resp-chip-avatar"><?= strtoupper(substr($ruta['operador_nome'],0,1)) ?></div>
          <?= htmlspecialchars($ruta['operador_nome']) ?>
          <?php if ($ruta['operador_email']): ?>
            <span style="opacity:.6">&nbsp;·&nbsp;<?= htmlspecialchars($ruta['operador_email']) ?></span>
          <?php endif; ?>
        </div>
      <?php endif; ?>
      <span>Capital base: <?= brl($ruta['capital_base']) ?></span>
      <span>Criada em: <?= date('d/m/Y', strtotime($ruta['criado_em'])) ?></span>
      <?php if (!$ruta['ativa']): ?>
        <span class="badge badge-red">Inativa</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Stats da ruta -->
<div class="stat-grid">
    <div class="stat-card sc-green fu">
    <div class="stat-label">Saldo Geral</div>
    <div class="stat-value"><?= brl($metricas['lucro_liquido']) ?></div>
    <div class="stat-sub">Capital Atual</div>
  </div>
  <div class="stat-card sc-cyan fu">
    <div class="stat-label">Hoje</div>
    <div class="stat-value"><?= brl($lhoje) ?></div>
    <div class="stat-sub"><?= date('d/m/Y') ?></div>
  </div>
  <div class="stat-card sc-cyan fu">
    <div class="stat-label">Semana</div>
    <div class="stat-value"><?= brl($lsem) ?></div>
    <div class="stat-sub">Últimos 7 dias</div>
  </div>
  <div class="stat-card sc-cyan fu">
    <div class="stat-label">Mês</div>
    <div class="stat-value"><?= brl($lmes) ?></div>
    <div class="stat-sub"><?= date('m/Y') ?></div>
  </div>
  <div class="stat-card sc-red fu">
    <div class="stat-label">Emprestado</div>
    <div class="stat-value"><?= brl($metricas['total_emprestado']) ?></div>
    <div class="stat-sub"><?= $metricas['qtd_emprestimos'] ?> empréstimo(s)</div>
  </div>
  <div class="stat-card sc-yellow fu">
    <div class="stat-label">Multas</div>
    <div class="stat-value"><?= brl($metricas['total_multas']) ?></div>
    <div class="stat-sub">Arrecadadas</div>
  </div>
  <div class="stat-card sc-green fu">
    <div class="stat-label">Recebido hoje</div>
    <div class="stat-value"><?= brl($recebidoHoje) ?></div>
    <div class="stat-sub">Total recebido hoje</div>
  </div>
</div>

<!-- Movimentações do dia -->
<div class="card fu" style="margin-bottom:18px">
  <div class="card-header">
    <div class="card-title">📒 Movimentações do Dia — <?= date('d/m/Y') ?></div>
  </div>
  <div class="stat-grid" style="padding:14px 16px;gap:10px">
    <div class="stat-card sc-green fu">
      <div class="stat-label">Entradas hoje</div>
      <div class="stat-value"><?= brl($entradasHoje) ?></div>
      <div class="stat-sub">Aportes / ingressos</div>
    </div>
    <div class="stat-card sc-red fu">
      <div class="stat-label">Retiradas hoje</div>
      <div class="stat-value"><?= brl($retiradasHoje) ?></div>
      <div class="stat-sub">Saídas registradas</div>
    </div>
    <div class="stat-card sc-red fu">
      <div class="stat-label">Despesas hoje</div>
      <div class="stat-value"><?= brl($despesasHoje) ?></div>
      <div class="stat-sub">Custos operacionais</div>
    </div>
    <div class="stat-card sc-yellow fu">
      <div class="stat-label">Ajustes de caixa hoje</div>
      <div class="stat-value"><?= brl($ajustesHoje) ?></div>
      <div class="stat-sub">Correções manuais</div>
    </div>
  </div>
</div>

<!-- Movimentações com filtro -->
<div class="card fu">
  <div class="card-header">
    <div class="card-title">Movimentações</div>
  </div>

  <form method="GET" action="">
    <input type="hidden" name="id" value="<?= $id ?>">
    <div class="filter-row">
      <input type="date" name="data_inicio" value="<?= htmlspecialchars($fInicio) ?>" placeholder="De">
      <input type="date" name="data_fim"    value="<?= htmlspecialchars($fFim) ?>"   placeholder="Até">
      <select name="tipo">
        <option value="">Todos os tipos</option>
        <?php foreach (['emprestimo','pagamento','multa','aporte','retirada','ajuste'] as $t): ?>
          <option value="<?= $t ?>" <?= $fTipo===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-filter">Filtrar</button>
      <a href="?id=<?= $id ?>" class="btn-clear">Limpar</a>
    </div>
  </form>

  <div class="filter-summary">
    <div class="fs-item"><span class="fs-label">Entradas: </span><span class="val-pos"><?= brl($tots['entradas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Saídas: </span><span class="val-neg"><?= brl($tots['saidas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Multas: </span><span class="val-neu"><?= brl($tots['multas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Saldo: </span><span class="<?= $tots['saldo']>=0?'val-pos':'val-neg' ?>"><?= brl($tots['saldo']) ?></span></div>
    <div class="fs-item" style="color:var(--muted)"><?= $tots['total_regs'] ?> registros</div>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Data/Hora</th><th>Tipo</th><th>Cliente</th><th>Referência</th><th>Valor</th><th>Descrição</th></tr>
      </thead>
      <tbody>
      <?php if (empty($movs)): ?>
        <tr><td colspan="6"><div class="empty-state"><p>Nenhuma movimentação no período.</p></div></td></tr>
      <?php else: ?>
        <?php foreach ($movs as $m): ?>
        <tr>
          <td class="dh-cell">
            <div class="dh-data"><?= date('d/m/Y', strtotime($m['data_mov'])) ?></div>
            <div class="dh-hora"><?= date('H:i', strtotime($m['criado_em'] ?? $m['data_mov'])) ?></div>
          </td>
          <td><span class="tipo-badge t-<?= $m['tipo'] ?>"><?= $m['tipo'] ?></span></td>
          <td style="font-size:.82rem"><?= htmlspecialchars($m['cliente_nome'] ?? '—') ?></td>
          <td style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($m['referencia_id'] ?? '—') ?></td>
          <td class="<?= $m['valor']>=0?'val-pos':'val-neg' ?>"><?= brl(abs($m['valor'])) ?></td>
          <td style="font-size:.78rem;color:var(--muted2);max-width:200px"><?= htmlspecialchars($m['descricao'] ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/layout_end.php'; ?>
