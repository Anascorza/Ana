<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$ranking   = getLucrosRutas();
$hojeMap   = array_column(getLucroHoje(),   null, 'ruta_id');
$semanaMap = array_column(getLucroSemana(), null, 'ruta_id');
$mesMap    = array_column(getLucroMes(),    null, 'ruta_id');

// Filtra por status se pedido
$filtroStatus = $_GET['status'] ?? '';
if ($filtroStatus === 'ativas') {
    $ranking = array_filter($ranking, fn($r) => $r['ativa'] == 1);
} elseif ($filtroStatus === 'inativas') {
    $ranking = array_filter($ranking, fn($r) => $r['ativa'] == 0);
}

$pageTitle  = 'Rutas';
$activePage = 'rutas';
require_once __DIR__ . '/../includes/layout.php';
?>

<div class="card fu">
  <div class="card-header">
    <div class="card-title">Todas as Rutas</div>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <span style="font-size:.78rem;color:var(--muted)"><?= count($ranking) ?> rutas</span>
      <form method="GET" style="display:flex;gap:6px">
        <select name="status" style="background:var(--surface);border:1px solid var(--border);color:var(--text);font-size:.8rem;padding:6px 10px;border-radius:7px;outline:none">
          <option value="" <?= $filtroStatus===''?'selected':'' ?>>Todas</option>
          <option value="ativas"   <?= $filtroStatus==='ativas'?'selected':'' ?>>Ativas</option>
          <option value="inativas" <?= $filtroStatus==='inativas'?'selected':'' ?>>Inativas</option>
        </select>
        <button type="submit" class="btn-filter">Filtrar</button>
      </form>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Ruta</th><th>Responsável</th><th>Capital Base</th>
          <th>Emprestado</th><th>Aportes</th><th>Recolhido</th>
          <th>Hoje</th><th>Semana</th><th>Mês</th>
          <th>Saldo Geral</th><th>Status</th><th></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($ranking)): ?>
        <tr><td colspan="12">
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            <p>Nenhuma ruta encontrada.</p>
          </div>
        </td></tr>
      <?php else: ?>
        <?php foreach ($ranking as $r):
          $st = statusLucro((float)$r['lucro_liquido']);
          $lh = (float)($hojeMap[$r['ruta_id']]['lucro_hoje']    ?? 0);
          $ls = (float)($semanaMap[$r['ruta_id']]['lucro_semana'] ?? 0);
          $lm = (float)($mesMap[$r['ruta_id']]['lucro_mes']       ?? 0);
        ?>
        <tr>
          <td>
            <div style="font-weight:600"><?= htmlspecialchars($r['ruta_nome']) ?></div>
            <div style="font-size:.72rem;color:var(--muted)"><?= $r['qtd_emprestimos'] ?> empréstimo(s)</div>
          </td>
          <td>
            <?php if ($r['operador_nome']): ?>
              <div class="resp-chip">
                <div class="resp-chip-avatar"><?= strtoupper(substr($r['operador_nome'],0,1)) ?></div>
                <?= htmlspecialchars($r['operador_nome']) ?>
              </div>
            <?php else: ?>
              <span style="color:var(--muted)">—</span>
            <?php endif; ?>
          </td>
          <td class="val-cyan"><?= brl($r['capital_base']) ?></td>
          <td class="val-neg"><?= brl($r['total_emprestado']) ?></td>
          <td class="val-pos"><?= brl($r['total_aportes']) ?></td>
          <td class="val-neg"><?= brl($r['total_recolhido']) ?></td>
          <td class="val-pos"><?= brl($lh) ?></td>
          <td class="val-pos"><?= brl($ls) ?></td>
          <td class="val-pos"><?= brl($lm) ?></td>
          <td class="<?= $r['lucro_liquido']>=0?'val-pos':'val-neg' ?>" style="font-size:.9rem;font-weight:700">
            <?= brl($r['lucro_liquido']) ?>
          </td>
          <td><span class="badge <?= $st['cls'] ?>"><?= $st['label'] ?></span></td>
          <td>
            <a href="<?= ADMIN_URL ?>/pages/ruta_detalhe.php?id=<?= $r['ruta_id'] ?>"
               style="font-size:.78rem;color:var(--accent);text-decoration:none;white-space:nowrap">
              Detalhe →
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/layout_end.php'; ?>
