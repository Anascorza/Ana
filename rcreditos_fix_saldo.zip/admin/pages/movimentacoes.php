<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$adminId = $_SESSION['adm_id'] ?? 0;

// ── Filtros ───────────────────────────────────────────────────────
$fInicio = $_GET['data_inicio'] ?? '';
$fFim    = $_GET['data_fim']    ?? '';
$fTipo   = $_GET['tipo']        ?? '';
$fRuta   = (int)($_GET['ruta']  ?? 0);

$where  = ['1=1'];
$params = [];
$types  = '';

if ($fInicio) { $where[] = 'm.data_mov >= ?'; $params[] = $fInicio; $types .= 's'; }
if ($fFim)    { $where[] = 'm.data_mov <= ?'; $params[] = $fFim;    $types .= 's'; }
if ($fTipo)   { $where[] = 'm.tipo = ?';      $params[] = $fTipo;   $types .= 's'; }
if ($fRuta)   { $where[] = 'm.ruta_id = ?';   $params[] = $fRuta;   $types .= 'i'; }
// Exclui movimentações derivadas de pagamentos retroativos (que não
// deveriam existir, pois pagamentos.salvar já filtra, mas garante
// defesa em profundidade caso algum registro antigo tenha escapado).
$where[] = "(m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')";

$whereStr = implode(' AND ', $where);

$movs = qAll("
    SELECT m.*, r.nome AS ruta_nome, u.nome AS usuario_nome
    FROM movimentacoes m
    JOIN rutas r    ON r.id = m.ruta_id
    JOIN usuarios u ON u.id = m.usuario_id
    WHERE (u.admin_id = ? OR u.id = ?) AND $whereStr
    ORDER BY m.data_mov DESC, m.criado_em DESC
    LIMIT 500
", array_merge([$adminId, $adminId], $params ?: []), $types ?: "");

// ── Totais do filtro ──────────────────────────────────────────────
$tots = qOne("
    SELECT
        COALESCE(SUM(CASE WHEN m.valor > 0 THEN m.valor END), 0)      AS entradas,
        COALESCE(ABS(SUM(CASE WHEN m.valor < 0 THEN m.valor END)), 0) AS saidas,
        COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0)    AS multas,
        COALESCE(SUM(m.valor), 0)                                      AS saldo,
        COUNT(*)                                                        AS total_regs
    FROM movimentacoes m
    JOIN rutas r ON r.id = m.ruta_id
    JOIN usuarios u ON u.id = r.usuario_id
    WHERE (u.admin_id = ? OR u.id = ?) AND $whereStr
", array_merge([$adminId, $adminId], $params ?: []), $types ?: "");

// ── Lista de rutas para o select de filtro ────────────────────────
$rutasLista = qAll("SELECT r.id, r.nome FROM rutas r JOIN usuarios u ON u.id = r.usuario_id WHERE u.admin_id = ? OR u.id = ? ORDER BY r.nome", [$adminId, $adminId]);

$pageTitle  = 'Movimentações';
$activePage = 'movimentacoes';
require_once __DIR__ . '/../includes/layout.php';
?>

<div class="card fu">
  <div class="card-header">
    <div class="card-title">Todas as Movimentações</div>
    <span style="font-size:.78rem;color:var(--muted)"><?= $tots['total_regs'] ?> registros</span>
  </div>

  <form method="GET" action="">
    <div class="filter-row">
      <input type="date" name="data_inicio" value="<?= htmlspecialchars($fInicio) ?>">
      <input type="date" name="data_fim"    value="<?= htmlspecialchars($fFim) ?>">
      <select name="tipo">
        <option value="">Todos os tipos</option>
        <?php foreach (['emprestimo','pagamento','multa','aporte','retirada','ajuste'] as $t): ?>
          <option value="<?= $t ?>" <?= $fTipo===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="ruta">
        <option value="">Todas as rutas</option>
        <?php foreach ($rutasLista as $rl): ?>
          <option value="<?= $rl['id'] ?>" <?= $fRuta===$rl['id']?'selected':'' ?>>
            <?= htmlspecialchars($rl['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-filter">Filtrar</button>
      <a href="?" class="btn-clear">Limpar</a>
    </div>
  </form>

  <div class="filter-summary">
    <div class="fs-item"><span class="fs-label">Entradas: </span><span class="val-pos"><?= brl($tots['entradas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Saídas: </span><span class="val-neg"><?= brl($tots['saidas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Multas: </span><span class="val-neu"><?= brl($tots['multas']) ?></span></div>
    <div class="fs-item"><span class="fs-label">Saldo: </span>
      <span class="<?= $tots['saldo']>=0?'val-pos':'val-neg' ?>"><?= brl($tots['saldo']) ?></span>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Data/Hora</th><th>Ruta</th><th>Operador</th><th>Tipo</th><th>Cliente</th><th>Valor</th><th>Descrição</th></tr>
      </thead>
      <tbody>
      <?php if (empty($movs)): ?>
        <tr><td colspan="7">
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
            <p>Nenhuma movimentação no período.</p>
          </div>
        </td></tr>
      <?php else: ?>
        <?php foreach ($movs as $m): ?>
        <tr>
          <td class="dh-cell">
            <div class="dh-data"><?= date('d/m/Y', strtotime($m['data_mov'])) ?></div>
            <div class="dh-hora"><?= date('H:i', strtotime($m['criado_em'] ?? $m['data_mov'])) ?></div>
          </td>
          <td>
            <a href="<?= ADMIN_URL ?>/pages/ruta_detalhe.php?id=<?= $m['ruta_id'] ?>"
               style="color:var(--text);text-decoration:none;font-weight:500;font-size:.84rem">
              <?= htmlspecialchars($m['ruta_nome']) ?>
            </a>
          </td>
          <td style="font-size:.78rem;color:var(--muted2)"><?= htmlspecialchars($m['usuario_nome'] ?? '—') ?></td>
          <td><span class="tipo-badge t-<?= $m['tipo'] ?>"><?= $m['tipo'] ?></span></td>
          <td style="font-size:.82rem"><?= htmlspecialchars($m['cliente_nome'] ?? '—') ?></td>
          <td class="<?= $m['valor']>=0?'val-pos':'val-neg' ?>"><?= brl(abs($m['valor'])) ?></td>
          <td style="font-size:.76rem;color:var(--muted);max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            <?= htmlspecialchars($m['descricao'] ?? '') ?>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/layout_end.php'; ?>
