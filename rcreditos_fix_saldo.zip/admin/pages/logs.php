<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$adminId = $_SESSION['adm_id'] ?? 0;

// Filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-7 days'));
$data_fim    = $_GET['data_fim']    ?? date('Y-m-d');
$usuario_id  = (int)($_GET['usuario_id'] ?? 0);

$where = "WHERE (l.admin_id = ? OR u.admin_id = ?) AND DATE(l.criado_em) BETWEEN ? AND ?";
$params = [$adminId, $adminId, $data_inicio, $data_fim];
$types = 'iiss';

if ($usuario_id > 0) {
    $where .= " AND l.usuario_id = ?";
    $params[] = $usuario_id;
    $types .= 'i';
}

$logs = qAll("
    SELECT l.*, COALESCE(u.nome, 'Sistema') AS usuario_nome, COALESCE(u.tipo, 'sistema') AS usuario_tipo
    FROM logs l
    LEFT JOIN usuarios u ON u.id = l.usuario_id
    $where
    ORDER BY l.id DESC
    LIMIT 500
", $params, $types);

$usuarios = qAll("SELECT id, nome FROM usuarios WHERE ativo = 1 AND (admin_id = ? OR id = ?) ORDER BY nome", [$adminId, $adminId], 'ii');

$pageTitle  = 'Monitoramento de Ações';
$activePage = 'logs';
require_once __DIR__ . '/../includes/layout.php';
?>

<div class="card fu">
  <form method="GET" class="filter-bar">
    <div class="filter-group">
      <label>Início</label>
      <input type="date" name="data_inicio" value="<?= $data_inicio ?>">
    </div>
    <div class="filter-group">
      <label>Fim</label>
      <input type="date" name="data_fim" value="<?= $data_fim ?>">
    </div>
    <div class="filter-group">
      <label>Usuário</label>
      <select name="usuario_id">
        <option value="0">Todos os usuários</option>
        <?php foreach ($usuarios as $u): ?>
          <option value="<?= $u['id'] ?>" <?= $u['id']==$usuario_id?'selected':'' ?>>
            <?= htmlspecialchars($u['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn-filter">Filtrar</button>
  </form>
</div>

<div class="card fu">
  <div class="card-header">
    <div class="card-title">Histórico de Atividades</div>
    <span style="font-size:.78rem;color:var(--muted)"><?= count($logs) ?> registros encontrados</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Data/Hora</th>
          <th>Usuário</th>
          <th>Ação</th>
          <th>Detalhes</th>
          <th>IP</th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($logs)): ?>
        <tr><td colspan="5"><div class="empty-state"><p>Nenhum registro encontrado para este período.</p></div></td></tr>
      <?php else: ?>
        <?php foreach ($logs as $l): ?>
        <tr>
          <td class="dh-cell">
            <div class="dh-data"><?= date('d/m/Y', strtotime($l['criado_em'])) ?></div>
            <div class="dh-hora"><?= date('H:i', strtotime($l['criado_em'])) ?></div>
          </td>
          <td>
            <div class="user-chip">
              <span style="font-weight:600;font-size:.85rem"><?= htmlspecialchars($l['usuario_nome']) ?></span>
              <span class="badge <?= $l['usuario_tipo']==='admin'?'badge-green':'badge-cyan' ?>" style="font-size:10px">
                <?= $l['usuario_tipo'] ?>
              </span>
            </div>
          </td>
          <td>
            <span style="font-weight:700;font-size:.82rem;color:var(--accent)">
              <?= htmlspecialchars($l['acao']) ?>
            </span>
          </td>
          <td style="font-size:.82rem;max-width:300px;overflow:hidden;text-overflow:ellipsis">
            <?= htmlspecialchars($l['detalhes'] ?? '—') ?>
          </td>
          <td style="font-family:monospace;font-size:.75rem;color:var(--muted2)">
            <?= htmlspecialchars($l['ip'] ?? '—') ?>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/layout_end.php'; ?>
