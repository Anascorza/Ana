/* R. Créditos — Admin JS v2.0 */

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', function () {

  // ── Barras de progresso ───────────────────────────────────
  document.querySelectorAll('.prog-fill[data-pct]').forEach(function (el) {
    var pct = Math.min(100, Math.max(0, parseFloat(el.dataset.pct) || 0));
    setTimeout(function () { el.style.width = pct + '%'; }, 80);
  });

  // ── Contagem animada nos stat-cards ──────────────────────
  document.querySelectorAll('[data-count]').forEach(function (el) {
    var target   = parseFloat(el.dataset.count) || 0;
    var prefix   = el.dataset.prefix  || '';
    var suffix   = el.dataset.suffix  || '';
    var decimals = el.dataset.decimals !== undefined ? parseInt(el.dataset.decimals) : 2;
    var duration = 750;
    var start    = performance.now();

    function tick(now) {
      var t    = Math.min((now - start) / duration, 1);
      var ease = 1 - Math.pow(1 - t, 3);
      var val  = target * ease;
      el.textContent = prefix + val.toLocaleString('pt-BR', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      }) + suffix;
      if (t < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });

});
