<?php
require_once __DIR__ . '/includes/config.php';

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    if (!$email || !$senha) {
        $erro = 'Preencha e-mail e senha.';
    } else {
        $user = qOne(
            "SELECT id, nome, senha, tipo FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1",
            [$email]
        );
        if ($user && $user['tipo'] === 'admin' && password_verify($senha, $user['senha'])) {
            session_regenerate_id(true);
            $_SESSION['adm_id']    = $user['id'];
            $_SESSION['adm_nome']  = $user['nome'];
            $_SESSION['adm_tipo']  = $user['tipo'];
            $_SESSION['adm_at']    = time();
            $_SESSION['adm_regen'] = time();
            header('Location: ' . ADMIN_URL . '/index.php'); exit;
        }
        $erro = 'E-mail ou senha incorretos, ou sem permissao de administrador.';
    }
}
$exp = !empty($_GET['exp']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#080b12">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="R. Créditos Admin">
<title>Login — <?= APP_NAME ?></title>
<link rel="manifest" href="<?= BASE_URL ?>/manifest.webmanifest">
<link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>/assets/icons/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>/assets/icons/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg:#080b12; --card:#111827; --border:#1f2937;
  --accent:#10b981; --accent-glow:rgba(16,185,129,.25);
  --danger:#ef4444; --warn:#f59e0b;
  --text:#e2e8f0; --muted:#64748b;
  --font:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
}
*,*::before,*::after { box-sizing:border-box; margin:0; padding:0; }
body {
  background:var(--bg); color:var(--text); font-family:var(--font);
  min-height:100vh; display:flex; align-items:center; justify-content:center;
  padding:20px;
}
body::after {
  content:''; position:fixed; top:-10%; left:50%; transform:translateX(-50%);
  width:600px; height:400px; pointer-events:none;
  background:radial-gradient(ellipse, rgba(16,185,129,.08) 0%, transparent 70%);
}
.card {
  background:var(--card); border:1px solid var(--border); border-radius:20px;
  padding:44px 40px; width:100%; max-width:400px; position:relative; z-index:1;
  box-shadow:0 0 60px rgba(0,0,0,.5);
  animation:up .4s cubic-bezier(.22,.68,0,1.2) both;
}
@keyframes up { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
.logo-wrap { text-align:center; margin-bottom:28px; }
.logo-icon {
  width:54px; height:54px;
  background:linear-gradient(135deg, var(--accent), #059669);
  border-radius:14px; display:grid; place-items:center;
  margin:0 auto 14px; font-weight:800; font-size:1.4rem; color:#fff;
  box-shadow:0 0 24px var(--accent-glow);
}
.logo-title { font-size:1.35rem; font-weight:800; letter-spacing:-.03em; }
.logo-sub { font-size:.78rem; color:var(--muted); margin-top:4px; }
.alert {
  border-radius:10px; padding:11px 14px; font-size:.84rem;
  font-weight:500; margin-bottom:20px;
}
.alert-err  { background:rgba(239,68,68,.1);  border:1px solid rgba(239,68,68,.3);  color:var(--danger); }
.alert-warn { background:rgba(245,158,11,.1); border:1px solid rgba(245,158,11,.3); color:var(--warn); }
.form-group { margin-bottom:16px; }
label {
  display:block; font-size:.72rem; font-weight:600; letter-spacing:.07em;
  text-transform:uppercase; color:var(--muted); margin-bottom:7px;
}
input {
  width:100%; background:rgba(255,255,255,.03); border:1px solid var(--border);
  border-radius:9px; color:var(--text); font-family:var(--font); font-size:.92rem;
  padding:12px 14px; outline:none; transition:border-color .18s, box-shadow .18s;
}
input:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(16,185,129,.12); }
input::placeholder { color:var(--muted); }
.btn {
  width:100%; background:linear-gradient(135deg, var(--accent), #059669);
  color:#fff; font-family:var(--font); font-weight:700; font-size:.95rem;
  border:none; border-radius:9px; padding:13px; cursor:pointer;
  transition:opacity .15s, transform .1s; margin-top:4px;
}
.btn:hover { opacity:.9; }
.btn:active { transform:scale(.98); }
.footer { margin-top:24px; font-size:.72rem; color:var(--muted); text-align:center; }
</style>
</head>
<body>
<div class="card">
  <div class="logo-wrap">
    <div class="logo-icon">R</div>
    <div class="logo-title"><?= APP_NAME ?></div>
    <div class="logo-sub">Painel Administrativo — Acesso restrito</div>
  </div>
  <?php if ($exp): ?>
    <div class="alert alert-warn">Sua sessao expirou. Faca login novamente.</div>
  <?php endif; ?>
  <?php if ($erro): ?>
    <div class="alert alert-err"><?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>
  <form method="POST" action="">
    <div class="form-group">
      <label for="email">E-mail</label>
      <input type="email" id="email" name="email" placeholder="admin@rcreditos.com"
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
    </div>
    <div class="form-group">
      <label for="senha">Senha</label>
      <input type="password" id="senha" name="senha" placeholder="••••••••" required>
    </div>
    <button class="btn" type="submit">Entrar no Painel</button>
  </form>
  <div class="footer"><?= APP_NAME ?> v<?= APP_VERSION ?></div>
</div>
</body>
</html>
