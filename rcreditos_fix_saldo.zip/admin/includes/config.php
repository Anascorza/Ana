<?php
/**
 * R. Créditos — Painel Administrativo — Configuração Central v8
 * ════════════════════════════════════════════════════════════════
 * Compatível com InfinityFree (PHP 7.4+ / MySQL 5.7+)
 */

// ── Fuso horário oficial ───────────────────────────────────────────
// Garante que date(), CURDATE() e os registros do painel usem Brasília.
date_default_timezone_set('America/Sao_Paulo');

// ── Detecta ambiente ──────────────────────────────────────────────
$_h = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? ''));
define('IS_LOCAL', in_array($_h, ['localhost', '127.0.0.1', '']));

// ── Credenciais do banco ──────────────────────────────────────────
// DEFINIDAS ANTES de incluir shared/db.php.
// O shared/db.php usa if(!defined()) e nunca vai sobrescrever estes valores.
if (!defined('DB_HOST')) {
    if (IS_LOCAL) {
        define('DB_HOST', 'localhost');
        define('DB_USER', 'root');
        define('DB_PASS', '');
        define('DB_NAME', 'rcreditos');
    } else {
        // ✅ InfinityFree — credenciais reais
        define('DB_HOST', 'sql302.infinityfree.com');
        define('DB_USER', 'if0_41425409');
        define('DB_PASS', 'hollaphy');
        define('DB_NAME', 'if0_41425409_Rcreditos');
    }
}

// ── Proteção contra redeclaração (CORRIGIDO) ──────────────────────
if (!defined('APP_NAME'))    define('APP_NAME',    'R. Créditos');
if (!defined('APP_VERSION')) define('APP_VERSION', '2.0.0');
if (!defined('SESSION_TTL')) define('SESSION_TTL', 28800); // 8 horas

// ── BASE_URL dinâmica (Compatível com subpastas InfinityFree) ─────
if (!defined('BASE_URL')) {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir  = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));

    // Remove subpastas conhecidas do admin
    $subpastas = ['/pages', '/includes', '/auth', '/config', '/api', '/css', '/js'];
    foreach ($subpastas as $sub) {
        if (substr($dir, -strlen($sub)) === $sub) {
            $dir = substr($dir, 0, -strlen($sub));
            break;
        }
    }
    // Remove /admin se estiver no final
    if (substr($dir, -6) === '/admin') {
        $dir = substr($dir, 0, -6);
    }

    define('BASE_URL',  '//' . $host . rtrim($dir, '/'));
    define('ADMIN_URL', BASE_URL . '/admin');
}

// ── Sessão segura (CORRIGIDA: strip de porta para compatibilidade LiteSpeed) ─
if (session_status() === PHP_SESSION_NONE) {
    session_name('RC_ADMIN');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    // Remove porta do host (ex: "site.com:80" → "site.com") para evitar
    // falha de cookie no LiteSpeed/InfinityFree
    $cookieDomain = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    session_set_cookie_params(0, '/', $cookieDomain, false, true);
    session_start();
}

// ── Conexão PDO (compartilhada via shared/db.php) ─────────────────
require_once __DIR__ . '/../../shared/db.php';
function db(): PDO { return getDB(); }

// ── Helpers de Banco ──────────────────────────────────────────────
function qAll(string $sql, array $params = [], string $types = ''): array {
    $db = db();
    if (empty($params)) return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    $st = $db->prepare($sql);
    $st->execute($params);
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

function qOne(string $sql, array $params = [], string $types = ''): ?array {
    $db = db();
    if (empty($params)) return $db->query($sql)->fetch(PDO::FETCH_ASSOC) ?: null;
    $st = $db->prepare($sql);
    $st->execute($params);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

function qExec(string $sql, array $params = [], string $types = ''): bool {
    $db = db();
    $st = $db->prepare($sql);
    return $st->execute($params);
}

// ── Formatação ────────────────────────────────────────────────────
function brl(float $v, bool $sinal = false): string {
    $f = 'R$&nbsp;' . number_format(abs($v), 2, ',', '.');
    if ($sinal && $v < 0) $f = '&minus;&nbsp;' . $f;
    return $f;
}

function statusLucro(float $v): array {
    if ($v > 0)  return ['label' => 'Gerando lucro', 'cls' => 'badge-green'];
    if ($v == 0) return ['label' => 'Empate',        'cls' => 'badge-yellow'];
    return            ['label' => 'Prejuízo',      'cls' => 'badge-red'];
}

// ── Log de ações do Painel Admin ──────────────────────────────────
// CORRIGIDO: usa nome diferente para não conflitar com logAcao() do app
if (!function_exists('logAcao')) {
    function logAcao(string $acao, ?string $detalhes = null): void {
        $db  = db();
        $uid = $_SESSION['adm_id'] ?? null;
        $ip  = $_SERVER['REMOTE_ADDR'] ?? null;
        try {
            $st = $db->prepare("INSERT INTO logs (usuario_id, admin_id, acao, detalhes, ip) VALUES (?, ?, ?, ?, ?)");
            $st->execute([$uid, $uid, $acao, $detalhes, $ip]);
        } catch (Exception $e) {
            error_log('[ADMIN LOG ERROR] ' . $e->getMessage());
        }
    }
}

// ── Autenticação do Painel Admin ──────────────────────────────────
function requireAdmin(): void {
    if (empty($_SESSION['adm_id']) || $_SESSION['adm_tipo'] !== 'admin') {
        header('Location: ' . ADMIN_URL . '/login.php');
        exit;
    }
    if (!empty($_SESSION['adm_at']) && (time() - $_SESSION['adm_at']) > SESSION_TTL) {
        session_unset();
        session_destroy();
        header('Location: ' . ADMIN_URL . '/login.php?exp=1');
        exit;
    }
    $_SESSION['adm_at'] = time();
    if (empty($_SESSION['adm_regen']) || time() - $_SESSION['adm_regen'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['adm_regen'] = time();
    }
}

// ── Consultas Administrativas ─────────────────────────────────────
        function getLucrosRutas(): array {
    $adminId = (int)($_SESSION['adm_id'] ?? 0);
    // Movimentações de pagamentos retroativos nunca são registradas
    // (pagamentos.salvar já filtra), mas a proteção extra abaixo garante
    // que nenhuma movimentação com descrição retroativa entre nos totais.
    return qAll("
        SELECT
            r.id AS ruta_id, r.nome AS ruta_nome, r.capital_base, r.ativa, r.criado_em,
            u.nome AS operador_nome, u.id AS operador_id,
            COALESCE(SUM(CASE WHEN m.valor > 0 THEN m.valor END), 0) AS total_entradas,
            COALESCE(ABS(SUM(CASE WHEN m.valor < 0 THEN m.valor END)), 0) AS total_saidas,
            COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor END)), 0) AS total_emprestado,
            COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0) AS total_pagamentos,
            COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0) AS total_multas,
            COALESCE(SUM(CASE WHEN m.tipo='aporte' THEN m.valor END), 0) AS total_aportes,
            COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' THEN m.valor END)), 0) AS total_recolhido,
            COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' THEN m.valor END)), 0) AS total_despesas,
            -- ════════════════════════════════════════════════════════════════
            -- SALDO GERAL ACUMULADO — fórmula fixa, não alterar sem atualizar este comentário:
            --   Saldo Geral Acumulado = Valor Investido + Total de Aportes - Total Retirado da Rua - Total de Despesas - Total Emprestado
            -- ════════════════════════════════════════════════════════════════
            (r.capital_base 
                + COALESCE(SUM(CASE WHEN m.tipo='aporte' THEN m.valor ELSE 0 END), 0) 
                - COALESCE(ABS(SUM(CASE WHEN m.tipo='retirada' THEN m.valor ELSE 0 END)), 0) 
                - COALESCE(ABS(SUM(CASE WHEN m.tipo='despesa' THEN m.valor ELSE 0 END)), 0)
                - COALESCE(ABS(SUM(CASE WHEN m.tipo='emprestimo' THEN m.valor ELSE 0 END)), 0)
            ) AS lucro_liquido,
            COUNT(DISTINCT CASE WHEN m.tipo='emprestimo' THEN m.referencia_id END) AS qtd_emprestimos
        FROM rutas r
        LEFT JOIN usuarios u ON u.id = r.usuario_id
        LEFT JOIN movimentacoes m ON m.ruta_id = r.id
            AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
        WHERE u.admin_id = ? OR u.id = ?
        GROUP BY r.id, r.nome, r.capital_base, r.ativa, r.criado_em, u.nome, u.id
        ORDER BY lucro_liquido DESC
    ", [$adminId, $adminId]);
}

function getLucroHoje(?int $rutaId = null): array {
    $adminId = (int)($_SESSION['adm_id'] ?? 0);
    $where   = $rutaId ? 'AND r.id = ?' : '';
    $params  = $rutaId ? [$adminId, $adminId, $rutaId] : [$adminId, $adminId];
    return qAll("
        SELECT r.id AS ruta_id, r.nome AS ruta_nome,
            COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0) AS pago_hoje,
            COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0) AS multa_hoje,
            COALESCE(
                SUM(CASE WHEN m.tipo IN ('pagamento','multa') THEN m.valor ELSE 0 END)
            , 0) AS lucro_hoje
        FROM rutas r
        JOIN usuarios u ON u.id = r.usuario_id
        LEFT JOIN movimentacoes m ON m.ruta_id = r.id AND DATE(m.data_mov) = CURDATE()
            AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
        WHERE (u.admin_id = ? OR u.id = ?) $where
        GROUP BY r.id, r.nome
    ", $params);
}

function getLucroSemana(?int $rutaId = null): array {
    $adminId = (int)($_SESSION['adm_id'] ?? 0);
    $where   = $rutaId ? 'AND r.id = ?' : '';
    $params  = $rutaId ? [$adminId, $adminId, $rutaId] : [$adminId, $adminId];
    return qAll("
        SELECT r.id AS ruta_id, r.nome AS ruta_nome,
            COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0) AS pago_semana,
            COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0) AS multa_semana,
            COALESCE(
                SUM(CASE WHEN m.tipo IN ('pagamento','multa') THEN m.valor ELSE 0 END)
            , 0) AS lucro_semana
        FROM rutas r
        JOIN usuarios u ON u.id = r.usuario_id
        LEFT JOIN movimentacoes m ON m.ruta_id = r.id
            AND m.data_mov BETWEEN DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND CURDATE()
            AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
        WHERE (u.admin_id = ? OR u.id = ?) $where
        GROUP BY r.id, r.nome
    ", $params);
}

function getLucroMes(?int $rutaId = null): array {
    $adminId = (int)($_SESSION['adm_id'] ?? 0);
    $where   = $rutaId ? 'AND r.id = ?' : '';
    $params  = $rutaId ? [$adminId, $adminId, $rutaId] : [$adminId, $adminId];
    return qAll("
        SELECT r.id AS ruta_id, r.nome AS ruta_nome,
            COALESCE(SUM(CASE WHEN m.tipo='pagamento' THEN m.valor END), 0) AS pago_mes,
            COALESCE(SUM(CASE WHEN m.tipo='multa' THEN m.valor END), 0) AS multa_mes,
            COALESCE(
                SUM(CASE WHEN m.tipo IN ('pagamento','multa') THEN m.valor ELSE 0 END)
            , 0) AS lucro_mes
        FROM rutas r
        JOIN usuarios u ON u.id = r.usuario_id
        LEFT JOIN movimentacoes m ON m.ruta_id = r.id
            AND YEAR(m.data_mov) = YEAR(CURDATE())
            AND MONTH(m.data_mov) = MONTH(CURDATE())
            AND (m.tipo != 'pagamento' OR COALESCE(m.descricao, '') NOT LIKE '%Retroativo%' AND COALESCE(m.descricao, '') NOT LIKE '%retroativo%')
        WHERE (u.admin_id = ? OR u.id = ?) $where
        GROUP BY r.id, r.nome
    ", $params);
}
?>
