  </div><!-- /content -->
</main><!-- /main -->

<script src="<?= ADMIN_URL ?>/js/admin.js"></script>
</body>
</html>
