<?php
/**
 * Layout principal — inclua no topo de cada página protegida:
 *   $pageTitle  = 'Dashboard';
 *   $activePage = 'dashboard';
 *   require_once __DIR__ . '/../includes/layout.php';
 * E no final da página:
 *   require_once __DIR__ . '/../includes/layout_end.php';
 */
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0a0d14">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="R. Créditos Admin">
<title><?= htmlspecialchars($pageTitle ?? 'Admin') ?> — <?= APP_NAME ?></title>
<link rel="manifest" href="<?= BASE_URL ?>/manifest.webmanifest">
<link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>/assets/icons/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>/assets/icons/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= ADMIN_URL ?>/css/admin.css">
</head>
<body>

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon">R</div>
    <div>
      <div class="brand-name"><?= APP_NAME ?></div>
      <div class="brand-sub">Painel Admin</div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">VISÃO GERAL</div>
    <a href="<?= ADMIN_URL ?>/index.php"
       class="nav-link <?= ($activePage??'')==='dashboard'?'active':'' ?>">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      Dashboard
    </a>

    <div class="nav-section">GESTÃO</div>
    <a href="<?= ADMIN_URL ?>/pages/rutas.php"
       class="nav-link <?= ($activePage??'')==='rutas'?'active':'' ?>">
      <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
      Rutas
    </a>
    <a href="<?= ADMIN_URL ?>/pages/movimentacoes.php"
       class="nav-link <?= ($activePage??'')==='movimentacoes'?'active':'' ?>">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/></svg>
      Movimentações
    </a>
    <a href="<?= ADMIN_URL ?>/pages/responsaveis.php"
       class="nav-link <?= ($activePage??'')==='responsaveis'?'active':'' ?>">
      <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Responsáveis
    </a>
    <a href="<?= ADMIN_URL ?>/pages/logs.php"
       class="nav-link <?= ($activePage??'')==='logs'?'active':'' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
      Monitoramento
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="user-chip">
      <div class="user-avatar"><?= strtoupper(substr($_SESSION['adm_nome']??'A',0,1)) ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($_SESSION['adm_nome']??'') ?></div>
        <div class="user-role">Administrador</div>
      </div>
    </div>
    <a href="<?= ADMIN_URL ?>/logout.php" class="logout-btn" title="Sair">
      <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
    </a>
  </div>
</aside>

<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<main class="main">
  <header class="topbar">
    <button class="hamburger" onclick="toggleSidebar()">
      <svg viewBox="0 0 24 24"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>
    <h1 class="topbar-title"><?= htmlspecialchars($pageTitle??'') ?></h1>
    <span class="topbar-date"><?= date('d/m/Y') ?></span>
  </header>
  <div class="content">
