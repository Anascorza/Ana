<?php
/**
 * R. Créditos — Roteador Principal v8
 * ════════════════════════════════════════════════════
 * Compatível com InfinityFree (PHP 8.x / Sem ERR_TOO_MANY_REDIRECTS)
 */
error_reporting(0);
ini_set('display_errors', '0');

// Caminho da URL sem query string
$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$uri = rtrim($uri, '/');

// Remove o subdiretório base da URL (compatibilidade com subpastas na InfinityFree)
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
if ($scriptDir !== '' && $scriptDir !== '/' && strpos($uri, $scriptDir) === 0) {
    $uri = substr($uri, strlen($scriptDir));
}
$uri = $uri ?: '/';

// ── Roteamento ───────────────────────────────────────────────────────
// 1. Acesso ao Admin (URL começa com /admin)
if (strpos($uri, '/admin') === 0) {
    $admin_file = __DIR__ . '/admin/index.php';
    if (file_exists($admin_file)) {
        require_once $admin_file;
    } else {
        http_response_code(500);
        die('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><title>Erro</title>'
        .'<style>body{font-family:sans-serif;background:#0a0d14;color:#e2e8f0;display:flex;'
        .'align-items:center;justify-content:center;min-height:100vh;margin:0}'
        .'.box{background:#111520;border:1px solid #1e2535;border-radius:16px;padding:40px;'
        .'max-width:480px;text-align:center}h2{color:#f87171;margin-bottom:12px}'
        .'code{color:#fbbf24;background:#1e2535;padding:2px 8px;border-radius:4px}</style></head>'
        .'<body><div class="box"><h2>Erro de Instalação</h2>'
        .'<p>A pasta <code>/admin</code> não foi encontrada.</p>'
        .'<p>Verifique se todos os arquivos foram enviados corretamente para a <code>htdocs</code>.</p>'
        .'</div></body></html>');
    }
    exit;
}

// 2. Acesso ao App (padrão)
$app_file = __DIR__ . '/app/index.php';
if (file_exists($app_file)) {
    require_once $app_file;
} else {
    http_response_code(500);
    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><title>Erro de Instalação</title>'
    .'<style>body{font-family:sans-serif;background:#0a0d14;color:#e2e8f0;display:flex;'
    .'align-items:center;justify-content:center;min-height:100vh;margin:0}'
    .'.box{background:#111520;border:1px solid #1e2535;border-radius:16px;padding:40px;'
    .'max-width:480px;text-align:center}h2{color:#f87171;margin-bottom:12px}'
    .'code{color:#fbbf24;background:#1e2535;padding:2px 8px;border-radius:4px}</style></head>'
    .'<body><div class="box"><h2>Erro de Instalação</h2>'
    .'<p>A pasta <code>/app</code> não foi encontrada.</p>'
    .'<p>Verifique se as pastas <code>admin</code>, <code>app</code>, <code>shared</code> estão dentro da <code>htdocs</code>.</p>'
    .'</div></body></html>';
}
exit;
