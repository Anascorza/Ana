-- Histórico diário de cobrança. Não altera vendas, parcelas ou pagamentos.
-- Executar uma única vez no banco R. Créditos.
CREATE TABLE IF NOT EXISTS historico_cobrancas (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id BIGINT NULL,
  admin_id BIGINT NULL,
  venda_id BIGINT NOT NULL,
  cliente_id VARCHAR(191) NOT NULL,
  parcela_numero INT NOT NULL,
  data_cobranca DATE NOT NULL,
  situacao VARCHAR(30) NOT NULL,
  observacao VARCHAR(255) NULL,
  pagamento_id BIGINT NULL,
  data_pagamento DATE NULL,
  valor_pago DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  evento_chave VARCHAR(191) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_historico_cobranca_evento (evento_chave),
  KEY idx_historico_venda_data (venda_id, data_cobranca),
  KEY idx_historico_cliente_data (cliente_id, data_cobranca)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
